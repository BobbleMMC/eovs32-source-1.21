@echo off
setlocal
set GRADLE_VERSION=8.12
set GRADLE_HOME=%CD%\.gradle\local-gradle\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat

if exist "%GRADLE_BIN%" (
  call "%GRADLE_BIN%" %*
  exit /b %ERRORLEVEL%
)

where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)

echo Local Gradle is not installed yet.
echo Run: setup_gradle_local.bat
echo Then run: .\gradlew.bat build
exit /b 1
