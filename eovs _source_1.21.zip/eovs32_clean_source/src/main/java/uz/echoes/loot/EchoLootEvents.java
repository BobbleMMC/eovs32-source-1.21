/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 */
package uz.echoes.loot;

import uz.echoes.EchoesMod;

public final class EchoLootEvents {
    private EchoLootEvents() {
    }

    public static void register() {
        EchoesMod.LOGGER.info("Echo loot hooks ready. Runtime entity loot can be expanded after build validation.");
    }
}

