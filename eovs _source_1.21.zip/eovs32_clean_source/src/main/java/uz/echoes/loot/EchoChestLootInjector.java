/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_2595
 */
package uz.echoes.loot;

import net.minecraft.class_1799;
import net.minecraft.class_2595;
import uz.echoes.structure.EchoLootTableManager;

public class EchoChestLootInjector {
    public static void injectLoot(class_2595 class_25952) {
        class_1799[] class_1799Array = EchoLootTableManager.getArenaLoot();
        for (int i = 0; i < class_1799Array.length; ++i) {
            class_25952.method_5447(i, class_1799Array[i]);
        }
    }
}

