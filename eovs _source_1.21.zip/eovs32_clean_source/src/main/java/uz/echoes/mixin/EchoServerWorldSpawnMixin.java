package uz.echoes.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.echoes.world.EchoProtectorSpawnRules;
import uz.echoes.world.EchoWardenSpawnLimiter;

@Mixin(class_3218.class)
public abstract class EchoServerWorldSpawnMixin {
    @Inject(method = "method_8649", at = @At("HEAD"), cancellable = true)
    private void eovs32$blockUnsafeSpawns(class_1297 entity, CallbackInfoReturnable<Boolean> cir) {
        class_3218 world = (class_3218)(Object)this;
        if (EchoProtectorSpawnRules.shouldBlockSpawn(world, entity) || EchoWardenSpawnLimiter.shouldBlockWardenSpawn(world, entity)) {
            cir.setReturnValue(Boolean.FALSE);
        }
    }
}
