package uz.echoes.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_2487;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.echoes.item.EchoPickaxeCounterAccess;

@Mixin(class_1657.class)
public abstract class EchoPlayerPersistentDataMixin implements EchoPickaxeCounterAccess {
    @Unique private static final String ECHO_PICKAXE_MINED_KEY = "eovs32_echo_pickaxe_mined";
    @Unique private int eovs32$echoPickaxeMinedCount = 0;

    @Override
    public int eovs32$getEchoPickaxeMinedCount() {
        return this.eovs32$echoPickaxeMinedCount;
    }

    @Override
    public void eovs32$setEchoPickaxeMinedCount(int count) {
        this.eovs32$echoPickaxeMinedCount = Math.max(0, count);
    }

    @Inject(method = "method_5652", at = @At("TAIL"))
    private void eovs32$writeEchoPickaxeCounter(class_2487 nbt, CallbackInfo ci) {
        nbt.method_10569(ECHO_PICKAXE_MINED_KEY, this.eovs32$echoPickaxeMinedCount);
    }

    @Inject(method = "method_5749", at = @At("TAIL"))
    private void eovs32$readEchoPickaxeCounter(class_2487 nbt, CallbackInfo ci) {
        this.eovs32$echoPickaxeMinedCount = Math.max(0, nbt.method_10550(ECHO_PICKAXE_MINED_KEY));
    }
}
