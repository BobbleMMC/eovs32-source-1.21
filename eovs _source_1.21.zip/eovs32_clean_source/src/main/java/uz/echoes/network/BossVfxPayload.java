/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2960
 *  net.minecraft.class_8710
 *  net.minecraft.class_8710$class_9154
 *  net.minecraft.class_9129
 *  net.minecraft.class_9139
 */
package uz.echoes.network;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record BossVfxPayload(String effect) implements class_8710
{
    public static final class_8710.class_9154<BossVfxPayload> ID = new class_8710.class_9154(class_2960.method_60655((String)"eovs32", (String)"boss_vfx"));
    public static final class_9139<class_9129, BossVfxPayload> CODEC = class_9139.method_56438((bossVfxPayload, class_91292) -> class_91292.method_10814(bossVfxPayload.effect()), class_91292 -> new BossVfxPayload(class_91292.method_19772()));

    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}

