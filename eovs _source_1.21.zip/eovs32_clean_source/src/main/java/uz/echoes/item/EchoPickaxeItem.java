package uz.echoes.item;

import java.util.List;
import java.util.WeakHashMap;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1836;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import uz.echoes.block.ModBlocks;

public class EchoPickaxeItem extends class_1810 {
    private static final class_2248 REINFORCED_DEEPSLATE = (class_2248)class_7923.field_41175.method_10223(class_2960.method_60655((String)"minecraft", (String)"reinforced_deepslate"));
    private static final WeakHashMap<class_1309, Integer> MINED_COUNTER = new WeakHashMap<>();

    public EchoPickaxeItem(class_1832 class_18322, class_1792.class_1793 class_17932) {
        super(class_18322, class_17932);
    }

    public float method_58404(class_1799 class_17992, class_2680 class_26802) {
        if (class_26802.method_27852(ModBlocks.SCULK_REINFORCED_STONE) || class_26802.method_27852(REINFORCED_DEEPSLATE)) {
            return 75.0f;
        }
        return super.method_58404(class_17992, class_26802);
    }

    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        boolean result = super.method_7879(stack, world, state, pos, miner);
        if (!world.method_8608()) {
            int mined;
            if (miner instanceof EchoPickaxeCounterAccess) {
                EchoPickaxeCounterAccess access = (EchoPickaxeCounterAccess)miner;
                mined = access.eovs32$incrementEchoPickaxeMinedCount();
                if (mined >= 1000) {
                    mined = 0;
                    access.eovs32$setEchoPickaxeMinedCount(0);
                    miner.method_6092(new class_1293(class_1294.field_5917, 1200, 1, true, true, true));
                }
            } else {
                mined = MINED_COUNTER.getOrDefault(miner, 0) + 1;
                if (mined >= 1000) {
                    mined = 0;
                    miner.method_6092(new class_1293(class_1294.field_5917, 1200, 1, true, true, true));
                }
                MINED_COUNTER.put(miner, mined);
            }
        }
        return result;
    }

    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_pickaxe.line1"));
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_pickaxe.line2"));
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_tools.line1"));
    }
}
