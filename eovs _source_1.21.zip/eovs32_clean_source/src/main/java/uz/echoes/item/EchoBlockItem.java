package uz.echoes.item;

import java.util.List;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;

public class EchoBlockItem extends class_1747 {
    private final String[] tooltipKeys;

    public EchoBlockItem(class_2248 block, class_1792.class_1793 settings, String... tooltipKeys) {
        super(block, settings);
        this.tooltipKeys = tooltipKeys;
    }

    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        for (String key : this.tooltipKeys) {
            tooltip.add(class_2561.method_43471(key));
        }
    }
}
