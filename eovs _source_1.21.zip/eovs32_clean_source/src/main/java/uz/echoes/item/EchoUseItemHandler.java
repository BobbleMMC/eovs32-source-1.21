package uz.echoes.item;

/**
 * Right-click safety shim.
 *
 * Earlier builds registered a global UseItemCallback here and manually handled
 * Echo Book, Echo Gate Sigil, EchoFunctionalItem and Echo armor use. That made
 * many item right-click actions fragile because Fabric item-use callbacks run
 * before the normal Item#use / Item#useOnBlock pipeline; returning SUCCESS or
 * CONSUME from the callback can stop the real item class from receiving the
 * click.
 *
 * Pro-fix rule:
 *   - Item-specific behaviour belongs in each Item subclass.
 *   - EchoBookItem opens the guide.
 *   - EchoFunctionalItem handles pearls, binder eye, rib bone and gate sigil.
 *   - EchoKeyItem handles portal-frame activation.
 *   - ArmorItem already handles normal right-click equip.
 *
 * Keeping this class as a no-op preserves source compatibility for EchoesMod
 * and prevents old duplicate callback logic from blocking other items.
 */
public final class EchoUseItemHandler {
    private EchoUseItemHandler() {
    }

    public static void register() {
        // Intentionally no-op. Do not register UseItemCallback here.
    }
}
