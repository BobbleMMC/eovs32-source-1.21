package uz.echoes.item;

import java.util.List;
import java.util.WeakHashMap;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;

public class EchoHoeItem extends class_1794 {
    private static final WeakHashMap<class_1657, Long> COOLDOWNS = new WeakHashMap<>();
    private static final long COOLDOWN_MS = 400L;

    public EchoHoeItem(class_1832 material, class_1792.class_1793 settings) {
        super(material, settings);
    }

    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_1657 player = context.method_8036();
        if (world.method_8608()) {
            return class_1269.field_5812;
        }
        if (player == null || !ready(player)) {
            return class_1269.field_5811;
        }
        class_2338 pos = context.method_8037();
        class_2680 state = world.method_8320(pos);
        boolean grown = this.tryGrowWithBonemeal((class_3218)world, pos, state) || this.tryGrowSugarCane((class_3218)world, pos, state);
        if (!grown) {
            return super.method_7884(context);
        }
        COOLDOWNS.put(player, System.currentTimeMillis());
        return class_1269.field_5812;
    }

    private boolean tryGrowWithBonemeal(class_3218 world, class_2338 pos, class_2680 state) {
        if (!(state.method_26204() instanceof class_2256)) {
            return false;
        }
        class_2256 fertilizable = (class_2256)state.method_26204();
        if (!fertilizable.method_9651(world, pos, state) || !fertilizable.method_9650(world, world.method_8409(), pos, state)) {
            return false;
        }
        fertilizable.method_9652(world, world.method_8409(), pos, state);
        return true;
    }

    private boolean tryGrowSugarCane(class_3218 world, class_2338 pos, class_2680 state) {
        String id = class_7923.field_41175.method_10221(state.method_26204()).toString();
        if (!id.equals("minecraft:sugar_cane")) {
            return false;
        }
        class_2248 sugar = state.method_26204();
        int height = 1;
        class_2338 bottom = pos;
        while (world.method_8320(bottom.method_10074()).method_27852(sugar)) {
            bottom = bottom.method_10074();
        }
        class_2338 top = bottom;
        while (world.method_8320(top.method_10084()).method_27852(sugar)) {
            top = top.method_10084();
            ++height;
        }
        if (height >= 4 || !world.method_8320(top.method_10084()).method_26215()) {
            return false;
        }
        world.method_8652(top.method_10084(), sugar.method_9564(), 3);
        return true;
    }

    private static boolean ready(class_1657 player) {
        long last = COOLDOWNS.getOrDefault(player, 0L);
        return System.currentTimeMillis() - last >= COOLDOWN_MS;
    }

    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_hoe.line1"));
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_tools.line1"));
    }
}
