package uz.echoes.item;

import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1821;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class EchoShovelItem extends class_1821 {
    private static final class_1935 DIAMOND = (class_1935)class_7923.field_41178.method_10223(class_2960.method_60655((String)"minecraft", (String)"diamond"));
    private static final class_1935 DIAMOND_BLOCK = (class_1935)class_7923.field_41175.method_10223(class_2960.method_60655((String)"minecraft", (String)"diamond_block"));

    public EchoShovelItem(class_1832 material, class_1792.class_1793 settings) {
        super(material, settings);
    }

    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        boolean result = super.method_7879(stack, world, state, pos, miner);
        if (!world.method_8608()) {
            this.dropSuspiciousBlockIfNeeded(state, miner);
            int roll = miner.method_59922().method_43048(10000);
            if (roll == 0) {
                miner.method_5775(new class_1799(DIAMOND_BLOCK, 1));
            } else if (roll < 100) {
                miner.method_5775(new class_1799(DIAMOND, 1));
            }
        }
        return result;
    }

    private void dropSuspiciousBlockIfNeeded(class_2680 state, class_1309 miner) {
        class_2248 block = state.method_26204();
        String id = class_7923.field_41175.method_10221(block).toString();
        if (id.equals("minecraft:suspicious_sand") || id.equals("minecraft:suspicious_gravel")) {
            miner.method_5775(new class_1799((class_1935)block, 1));
        }
    }

    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_shovel.line1"));
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_shovel.line2"));
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_tools.line1"));
    }
}
