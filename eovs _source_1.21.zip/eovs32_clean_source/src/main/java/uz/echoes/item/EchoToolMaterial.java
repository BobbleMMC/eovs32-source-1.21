/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1832
 *  net.minecraft.class_1834
 *  net.minecraft.class_1856
 *  net.minecraft.class_1935
 *  net.minecraft.class_2248
 *  net.minecraft.class_2960
 *  net.minecraft.class_6862
 *  net.minecraft.class_7924
 */
package uz.echoes.item;

import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import uz.echoes.item.ModItems;

public enum EchoToolMaterial implements class_1832
{
    INSTANCE;

    private static final class_6862<class_2248> INCORRECT_FOR_ECHO_TOOL = class_6862.method_40092((net.minecraft.class_5321)class_7924.field_41254, (class_2960)class_2960.method_60655((String)"eovs32", (String)"incorrect_for_echo_tool"));

    public int method_8025() {
        return 3072;
    }

    public float method_8027() {
        return 15.0f;
    }

    public float method_8028() {
        return 5.0f;
    }

    public class_6862<class_2248> method_58419() {
        return INCORRECT_FOR_ECHO_TOOL;
    }

    public int method_8026() {
        return 40;
    }

    public class_1856 method_8023() {
        return class_1856.method_8091((class_1935[])new class_1935[]{ModItems.ECHO_WARDEN_HEART});
    }
}
