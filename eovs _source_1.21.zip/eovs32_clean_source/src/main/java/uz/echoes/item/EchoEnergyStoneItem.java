package uz.echoes.item;

import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import uz.echoes.block.ModBlocks;

public class EchoEnergyStoneItem extends class_1792 {
    public EchoEnergyStoneItem(class_1792.class_1793 settings) {
        super(settings);
    }

    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        if (world.method_8608()) {
            return class_1269.field_5812;
        }
        class_2338 pos = context.method_8037();
        if (!world.method_8320(pos).method_27852(ModBlocks.ECHO_ALTAR)) {
            return super.method_7884(context);
        }
        class_2338 above = pos.method_10084();
        if (!world.method_8320(above).method_26215()) {
            return class_1269.field_5811;
        }
        world.method_8652(above, ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564(), 3);
        pulseAltar((class_3218)world, pos);
        class_1657 player = context.method_8036();
        if (player != null && !player.method_7337()) {
            context.method_8041().method_7934(1);
        }
        return class_1269.field_5812;
    }

    private static void pulseAltar(class_3218 world, class_2338 center) {
        for (int dx = -3; dx <= 3; ++dx) {
            for (int dz = -3; dz <= 3; ++dz) {
                class_2338 p = center.method_10069(dx, 0, dz);
                if (isSculkEnergy(world.method_8320(p))) {
                    world.method_8652(p, ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564(), 3);
                }
            }
        }
    }


    private static boolean isSculkEnergy(net.minecraft.class_2680 state) {
        String id = class_7923.field_41175.method_10221(state.method_26204()).toString();
        return id.equals("minecraft:sculk_sensor") || id.equals("minecraft:sculk_shrieker") || id.equals("minecraft:sculk_catalyst") || id.equals("minecraft:sculk");
    }

    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echoenergy_stone.line1"));
    }
}
