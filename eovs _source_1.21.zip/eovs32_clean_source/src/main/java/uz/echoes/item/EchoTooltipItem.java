package uz.echoes.item;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

public class EchoTooltipItem extends class_1792 {
    private final String[] tooltipKeys;

    public EchoTooltipItem(class_1792.class_1793 settings, String... tooltipKeys) {
        super(settings);
        this.tooltipKeys = tooltipKeys;
    }

    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        for (String key : this.tooltipKeys) {
            tooltip.add(class_2561.method_43471(key));
        }
    }
}
