package uz.echoes.item;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1743;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_7923;

public class EchoAxeItem extends class_1743 {
    private static final int TREE_LIMIT = 250;

    public EchoAxeItem(class_1832 material, class_1792.class_1793 settings) {
        super(material, settings);
    }

    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        boolean result = super.method_7879(stack, world, state, pos, miner);
        if (!world.method_8608() && miner instanceof class_1657 && ((class_1657)miner).method_5715() && isLog(state)) {
            chopTree(world, pos, miner);
        }
        return result;
    }

    private static void chopTree(class_1937 world, class_2338 start, class_1309 miner) {
        ArrayDeque<class_2338> queue = new ArrayDeque<>();
        Set<class_2338> visited = new HashSet<>();
        Set<class_2338> leaves = new HashSet<>();
        queue.add(start);
        visited.add(start);
        int logs = 0;
        while (!queue.isEmpty() && logs < TREE_LIMIT) {
            class_2338 current = queue.removeFirst();
            for (int dx = -1; dx <= 1; ++dx) {
                for (int dy = -1; dy <= 1; ++dy) {
                    for (int dz = -1; dz <= 1; ++dz) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        class_2338 next = current.method_10069(dx, dy, dz);
                        if (visited.contains(next)) continue;
                        class_2680 nextState = world.method_8320(next);
                        if (isLog(nextState)) {
                            visited.add(next);
                            queue.add(next);
                        } else if (isLeaf(nextState)) {
                            leaves.add(next);
                        }
                    }
                }
            }
            class_2680 currentState = world.method_8320(current);
            if (isLog(currentState)) {
                class_2248 block = currentState.method_26204();
                miner.method_5775(new class_1799((class_1935)block, 1));
                world.method_8652(current, class_2246.field_10124.method_9564(), 3);
                ++logs;
            }
        }
        for (class_2338 leaf : leaves) {
            if (isLeaf(world.method_8320(leaf))) {
                world.method_8652(leaf, class_2246.field_10124.method_9564(), 3);
            }
        }
    }

    private static boolean isLog(class_2680 state) {
        String id = class_7923.field_41175.method_10221(state.method_26204()).toString();
        return id.endsWith("_log") || id.endsWith("_wood") || id.endsWith("_stem") || id.endsWith("_hyphae");
    }

    private static boolean isLeaf(class_2680 state) {
        String id = class_7923.field_41175.method_10221(state.method_26204()).toString();
        return id.endsWith("_leaves") || id.endsWith("_wart_block") || id.equals("minecraft:shroomlight");
    }

    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_axe.line1"));
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_tools.line1"));
    }
}
