package uz.echoes.item;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import uz.echoes.block.ModBlocks;
import net.minecraft.class_7923;
import net.minecraft.class_2960;
import net.minecraft.class_2680;
import net.minecraft.class_2338;
import net.minecraft.class_2248;
import net.minecraft.class_2246;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import uz.echoes.portal.EchoPortalTeleporter;
import uz.echoes.world.EchoArenaFixer;
import uz.echoes.world.EchoDimensionKeys;
import uz.echoes.world.EchoSpawnPlatform;

public class EchoFunctionalItem extends class_1792 {
    public enum Mode {
        SILENT_PEARL,
        ANCIENT_RIB_BONE,
        SCULK_BINDER_EYE,
        VOID_STALKER_PEARL,
        ECHO_GATE_SIGIL
    }

    private final Mode mode;

    public EchoFunctionalItem(Mode mode, class_1792.class_1793 settings) {
        super(settings);
        this.mode = mode;
    }

    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (this.mode == Mode.ECHO_GATE_SIGIL) {
            return this.useGateSigil(world, player, stack);
        }

        // Ancient Rib Bone is a real food item. Let vanilla start the eating
        // pipeline so other food/bow/projectile use timings are not copied or
        // broken by this custom utility item class.
        if (this.mode == Mode.ANCIENT_RIB_BONE) {
            return super.method_7836(world, player, hand);
        }

        if (!world.method_8608()) {
            this.activateServer(world, player);
            if (!player.method_7337()) {
                stack.method_7934(1);
            }
        }
        return class_1271.method_29237(stack, world.method_8608());
    }

    public class_1269 method_7884(class_1838 context) {
        if (this.mode != Mode.ECHO_GATE_SIGIL) {
            return super.method_7884(context);
        }

        class_1937 world = context.method_8045();
        if (world.method_8608()) {
            return class_1269.field_5812;
        }

        class_1657 player = context.method_8036();
        if (player instanceof class_3222) {
            boolean accepted = EchoPortalTeleporter.requestSigilTravel((class_3222)player);
            return accepted ? class_1269.field_5812 : class_1269.field_5811;
        }
        return class_1269.field_5811;
    }

    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        class_1799 result = super.method_7861(stack, world, user);
        if (!world.method_8608() && this.mode == Mode.ANCIENT_RIB_BONE && user instanceof class_1657) {
            class_1657 player = (class_1657)user;
            player.method_6033(Math.min(player.method_6063(), player.method_6032() + 8.0f));
            player.method_6092(new class_1293(class_1294.field_5907, 180, 1, true, false, true));
        }
        return result;
    }

    private class_1271<class_1799> useGateSigil(class_1937 world, class_1657 player, class_1799 stack) {
        if (world.method_8608()) {
            return class_1271.method_29237(stack, true);
        }

        if (player instanceof class_3222) {
            boolean accepted = EchoPortalTeleporter.requestSigilTravel((class_3222)player);
            // Gate Sigil is a key-style travel item now. Do not shrink it here;
            // otherwise the same sigil cannot be used to return from Echo Dimension.
            return accepted ? class_1271.method_29237(stack, false) : class_1271.method_22431(stack);
        }

        return class_1271.method_22431(stack);
    }

    public void activateServer(class_1937 world, class_1657 player) {
        switch (this.mode) {
            case SILENT_PEARL:
                this.blink(player, 16.0, 0.0);
                break;
            case VOID_STALKER_PEARL:
                this.blink(player, -8.0, 8.0);
                player.method_6092(new class_1293(class_1294.field_5919, 120, 0, true, false, true));
                break;
            case SCULK_BINDER_EYE:
                if (world.method_27983().equals(EchoDimensionKeys.ECHO_DIMENSION) && world instanceof class_3218) {
                    this.bindEchoDimensionSculk((class_3218)world, player);
                } else {
                    player.method_6092(new class_1293(class_1294.field_5916, 220, 0, true, false, true));
                    player.method_6092(new class_1293(class_1294.field_38092, 160, 0, true, false, true));
                }
                break;
            case ANCIENT_RIB_BONE:
            case ECHO_GATE_SIGIL:
                // Handled by vanilla food flow or Gate Sigil travel methods.
                break;
        }

        if (this.mode == Mode.VOID_STALKER_PEARL && player instanceof class_3222 && world.method_27983().equals(EchoDimensionKeys.ECHO_DIMENSION)) {
            class_3222 serverPlayer = (class_3222)player;
            serverPlayer.method_14251(
                    serverPlayer.method_51469(),
                    (double)EchoArenaFixer.PLAYER_BRIDGE_SPAWN.method_10263() + 0.5,
                    (double)EchoSpawnPlatform.createPlatform(serverPlayer.method_51469(), EchoArenaFixer.PLAYER_BRIDGE_SPAWN).method_10264(),
                    (double)EchoArenaFixer.PLAYER_BRIDGE_SPAWN.method_10260() + 0.5,
                    player.method_36454(),
                    0.0f
            );
        }
    }


    private void bindEchoDimensionSculk(class_3218 world, class_1657 player) {
        class_2338 center = player.method_24515();
        int placed = 0;
        for (int dx = -4; dx <= 4 && placed < 10; ++dx) {
            for (int dz = -4; dz <= 4 && placed < 10; ++dz) {
                class_2338 pos = center.method_10069(dx, -1, dz);
                class_2680 state = world.method_8320(pos);
                if (state.method_27852(block("sculk")) || state.method_27852(block("sculk_sensor")) || state.method_27852(block("sculk_catalyst"))) {
                    world.method_8652(pos.method_10084(), ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564(), 3);
                    ++placed;
                }
            }
        }
        class_2338 altarSeed = center.method_10069(0, -1, 0);
        if (world.method_8320(altarSeed).method_27852(block("sculk"))) {
            world.method_8652(altarSeed, ModBlocks.SCULK_REINFORCED_STONE.method_9564(), 3);
        }
    }

    private static class_2248 block(String id) {
        return (class_2248)class_7923.field_41175.method_10223(class_2960.method_60655((String)"minecraft", (String)id));
    }

    private void blink(class_1657 player, double distance, double yOffset) {
        double yawRadians = Math.toRadians((double)player.method_36454());
        double x = player.method_23317() - Math.sin(yawRadians) * distance;
        double z = player.method_23321() + Math.cos(yawRadians) * distance;
        double y = player.method_23318() + yOffset;

        if (player instanceof class_3222) {
            class_3222 serverPlayer = (class_3222)player;
            class_3218 serverWorld = serverPlayer.method_51469();
            serverPlayer.method_14251(serverWorld, x, y, z, player.method_36454(), player.method_36455());
        } else {
            player.method_5808(x, y, z, player.method_36454(), player.method_36455());
        }
        player.method_6073(0.0f);
    }

    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471(this.tooltipKey()));
    }

    private String tooltipKey() {
        switch (this.mode) {
            case SILENT_PEARL:
                return "tooltip.eovs32.silent_pearl.line1";
            case ANCIENT_RIB_BONE:
                return "tooltip.eovs32.ancient_rib_bone.line1";
            case SCULK_BINDER_EYE:
                return "tooltip.eovs32.sculk_binder_eye.line1";
            case VOID_STALKER_PEARL:
                return "tooltip.eovs32.void_stalker_pearl.line1";
            case ECHO_GATE_SIGIL:
                return "tooltip.eovs32.echo_gate_sigil.line1";
            default:
                return "tooltip.eovs32.echo_book.line2";
        }
    }
}
