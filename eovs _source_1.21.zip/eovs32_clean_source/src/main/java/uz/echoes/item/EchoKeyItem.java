/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1269
 *  net.minecraft.class_1792
 *  net.minecraft.class_1792$class_1793
 *  net.minecraft.class_1838
 *  net.minecraft.class_1937
 *  net.minecraft.class_3218
 */
package uz.echoes.item;

import java.util.List;

import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import uz.echoes.world.EchoDimensionKeys;
import net.minecraft.class_2561;
import net.minecraft.class_1836;
import net.minecraft.class_1799;
import uz.echoes.portal.EchoPortalFrameFiller;

public class EchoKeyItem
extends class_1792 {
    public EchoKeyItem(class_1792.class_1793 class_17932) {
        super(class_17932);
    }

    public class_1269 method_7884(class_1838 class_18382) {
        if (class_18382.method_8045().field_9236) {
            return class_1269.field_5812;
        }
        class_1937 class_19372 = class_18382.method_8045();
        if (class_19372.method_27983().equals(EchoDimensionKeys.ECHO_DIMENSION)) {
            return class_1269.field_5811;
        }
        if (class_19372 instanceof class_3218) {
            class_3218 class_32182 = (class_3218)class_19372;
            boolean bl = EchoPortalFrameFiller.tryOpenPortal(class_32182, class_18382.method_8037());
            return bl ? class_1269.field_5812 : class_1269.field_5811;
        }
        return class_1269.field_5811;
    }

    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_key.line1"));
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_key.line2"));
    }

}

