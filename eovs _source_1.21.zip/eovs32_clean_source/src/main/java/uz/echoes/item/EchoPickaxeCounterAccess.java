package uz.echoes.item;

public interface EchoPickaxeCounterAccess {
    int eovs32$getEchoPickaxeMinedCount();
    void eovs32$setEchoPickaxeMinedCount(int count);

    default int eovs32$incrementEchoPickaxeMinedCount() {
        int next = this.eovs32$getEchoPickaxeMinedCount() + 1;
        this.eovs32$setEchoPickaxeMinedCount(next);
        return next;
    }
}
