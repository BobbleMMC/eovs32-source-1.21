/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1792
 *  net.minecraft.class_1792$class_1793
 */
package uz.echoes.item;

import net.minecraft.class_1792;

public class EchoCoreItem
extends class_1792 {
    public EchoCoreItem(class_1792.class_1793 class_17932) {
        super(class_17932);
    }
}

