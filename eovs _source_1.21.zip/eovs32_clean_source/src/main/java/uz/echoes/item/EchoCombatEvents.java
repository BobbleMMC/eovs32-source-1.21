package uz.echoes.item;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3966;

public final class EchoCombatEvents {
    private static final int ECHO_SWORD_EFFECT_TICKS = 100;

    private EchoCombatEvents() {
    }

    public static void register() {
        AttackEntityCallback.EVENT.register((class_16572, class_19372, class_12682, class_12972, class_39662) -> EchoCombatEvents.onAttack(class_16572, class_19372, class_12682, class_12972, class_39662));
    }

    private static class_1269 onAttack(class_1657 player, class_1937 world, class_1268 hand, class_1297 entity, class_3966 hitResult) {
        if (world.method_8608() || !(entity instanceof class_1309)) {
            return class_1269.field_5811;
        }
        class_1799 stack = player.method_5998(hand);
        if (!stack.method_31574(ModItems.ECHO_SWORD)) {
            return class_1269.field_5811;
        }
        class_1309 target = (class_1309)entity;
        if (!target.method_5805() || target instanceof class_1657) {
            return class_1269.field_5811;
        }
        target.method_6092(new class_1293(class_1294.field_38092, ECHO_SWORD_EFFECT_TICKS, 0, true, true, true));
        return class_1269.field_5811;
    }
}
