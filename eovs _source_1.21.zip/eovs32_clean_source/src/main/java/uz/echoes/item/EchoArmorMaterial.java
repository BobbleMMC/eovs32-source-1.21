/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1304
 *  net.minecraft.class_1309
 *  net.minecraft.class_1738$class_8051
 *  net.minecraft.class_1741
 *  net.minecraft.class_1741$class_9196
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1856
 *  net.minecraft.class_1935
 *  net.minecraft.class_2378
 *  net.minecraft.class_2960
 *  net.minecraft.class_3417
 *  net.minecraft.class_6880
 *  net.minecraft.class_7923
 */
package uz.echoes.item;

import java.util.EnumMap;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import uz.echoes.item.ModItems;

public final class EchoArmorMaterial {
    public static final class_6880<class_1741> MATERIAL = EchoArmorMaterial.register();

    private EchoArmorMaterial() {
    }

    private static class_6880<class_1741> register() {
        EnumMap<class_1738.class_8051, Integer> enumMap = new EnumMap<class_1738.class_8051, Integer>(class_1738.class_8051.class);
        enumMap.put(class_1738.class_8051.field_41934, 5);
        enumMap.put(class_1738.class_8051.field_41935, 10);
        enumMap.put(class_1738.class_8051.field_41936, 8);
        enumMap.put(class_1738.class_8051.field_41937, 5);
        enumMap.put(class_1738.class_8051.field_48838, 12);
        class_1741 class_17412 = new class_1741(enumMap, 22, class_3417.field_21866, () -> class_1856.method_8091((class_1935[])new class_1935[]{ModItems.ECHOENERGY_STONE}), List.of(new class_1741.class_9196(class_2960.method_60655((String)"eovs32", (String)"echo"))), 4.5f, 0.2f);
        return class_2378.method_47985((class_2378)class_7923.field_48976, (class_2960)class_2960.method_60655((String)"eovs32", (String)"echo"), (Object)class_17412);
    }

    public static boolean hasFullEchoArmor(class_1309 class_13092) {
        return EchoArmorMaterial.isEcho(class_13092.method_6118(class_1304.field_6169), ModItems.ECHO_HELMET) && EchoArmorMaterial.isEcho(class_13092.method_6118(class_1304.field_6174), ModItems.ECHO_CHESTPLATE) && EchoArmorMaterial.isEcho(class_13092.method_6118(class_1304.field_6172), ModItems.ECHO_LEGGINGS) && EchoArmorMaterial.isEcho(class_13092.method_6118(class_1304.field_6166), ModItems.ECHO_BOOTS);
    }

    private static boolean isEcho(class_1799 class_17992, class_1792 class_17922) {
        return class_17992 != null && class_17992.method_31574(class_17922);
    }
}

