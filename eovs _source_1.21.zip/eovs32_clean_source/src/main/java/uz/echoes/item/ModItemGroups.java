/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup
 *  net.minecraft.class_1761
 *  net.minecraft.class_1799
 *  net.minecraft.class_1935
 *  net.minecraft.class_2378
 *  net.minecraft.class_2561
 *  net.minecraft.class_2960
 *  net.minecraft.class_7923
 */
package uz.echoes.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import uz.echoes.EchoesMod;
import uz.echoes.item.ModItems;

public final class ModItemGroups {
    public static final class_1761 ECHO_GROUP = (class_1761)class_2378.method_10230((class_2378)class_7923.field_44687, (class_2960)class_2960.method_60655((String)"eovs32", (String)"echo_group"), (Object)FabricItemGroup.builder().method_47321((class_2561)class_2561.method_43471((String)"itemGroup.eovs32.echo_group")).method_47320(() -> new class_1799((class_1935)ModItems.ECHO_CORE)).method_47317((class_81282, class_77042) -> {
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_KEY));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_WARDEN_HEART));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_CORE));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_FRAGMENT));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHOENERGY_STONE));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_CRYSTAL_SHARD));
        class_77042.method_45420(new class_1799((class_1935)ModItems.SILENT_PEARL));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ANCIENT_RIB_BONE));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_SENTINEL_CORE));
        class_77042.method_45420(new class_1799((class_1935)ModItems.SCULK_BINDER_EYE));
        class_77042.method_45420(new class_1799((class_1935)ModItems.VOID_STALKER_PEARL));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_GATE_SIGIL));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_PROTECTOR_STAFF));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_PROTECTOR_BLOCK_ITEM));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_ALTAR_ITEM));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_CRYSTAL_BLOCK_ITEM));
        class_77042.method_45420(new class_1799((class_1935)ModItems.VOID_GLASS_ITEM));
        class_77042.method_45420(new class_1799((class_1935)ModItems.DORMANT_ANCHOR_ITEM));
        class_77042.method_45420(new class_1799((class_1935)ModItems.SCULK_REINFORCED_STONE_ITEM));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_ORE_ITEM));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_SWORD));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_PICKAXE));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_SHOVEL));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_HOE));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_AXE));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_HELMET));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_CHESTPLATE));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_LEGGINGS));
        class_77042.method_45420(new class_1799((class_1935)ModItems.ECHO_BOOTS));
    }).method_47324());

    private ModItemGroups() {
    }

    public static void register() {
        EchoesMod.LOGGER.info("Registering Echo item group");
    }
}
