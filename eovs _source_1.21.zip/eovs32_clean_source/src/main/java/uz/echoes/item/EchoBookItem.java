/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1271
 *  net.minecraft.class_1657
 *  net.minecraft.class_1792
 *  net.minecraft.class_1792$class_1793
 *  net.minecraft.class_1792$class_9635
 *  net.minecraft.class_1799
 *  net.minecraft.class_1836
 *  net.minecraft.class_1937
 *  net.minecraft.class_2561
 */
package uz.echoes.item;

import java.lang.reflect.Method;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import uz.echoes.EchoesMod;

public class EchoBookItem
extends class_1792 {
    private static boolean warnedPatchouliOpenFailure = false;
    private static boolean warnedFallbackScreenFailure = false;
    public EchoBookItem(class_1792.class_1793 class_17932) {
        super(class_17932);
    }

    public class_1271<class_1799> method_7836(class_1937 class_19372, class_1657 class_16572, class_1268 class_12682) {
        class_1799 class_17992 = class_16572.method_5998(class_12682);
        if (class_19372.method_8608()) {
            EchoBookItem.openClientGuideSafely();
            return class_1271.method_22427(class_17992);
        }
        return class_1271.method_22427(class_17992);
    }

    public static void openClientGuideSafely() {
        if (EchoBookItem.openPatchouliBookSafely()) {
            return;
        }
        try {
            Class<?> clazz = Class.forName("uz.echoes.client.gui.EchoBookScreen");
            Method method = clazz.getDeclaredMethod("open", new Class[0]);
            method.invoke(null, new Object[0]);
        } catch (Throwable throwable) {
            if (!warnedFallbackScreenFailure) {
                warnedFallbackScreenFailure = true;
                EchoesMod.LOGGER.warn("Echo Book fallback GUI could not be opened. Patchouli may be absent and fallback screen failed.", throwable);
            }
        }
    }

    private static boolean openPatchouliBookSafely() {
        class_2960 bookId = class_2960.method_60655((String)"eovs32", (String)"echo_book");
        try {
            Class<?> clazz = Class.forName("vazkii.patchouli.api.PatchouliAPI");
            Object api = clazz.getMethod("get", new Class[0]).invoke(null, new Object[0]);

            for (Method method : api.getClass().getMethods()) {
                if (method.getName().equals("openBookGUI") && method.getParameterCount() == 1) {
                    Class<?> parameter = method.getParameterTypes()[0];
                    if (parameter.isAssignableFrom(class_2960.class) || parameter.getName().equals("net.minecraft.class_2960")) {
                        method.invoke(api, bookId);
                        return true;
                    }
                }
            }

            for (Method method : clazz.getMethods()) {
                if (method.getName().equals("openBookGUI") && method.getParameterCount() == 1) {
                    Class<?> parameter = method.getParameterTypes()[0];
                    if (parameter.isAssignableFrom(class_2960.class) || parameter.getName().equals("net.minecraft.class_2960")) {
                        method.invoke(api, bookId);
                        return true;
                    }
                }
            }
        } catch (Throwable throwable) {
            if (!warnedPatchouliOpenFailure) {
                warnedPatchouliOpenFailure = true;
                EchoesMod.LOGGER.info("Patchouli is unavailable or incompatible; using built-in Echo Book fallback GUI.");
            }
            return false;
        }
        return false;
    }

    public void method_7851(class_1799 class_17992, class_1792.class_9635 class_96352, List<class_2561> list, class_1836 class_18362) {
        list.add((class_2561)class_2561.method_43471((String)"tooltip.eovs32.echo_book.line1"));
        list.add((class_2561)class_2561.method_43471((String)"tooltip.eovs32.echo_book.line2"));
    }
}
