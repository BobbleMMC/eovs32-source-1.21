/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1738
 *  net.minecraft.class_1738$class_8051
 *  net.minecraft.class_1743
 *  net.minecraft.class_1747
 *  net.minecraft.class_1766
 *  net.minecraft.class_1792
 *  net.minecraft.class_1792$class_1793
 *  net.minecraft.class_1794
 *  net.minecraft.class_1810
 *  net.minecraft.class_1821
 *  net.minecraft.class_1829
 *  net.minecraft.class_1832
 *  net.minecraft.class_2378
 *  net.minecraft.class_2960
 *  net.minecraft.class_7923
 */
package uz.echoes.item;

import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1747;
import net.minecraft.class_1766;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_2378;
import net.minecraft.class_4174;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import uz.echoes.EchoesMod;
import uz.echoes.block.ModBlocks;
import uz.echoes.item.EchoArmorMaterial;
import uz.echoes.item.EchoBookItem;
import uz.echoes.item.EchoFunctionalItem;
import uz.echoes.item.EchoKeyItem;
import uz.echoes.item.EchoPickaxeItem;
import uz.echoes.item.EchoToolMaterial;
import uz.echoes.item.SoulProtectorItem;

public final class ModItems {
    public static final class_1792 ECHO_WARDEN_HEART = ModItems.register("echo_warden_heart", new class_1792(new class_1792.class_1793().method_7889(16)));
    public static final class_1792 ECHO_CORE = ModItems.register("echo_core", new class_1792(new class_1792.class_1793().method_7889(16)));
    public static final class_1792 ECHO_BOOK = ModItems.register("echo_book", new EchoBookItem(new class_1792.class_1793().method_7889(1)));
    public static final class_1792 ECHO_KEY = ModItems.register("echo_key", new EchoKeyItem(new class_1792.class_1793().method_7889(1)));
    public static final class_1792 ECHO_PROTECTOR_STAFF = ModItems.register("echo_protector_staff", new SoulProtectorItem(new class_1792.class_1793().method_7889(1)));
    /** Deprecated compatibility item id; new content should use echo_protector_staff. */
    @Deprecated
    public static final class_1792 SOUL_PROTECTOR = ModItems.register("soul_protector", new SoulProtectorItem(new class_1792.class_1793().method_7889(1)));
    public static final class_1792 ECHO_ALTAR_ITEM = ModItems.register("echo_altar", (class_1792)new EchoBlockItem(ModBlocks.ECHO_ALTAR, new class_1792.class_1793().method_7889(1), "tooltip.eovs32.echo_altar.line1", "tooltip.eovs32.echo_altar.line2"));
    public static final class_1792 ECHO_PROTECTOR_BLOCK_ITEM = ModItems.register("echo_protector_block", (class_1792)new EchoBlockItem(ModBlocks.ECHO_PROTECTOR_BLOCK, new class_1792.class_1793().method_7889(16), "tooltip.eovs32.echo_protector_block.line1", "tooltip.eovs32.echo_protector_block.line2"));
    /** Deprecated compatibility item id; new content should use echo_protector_block. */
    @Deprecated
    public static final class_1792 SOUL_PROTECTOR_BLOCK_ITEM = ModItems.register("soul_protector_block", (class_1792)new EchoBlockItem(ModBlocks.SOUL_PROTECTOR_BLOCK, new class_1792.class_1793().method_7889(16), "tooltip.eovs32.echo_protector_block.line1", "tooltip.eovs32.echo_protector_block.line2"));
    public static final class_1792 ECHO_CRYSTAL_BLOCK_ITEM = ModItems.register("echo_crystal_block", (class_1792)new EchoBlockItem(ModBlocks.ECHO_CRYSTAL_BLOCK, new class_1792.class_1793().method_7889(64), "tooltip.eovs32.echo_crystal_block.line1", "tooltip.eovs32.echo_crystal_block.line2"));
    public static final class_1792 VOID_GLASS_ITEM = ModItems.register("void_glass", (class_1792)new EchoBlockItem(ModBlocks.VOID_GLASS, new class_1792.class_1793().method_7889(64), "tooltip.eovs32.void_glass.line1", "tooltip.eovs32.void_glass.line2"));
    public static final class_1792 DORMANT_ANCHOR_ITEM = ModItems.register("dormant_anchor", (class_1792)new EchoBlockItem(ModBlocks.DORMANT_ANCHOR, new class_1792.class_1793().method_7889(16), "tooltip.eovs32.dormant_anchor.line1"));
    public static final class_1792 SCULK_REINFORCED_STONE_ITEM = ModItems.register("sculk_reinforced_stone", (class_1792)new class_1747(ModBlocks.SCULK_REINFORCED_STONE, new class_1792.class_1793().method_7889(64)));
    public static final class_1792 ECHO_ORE_ITEM = ModItems.register("echo_ore", (class_1792)new EchoBlockItem(ModBlocks.ECHO_ORE, new class_1792.class_1793().method_7889(64), "tooltip.eovs32.echo_ore.line1", "tooltip.eovs32.echo_ore.line2"));
    public static final class_1792 ECHOENERGY_STONE = ModItems.register("echoenergy_stone", new EchoEnergyStoneItem(new class_1792.class_1793().method_7889(16)));
    public static final class_1792 ECHO_FRAGMENT = ModItems.register("echo_fragment", new class_1792(new class_1792.class_1793().method_7889(16)));
    public static final class_1792 ECHO_CRYSTAL_SHARD = ModItems.register("echo_crystal_shard", new class_1792(new class_1792.class_1793().method_7889(64)));
    public static final class_1792 SILENT_PEARL = ModItems.register("silent_pearl", new EchoFunctionalItem(EchoFunctionalItem.Mode.SILENT_PEARL, new class_1792.class_1793().method_7889(16)));
    private static final class_4174 ANCIENT_RIB_BONE_FOOD = new class_4174(4, 0.6F, true, 1.6F, Optional.empty(), List.of());
    public static final class_1792 ANCIENT_RIB_BONE = ModItems.register("ancient_rib_bone", new EchoFunctionalItem(EchoFunctionalItem.Mode.ANCIENT_RIB_BONE, new class_1792.class_1793().method_7889(32).method_19265(ANCIENT_RIB_BONE_FOOD)));
    public static final class_1792 ECHO_SENTINEL_CORE = ModItems.register("echo_sentinel_core", new class_1792(new class_1792.class_1793().method_7889(16)));
    public static final class_1792 SCULK_BINDER_EYE = ModItems.register("sculk_binder_eye", new EchoFunctionalItem(EchoFunctionalItem.Mode.SCULK_BINDER_EYE, new class_1792.class_1793().method_7889(16)));
    public static final class_1792 VOID_STALKER_PEARL = ModItems.register("void_stalker_pearl", new EchoFunctionalItem(EchoFunctionalItem.Mode.VOID_STALKER_PEARL, new class_1792.class_1793().method_7889(16)));
    public static final class_1792 ECHO_GATE_SIGIL = ModItems.register("echo_gate_sigil", new EchoFunctionalItem(EchoFunctionalItem.Mode.ECHO_GATE_SIGIL, new class_1792.class_1793().method_7889(1)));
    public static final class_1792 ECHO_SWORD = ModItems.register("echo_sword", (class_1792)new EchoSwordItem((class_1832)EchoToolMaterial.INSTANCE, new class_1792.class_1793().method_57348(class_1829.method_57394((class_1832)EchoToolMaterial.INSTANCE, (int)5, (float)-2.2f))));
    public static final class_1792 ECHO_PICKAXE = ModItems.register("echo_pickaxe", (class_1792)new EchoPickaxeItem((class_1832)EchoToolMaterial.INSTANCE, new class_1792.class_1793().method_57348(class_1766.method_57346((class_1832)EchoToolMaterial.INSTANCE, (float)2.0f, (float)-2.6f))));
    public static final class_1792 ECHO_SHOVEL = ModItems.register("echo_shovel", (class_1792)new EchoShovelItem((class_1832)EchoToolMaterial.INSTANCE, new class_1792.class_1793().method_57348(class_1766.method_57346((class_1832)EchoToolMaterial.INSTANCE, (float)2.5f, (float)-2.8f))));
    public static final class_1792 ECHO_HOE = ModItems.register("echo_hoe", (class_1792)new EchoHoeItem((class_1832)EchoToolMaterial.INSTANCE, new class_1792.class_1793().method_57348(class_1766.method_57346((class_1832)EchoToolMaterial.INSTANCE, (float)0.0f, (float)0.0f))));
    public static final class_1792 ECHO_AXE = ModItems.register("echo_axe", (class_1792)new EchoAxeItem((class_1832)EchoToolMaterial.INSTANCE, new class_1792.class_1793().method_57348(class_1766.method_57346((class_1832)EchoToolMaterial.INSTANCE, (float)7.0f, (float)-2.9f))));
    public static final class_1792 ECHO_HELMET = ModItems.register("echo_helmet", (class_1792)new class_1738(EchoArmorMaterial.MATERIAL, class_1738.class_8051.field_41934, new class_1792.class_1793().method_7889(1)));
    public static final class_1792 ECHO_CHESTPLATE = ModItems.register("echo_chestplate", (class_1792)new class_1738(EchoArmorMaterial.MATERIAL, class_1738.class_8051.field_41935, new class_1792.class_1793().method_7889(1)));
    public static final class_1792 ECHO_LEGGINGS = ModItems.register("echo_leggings", (class_1792)new class_1738(EchoArmorMaterial.MATERIAL, class_1738.class_8051.field_41936, new class_1792.class_1793().method_7889(1)));
    public static final class_1792 ECHO_BOOTS = ModItems.register("echo_boots", (class_1792)new class_1738(EchoArmorMaterial.MATERIAL, class_1738.class_8051.field_41937, new class_1792.class_1793().method_7889(1)));

    private ModItems() {
    }

    private static class_1792 register(String string, class_1792 class_17922) {
        return (class_1792)class_2378.method_10230((class_2378)class_7923.field_41178, (class_2960)class_2960.method_60655((String)"eovs32", (String)string), (Object)class_17922);
    }

    public static void register() {
        EchoesMod.LOGGER.info("Registering Echo items");
    }
}
