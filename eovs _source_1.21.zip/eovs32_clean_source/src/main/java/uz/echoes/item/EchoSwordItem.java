package uz.echoes.item;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

public class EchoSwordItem extends class_1829 {
    public EchoSwordItem(class_1832 material, class_1792.class_1793 settings) {
        super(material, settings);
    }

    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_sword.line1"));
        tooltip.add(class_2561.method_43471("tooltip.eovs32.echo_tools.line1"));
    }
}
