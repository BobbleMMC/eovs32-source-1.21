/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1937
 *  net.minecraft.class_1937$class_7867
 *  net.minecraft.class_2338
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_3218
 *  net.minecraft.class_3419
 */
package uz.echoes.boss;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import uz.echoes.boss.EchoBossDelayedTasks;
import uz.echoes.sound.ModSounds;

public final class EchoBossDeathFinisher {
    private static final int DEATH_ANIMATION_TICKS = 50;
    private static final float EXPLOSION_POWER = 6.0f;

    private EchoBossDeathFinisher() {
    }

    public static void start(class_1309 class_13092) {
        class_1937 class_19372 = class_13092.method_37908();
        if (!(class_19372 instanceof class_3218)) {
            return;
        }
        class_3218 class_32182 = (class_3218)class_19372;
        class_2338 class_23382 = class_13092.method_24515();
        double d = class_13092.method_23317();
        double d2 = class_13092.method_23318();
        double d3 = class_13092.method_23321();
        EchoBossDelayedTasks.runLater(class_32182, 50, () -> {
            class_32182.method_8396(null, class_23382, ModSounds.ECHO_BOSS_DEATH_ULTRA_BASS, class_3419.field_15251, 5.0f, 0.85f);
            class_32182.method_14199((class_2394)class_2398.field_38908, d, d2 + 1.2, d3, 1, 0.0, 0.0, 0.0, 0.0);
            class_32182.method_14199((class_2394)class_2398.field_38002, d, d2 + 1.0, d3, 120, 2.5, 1.5, 2.5, 0.08);
            class_32182.method_14199((class_2394)class_2398.field_11236, d, d2 + 1.0, d3, 6, 1.2, 0.8, 1.2, 0.0);
            class_32182.method_8437((class_1297)class_13092, d, d2 + 0.5, d3, 6.0f, class_1937.class_7867.field_40890);
        });
    }
}

