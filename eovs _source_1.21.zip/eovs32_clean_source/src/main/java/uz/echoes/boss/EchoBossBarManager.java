/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_1259$class_1260
 *  net.minecraft.class_1259$class_1261
 *  net.minecraft.class_2561
 *  net.minecraft.class_3213
 */
package uz.echoes.boss;

import net.minecraft.class_124;
import net.minecraft.class_1259;
import net.minecraft.class_2561;
import net.minecraft.class_3213;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossBarManager {
    private EchoBossBarManager() {
    }

    public static class_3213 attachBossBar(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        class_3213 class_32132 = new class_3213((class_2561)class_2561.method_43470((String)"Echo Warden Monarch").method_27692(class_124.field_1062), class_1259.class_1260.field_5780, class_1259.class_1261.field_5795);
        class_32132.method_5408(1.0f);
        return class_32132;
    }
}

