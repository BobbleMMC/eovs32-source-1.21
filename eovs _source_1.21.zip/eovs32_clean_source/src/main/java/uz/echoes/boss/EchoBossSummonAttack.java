/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1588
 *  net.minecraft.class_1937
 *  net.minecraft.class_2338
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_3218
 *  net.minecraft.class_3417
 *  net.minecraft.class_3730
 *  net.minecraft.class_5425
 */
package uz.echoes.boss;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossSummonAttack {
    private EchoBossSummonAttack() {
    }

    public static void cast(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity) {
        int n = echoWardenMonarchEntity.getEchoPhase();
        int n2 = n == 3 ? 4 : 2;
        echoWardenMonarchEntity.method_5783(class_3417.field_38075, 2.5f, 0.75f);
        for (int i = 0; i < n2; ++i) {
            double d = Math.PI * 2 / (double)n2 * (double)i + class_32182.field_9229.method_43058() * 0.7;
            double d2 = 5.0 + class_32182.field_9229.method_43058() * 5.0;
            class_2338 class_23382 = class_2338.method_49637((double)(echoWardenMonarchEntity.method_23317() + Math.cos(d) * d2), (double)echoWardenMonarchEntity.method_23318(), (double)(echoWardenMonarchEntity.method_23321() + Math.sin(d) * d2));
            class_1588 class_15882 = EchoBossSummonAttack.createSummon(class_32182, n);
            if (class_15882 == null) continue;
            class_15882.method_5808((double)class_23382.method_10263() + 0.5, (double)class_23382.method_10264() + 1.0, (double)class_23382.method_10260() + 0.5, class_32182.field_9229.method_43057() * 360.0f, 0.0f);
            class_15882.method_5943((class_5425)class_32182, class_32182.method_8404(class_23382), class_3730.field_16471, null);
            class_32182.method_8649((class_1297)class_15882);
            class_32182.method_14199((class_2394)class_2398.field_38002, (double)class_23382.method_10263() + 0.5, (double)class_23382.method_10264() + 1.2, (double)class_23382.method_10260() + 0.5, 20, 0.4, 0.7, 0.4, 0.05);
        }
    }

    private static class_1588 createSummon(class_3218 class_32182, int n) {
        if (n >= 3 && class_32182.field_9229.method_43056()) {
            return (class_1588)class_1299.field_38095.method_5883((class_1937)class_32182);
        }
        if (class_32182.field_9229.method_43056()) {
            return (class_1588)class_1299.field_6051.method_5883((class_1937)class_32182);
        }
        return (class_1588)class_1299.field_6137.method_5883((class_1937)class_32182);
    }
}

