/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1937
 *  net.minecraft.class_3218
 */
package uz.echoes.boss;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import uz.echoes.boss.EchoBossAdaptiveBrain;
import uz.echoes.boss.EchoBossCooldowns;
import uz.echoes.boss.EchoBossDarkPulseAttack;
import uz.echoes.boss.EchoBossScreenShake;
import uz.echoes.boss.EchoBossSculkSpikeAttack;
import uz.echoes.boss.EchoBossSonicAttack;
import uz.echoes.boss.EchoBossStompAttack;
import uz.echoes.boss.EchoBossTargeting;
import uz.echoes.boss.EchoBossTeleportAttack;
import uz.echoes.boss.EchoBossVfxSync;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossAttackController {
    private EchoBossAttackController() {
    }

    public static void tickBossAttacks(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        class_3218 class_32182;
        class_1937 class_19372;
        block13: {
            block12: {
                class_19372 = echoWardenMonarchEntity.method_37908();
                if (!(class_19372 instanceof class_3218)) break block12;
                class_32182 = (class_3218)class_19372;
                if (echoWardenMonarchEntity.method_5805()) break block13;
            }
            return;
        }
        EchoBossCooldowns.tick(echoWardenMonarchEntity);
        class_1309 target = EchoBossTargeting.findTarget(echoWardenMonarchEntity, 96.0);
        if (target == null) {
            return;
        }
        double d = echoWardenMonarchEntity.method_5858((class_1297)target);
        int n = echoWardenMonarchEntity.getEchoPhase();
        EchoBossAdaptiveBrain.Preference preference = EchoBossAdaptiveBrain.observe(echoWardenMonarchEntity, target);
        if (preference == EchoBossAdaptiveBrain.Preference.PUNISH_VERTICAL && EchoBossAttackController.trySonic(class_32182, echoWardenMonarchEntity, target, n, d, 0.82)) {
            return;
        }
        if (preference == EchoBossAdaptiveBrain.Preference.PUNISH_DISTANCE && EchoBossAttackController.tryTeleport(class_32182, echoWardenMonarchEntity, target, n, d, 0.72)) {
            return;
        }
        if (preference == EchoBossAdaptiveBrain.Preference.PUNISH_CLOSE && EchoBossAttackController.tryStomp(class_32182, echoWardenMonarchEntity, target, n, d, 1.0)) {
            return;
        }
        if (preference == EchoBossAdaptiveBrain.Preference.MIX_UP && EchoBossAttackController.tryDarkPulse(class_32182, echoWardenMonarchEntity, target, n, d)) {
            return;
        }
        if (EchoBossAttackController.tryStomp(class_32182, echoWardenMonarchEntity, target, n, d, 1.0)) {
            return;
        }
        if (EchoBossAttackController.trySonic(class_32182, echoWardenMonarchEntity, target, n, d, 1.0)) {
            return;
        }
        if (EchoBossAttackController.tryTeleport(class_32182, echoWardenMonarchEntity, target, n, d, 1.0)) {
            return;
        }
        if (EchoBossAttackController.trySpikes(class_32182, echoWardenMonarchEntity, target, n)) {
            return;
        }
        EchoBossAttackController.tryDarkPulse(class_32182, echoWardenMonarchEntity, target, n, d);
    }

    private static boolean tryStomp(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity, class_1309 class_13092, int n, double d, double d2) {
        if (d > 110.25 || !EchoBossCooldowns.readyStomp(echoWardenMonarchEntity)) {
            return false;
        }
        if (EchoBossAdaptiveBrain.recentlyUsed(echoWardenMonarchEntity, EchoBossVfxSync.Ability.STOMP, 35)) {
            return false;
        }
        EchoBossVfxSync.play(class_32182, echoWardenMonarchEntity, EchoBossVfxSync.Ability.STOMP, class_13092);
        EchoBossStompAttack.cast(class_32182, echoWardenMonarchEntity);
        EchoBossScreenShake.pulse(class_32182, echoWardenMonarchEntity, n == 3 ? 32.0 : 24.0, n == 3 ? 70 : 45, n == 3 ? 1 : 0);
        EchoBossCooldowns.resetStomp(echoWardenMonarchEntity, EchoBossAttackController.scaledCooldown(switch (n) {
            case 3 -> 50;
            case 2 -> 75;
            default -> 115;
        }, d2));
        EchoBossAdaptiveBrain.rememberCast(echoWardenMonarchEntity, EchoBossVfxSync.Ability.STOMP);
        return true;
    }

    private static boolean trySonic(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity, class_1309 class_13092, int n, double d, double d2) {
        if (d > 2304.0 || !EchoBossCooldowns.readySonic(echoWardenMonarchEntity)) {
            return false;
        }
        EchoBossVfxSync.play(class_32182, echoWardenMonarchEntity, EchoBossVfxSync.Ability.SONIC, class_13092);
        EchoBossSonicAttack.cast(class_32182, echoWardenMonarchEntity, class_13092);
        EchoBossCooldowns.resetSonic(echoWardenMonarchEntity, EchoBossAttackController.scaledCooldown(switch (n) {
            case 3 -> 120;
            case 2 -> 160;
            default -> 230;
        }, d2));
        EchoBossAdaptiveBrain.rememberCast(echoWardenMonarchEntity, EchoBossVfxSync.Ability.SONIC);
        return true;
    }

    private static boolean tryTeleport(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity, class_1309 class_13092, int n, double d, double d2) {
        if (n < 2 || d < 484.0 || !EchoBossCooldowns.readyTeleport(echoWardenMonarchEntity)) {
            return false;
        }
        if (!EchoBossTeleportAttack.cast(class_32182, echoWardenMonarchEntity, class_13092)) {
            EchoBossCooldowns.resetTeleport(echoWardenMonarchEntity, 40);
            return false;
        }
        EchoBossVfxSync.play(class_32182, echoWardenMonarchEntity, EchoBossVfxSync.Ability.TELEPORT, class_13092);
        EchoBossCooldowns.resetTeleport(echoWardenMonarchEntity, EchoBossAttackController.scaledCooldown(n == 3 ? 72 : 120, d2));
        EchoBossCooldowns.resetStomp(echoWardenMonarchEntity, 16);
        EchoBossAdaptiveBrain.rememberCast(echoWardenMonarchEntity, EchoBossVfxSync.Ability.TELEPORT);
        return true;
    }

    private static boolean trySpikes(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity, class_1309 class_13092, int n) {
        if (n < 2 || !EchoBossCooldowns.readySpikes(echoWardenMonarchEntity)) {
            return false;
        }
        EchoBossVfxSync.play(class_32182, echoWardenMonarchEntity, EchoBossVfxSync.Ability.SPIKES, class_13092);
        EchoBossSculkSpikeAttack.cast(class_32182, echoWardenMonarchEntity, class_13092);
        EchoBossCooldowns.resetSpikes(echoWardenMonarchEntity, n == 3 ? 78 : 125);
        EchoBossAdaptiveBrain.rememberCast(echoWardenMonarchEntity, EchoBossVfxSync.Ability.SPIKES);
        return true;
    }

    private static boolean tryDarkPulse(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity, class_1309 class_13092, int n, double d) {
        if (n != 3 || d > 784.0 || !EchoBossCooldowns.readyDarkPulse(echoWardenMonarchEntity)) {
            return false;
        }
        EchoBossVfxSync.play(class_32182, echoWardenMonarchEntity, EchoBossVfxSync.Ability.DARK_PULSE, class_13092);
        EchoBossDarkPulseAttack.cast(class_32182, echoWardenMonarchEntity);
        EchoBossScreenShake.pulse(class_32182, echoWardenMonarchEntity, 42.0, 90, 1);
        EchoBossCooldowns.resetDarkPulse(echoWardenMonarchEntity, 125);
        EchoBossAdaptiveBrain.rememberCast(echoWardenMonarchEntity, EchoBossVfxSync.Ability.DARK_PULSE);
        return true;
    }

    private static int scaledCooldown(int n, double d) {
        return Math.max(12, (int)Math.round((double)n * d));
    }
}

