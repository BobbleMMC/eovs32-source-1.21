/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_2561
 *  net.minecraft.class_3222
 */
package uz.echoes.boss;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossPhaseMessages {
    private EchoBossPhaseMessages() {
    }

    public static void sendPhaseMessage(class_3222 class_32222, EchoWardenMonarchEntity echoWardenMonarchEntity) {
        String string = switch (echoWardenMonarchEntity.getEchoPhase()) {
            case 3 -> "The Monarch is enraged!";
            case 2 -> "The Echo grows unstable...";
            default -> "The Monarch watches...";
        };
        class_32222.method_7353((class_2561)class_2561.method_43470((String)string).method_27692(class_124.field_1062), true);
    }
}

