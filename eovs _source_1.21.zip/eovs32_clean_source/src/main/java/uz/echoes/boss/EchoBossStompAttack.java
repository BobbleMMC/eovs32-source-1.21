/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_238
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_3218
 *  net.minecraft.class_3417
 */
package uz.echoes.boss;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossStompAttack {
    private EchoBossStompAttack() {
    }

    public static void cast(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity) {
        int n = echoWardenMonarchEntity.getEchoPhase();
        double d = n == 3 ? 16.0 : (n == 2 ? 12.5 : 9.0);
        echoWardenMonarchEntity.method_5783(class_3417.field_38064, 3.2f, n == 3 ? 0.55f : 0.7f);
        int particleCount = n == 3 ? 72 : 110 + n * 35;
        double particleSpread = n == 3 ? d * 0.32 : d * 0.45;
        class_32182.method_14199((class_2394)class_2398.field_38002, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 0.3, echoWardenMonarchEntity.method_23321(), particleCount, particleSpread, 0.12, particleSpread, n == 3 ? 0.055 : 0.085);
        class_238 class_2382 = echoWardenMonarchEntity.method_5829().method_1009(d, 3.0, d);
        for (class_1309 class_13093 : class_32182.method_8390(class_1309.class, class_2382, class_13092 -> class_13092.method_5805() && class_13092 != echoWardenMonarchEntity)) {
            if (!(class_13093.method_5858((class_1297)echoWardenMonarchEntity) <= d * d)) continue;
            class_13093.method_5643(class_32182.method_48963().method_48812((class_1309)echoWardenMonarchEntity), 12.0f + (float)n * 6.0f);
            class_13093.method_6005(1.4 + (double)n * 0.35, echoWardenMonarchEntity.method_23317() - class_13093.method_23317(), echoWardenMonarchEntity.method_23321() - class_13093.method_23321());
        }
    }
}

