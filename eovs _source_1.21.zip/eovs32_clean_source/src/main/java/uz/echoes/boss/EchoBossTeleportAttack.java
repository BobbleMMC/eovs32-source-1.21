/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_2338
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_3218
 *  net.minecraft.class_3417
 */
package uz.echoes.boss;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossTeleportAttack {
    private EchoBossTeleportAttack() {
    }

    public static boolean cast(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity, class_1309 class_13092) {
        if (class_32182 == null || echoWardenMonarchEntity == null || class_13092 == null || !echoWardenMonarchEntity.method_5805() || !class_13092.method_5805()) {
            return false;
        }
        try {
            class_2338 class_23382 = EchoBossTeleportAttack.findSafeTeleportPos(class_32182, echoWardenMonarchEntity, class_13092);
            if (class_23382 == null) {
                return false;
            }
            class_32182.method_14199((class_2394)class_2398.field_23114, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 2.2, echoWardenMonarchEntity.method_23321(), 4, 0.22, 0.35, 0.22, 0.006);
            boolean bl = echoWardenMonarchEntity.method_6082((double)class_23382.method_10263() + 0.5, class_23382.method_10264(), (double)class_23382.method_10260() + 0.5, true);
            if (!bl) {
                return false;
            }
            echoWardenMonarchEntity.method_5783(class_3417.field_14879, 1.2f, 0.55f);
            class_32182.method_14199((class_2394)class_2398.field_23114, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 2.2, echoWardenMonarchEntity.method_23321(), 6, 0.26, 0.45, 0.26, 0.006);
            return true;
        } catch (Throwable throwable) {
            return false;
        }
    }

    private static class_2338 findSafeTeleportPos(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity, class_1309 class_13092) {
        for (int i = 0; i < 8; ++i) {
            double d = class_32182.field_9229.method_43058() * Math.PI * 2.0;
            double d2 = 7.0 + class_32182.field_9229.method_43058() * 5.0;
            class_2338 class_23382 = class_2338.method_49637((double)(class_13092.method_23317() + Math.cos(d) * d2), (double)class_13092.method_23318(), (double)(class_13092.method_23321() + Math.sin(d) * d2));
            if (class_23382.method_10264() < 65 || class_23382.method_10264() > 130 || class_23382.method_10263() * class_23382.method_10263() + class_23382.method_10260() * class_23382.method_10260() > 1444 || !class_32182.method_19503(class_23382)) continue;
            for (int j = 3; j >= -4; --j) {
                class_2338 class_23383 = class_23382.method_10069(0, j, 0);
                if (echoWardenMonarchEntity.method_5858((class_1297)class_13092) < 64.0) {
                    return null;
                }
                if (class_32182.method_8320(class_23383.method_10074()).method_26215() || !class_32182.method_8320(class_23383).method_26215() || !class_32182.method_8320(class_23383.method_10084()).method_26215() || !class_32182.method_8320(class_23383.method_10086(2)).method_26215()) continue;
                return class_23383;
            }
        }
        return null;
    }
}

