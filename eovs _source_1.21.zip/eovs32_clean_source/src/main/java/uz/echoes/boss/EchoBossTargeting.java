/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1937
 *  net.minecraft.class_238
 *  net.minecraft.class_3218
 *  net.minecraft.class_3222
 *  net.minecraft.class_4051
 */
package uz.echoes.boss;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4051;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossTargeting {
    private EchoBossTargeting() {
    }

    public static class_1309 findTarget(EchoWardenMonarchEntity echoWardenMonarchEntity, double d) {
        class_1937 class_19372 = echoWardenMonarchEntity.method_37908();
        if (!(class_19372 instanceof class_3218)) {
            return null;
        }
        class_3218 class_32182 = (class_3218)class_19372;
        class_1309 class_13092 = echoWardenMonarchEntity.method_5968();
        if (class_13092 != null && class_13092.method_5805() && !(class_13092 instanceof class_3222 && (((class_3222)class_13092).method_7325() || ((class_3222)class_13092).method_7337())) && class_13092.method_5858((class_1297)echoWardenMonarchEntity) <= d * d) {
            return class_13092;
        }
        class_238 class_2382 = echoWardenMonarchEntity.method_5829().method_1014(d);
        class_3222 class_32223 = (class_3222)class_32182.method_18468(class_32182.method_8390(class_3222.class, class_2382, class_32222 -> class_32222.method_5805() && !class_32222.method_7325() && !class_32222.method_7337()), class_4051.field_18092, (class_1309)echoWardenMonarchEntity, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318(), echoWardenMonarchEntity.method_23321());
        if (class_32223 != null) {
            echoWardenMonarchEntity.method_5980((class_1309)class_32223);
        }
        return class_32223;
    }
}
