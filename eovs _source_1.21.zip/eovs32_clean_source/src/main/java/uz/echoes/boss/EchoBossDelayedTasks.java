/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
 *  net.minecraft.class_3218
 */
package uz.echoes.boss;

import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_3218;

public final class EchoBossDelayedTasks {
    private static final Queue<Task> TASKS = new ConcurrentLinkedQueue<Task>();
    private static boolean registered = false;

    private EchoBossDelayedTasks() {
    }

    public static void init() {
        if (registered) {
            return;
        }
        registered = true;
        ServerTickEvents.END_SERVER_TICK.register(minecraftServer -> {
            Iterator iterator = TASKS.iterator();
            while (iterator.hasNext()) {
                Task task = (Task)iterator.next();
                --task.ticksLeft;
                if (task.ticksLeft > 0) continue;
                task.world.method_8503().execute(task.action);
                iterator.remove();
            }
        });
    }

    public static void runLater(class_3218 class_32182, int n, Runnable runnable) {
        TASKS.add(new Task(class_32182, n, runnable));
    }

    private static class Task {
        private final class_3218 world;
        private int ticksLeft;
        private final Runnable action;

        public Task(class_3218 class_32182, int n, Runnable runnable) {
            this.world = class_32182;
            this.ticksLeft = n;
            this.action = runnable;
        }
    }
}

