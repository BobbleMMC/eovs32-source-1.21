/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_3218
 *  net.minecraft.class_3417
 */
package uz.echoes.boss;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossSculkSpikeAttack {
    private EchoBossSculkSpikeAttack() {
    }

    public static void cast(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity, class_1309 class_13092) {
        echoWardenMonarchEntity.method_5783(class_3417.field_38060, 3.2f, echoWardenMonarchEntity.getEchoPhase() == 3 ? 0.62f : 0.78f);
        class_2338 class_23382 = class_13092.method_24515();
        int n = echoWardenMonarchEntity.getEchoPhase() == 3 ? 5 : 3;
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                if (Math.abs(i) + Math.abs(j) > n + 1) continue;
                class_2338 class_23383 = class_23382.method_10069(i, -1, j);
                class_2338 class_23384 = class_23383.method_10084();
                if (class_32182.method_8320(class_23383).method_26215() || !class_32182.method_8320(class_23384).method_26215()) continue;
                class_32182.method_8652(class_23384, class_2246.field_37569.method_9564(), 3);
                class_32182.method_14199((class_2394)class_2398.field_38002, (double)class_23384.method_10263() + 0.5, (double)class_23384.method_10264() + 0.35, (double)class_23384.method_10260() + 0.5, 6, 0.25, 0.35, 0.25, 0.02);
            }
        }
        if (echoWardenMonarchEntity.method_5858((class_1297)class_13092) < 81.0) {
            class_13092.method_5643(class_32182.method_48963().method_48812((class_1309)echoWardenMonarchEntity), echoWardenMonarchEntity.getEchoPhase() == 3 ? 16.0f : 11.0f);
        }
    }
}

