/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1937
 *  net.minecraft.class_2338
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_2561
 *  net.minecraft.class_3218
 *  net.minecraft.class_3417
 *  net.minecraft.class_3419
 *  net.minecraft.class_3730
 *  net.minecraft.class_5425
 */
package uz.echoes.boss;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import uz.echoes.boss.EchoBossBarManager;
import uz.echoes.boss.EchoBossDelayedTasks;
import uz.echoes.entity.EchoWardenMonarchEntity;
import uz.echoes.registry.ModEntities;

public final class EchoBossSpawner {
    private EchoBossSpawner() {
    }

    public static EchoWardenMonarchEntity spawnBoss(class_3218 class_32182, class_2338 class_23382) {
        EchoWardenMonarchEntity echoWardenMonarchEntity = (EchoWardenMonarchEntity)ModEntities.ECHO_WARDEN_MONARCH.method_5883((class_1937)class_32182);
        if (echoWardenMonarchEntity == null) {
            return null;
        }
        echoWardenMonarchEntity.method_5665((class_2561)class_2561.method_43470((String)"Echo Warden Monarch"));
        echoWardenMonarchEntity.method_5880(true);
        echoWardenMonarchEntity.method_5808((double)class_23382.method_10263() + 0.5, class_23382.method_10264(), (double)class_23382.method_10260() + 0.5, 0.0f, 0.0f);
        echoWardenMonarchEntity.method_5943((class_5425)class_32182, class_32182.method_8404(class_23382), class_3730.field_16461, null);
        echoWardenMonarchEntity.method_6033(1.0f);
        echoWardenMonarchEntity.setInvulnerableIntroTicks(70);
        class_32182.method_8649((class_1297)echoWardenMonarchEntity);
        echoWardenMonarchEntity.setEchoBossBar(EchoBossBarManager.attachBossBar(echoWardenMonarchEntity));
        EchoBossSpawner.playWardenSpawnAnimation(class_32182, class_23382);
        EchoBossDelayedTasks.runLater(class_32182, 70, () -> {
            if (echoWardenMonarchEntity.method_5805()) {
                echoWardenMonarchEntity.method_6033(echoWardenMonarchEntity.method_6063());
            }
        });
        echoWardenMonarchEntity.triggerRoarAnimation();
        return echoWardenMonarchEntity;
    }

    private static void playWardenSpawnAnimation(class_3218 class_32182, class_2338 class_23382) {
        class_32182.method_8396(null, class_23382, class_3417.field_38075, class_3419.field_15251, 4.0f, 0.55f);
        class_32182.method_8396(null, class_23382, class_3417.field_38064, class_3419.field_15251, 2.6f, 0.75f);
        class_32182.method_14199((class_2394)class_2398.field_38002, (double)class_23382.method_10263() + 0.5, (double)class_23382.method_10264() + 0.4, (double)class_23382.method_10260() + 0.5, 96, 1.2, 0.35, 1.2, 0.02);
        class_32182.method_14199((class_2394)class_2398.field_23114, (double)class_23382.method_10263() + 0.5, (double)class_23382.method_10264() + 1.4, (double)class_23382.method_10260() + 0.5, 48, 0.7, 0.9, 0.7, 0.01);
    }
}

