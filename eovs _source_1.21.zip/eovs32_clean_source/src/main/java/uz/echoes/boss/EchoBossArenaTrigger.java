package uz.echoes.boss;

import net.minecraft.class_3218;
import uz.echoes.world.EchoArenaChestBossTrigger;
import uz.echoes.world.EchoDimensionPersistentState;

/** Compatibility hook: boss is spawned only by the one-time arena chest trigger. */
public final class EchoBossArenaTrigger {
    private EchoBossArenaTrigger() {
    }

    public static void ensureBossAtArena(class_3218 world) {
        if (world == null || EchoDimensionPersistentState.get(world).isBossDefeated()) {
            return;
        }
        if (!EchoArenaChestBossTrigger.isTriggered(world)) {
            return;
        }
        EchoArenaChestBossTrigger.spawnBossOnce(world);
    }
}
