/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 */
package uz.echoes.boss;

import uz.echoes.boss.EchoBossAttackController;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossCombatManager {
    private EchoBossCombatManager() {
    }

    public static void tickCombat(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        EchoBossAttackController.tickBossAttacks(echoWardenMonarchEntity);
    }
}

