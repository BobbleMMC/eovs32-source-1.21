/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1309
 *  net.minecraft.class_1937
 *  net.minecraft.class_238
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_2561
 *  net.minecraft.class_3218
 *  net.minecraft.class_3222
 *  net.minecraft.class_3417
 *  net.minecraft.class_3419
 */
package uz.echoes.boss;

import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import uz.echoes.boss.EchoBossCooldowns;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossPhaseManager {
    private EchoBossPhaseManager() {
    }

    public static void updatePhase(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        int n;
        if (echoWardenMonarchEntity == null || !echoWardenMonarchEntity.method_5805()) {
            return;
        }
        int n2 = echoWardenMonarchEntity.getEchoPhase();
        if (n2 != (n = EchoBossPhaseManager.calculatePhase(echoWardenMonarchEntity))) {
            echoWardenMonarchEntity.setEchoPhase(n);
            EchoBossCooldowns.onPhaseChanged(echoWardenMonarchEntity);
            EchoBossPhaseManager.playPhaseRoar(echoWardenMonarchEntity, n);
            EchoBossPhaseManager.spawnPhaseBurst(echoWardenMonarchEntity, n);
            EchoBossPhaseManager.broadcastPhaseMessage(echoWardenMonarchEntity, n);
        }
    }

    private static int calculatePhase(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        float f = echoWardenMonarchEntity.method_6063();
        if (f <= 0.0f) {
            return 1;
        }
        float f2 = echoWardenMonarchEntity.method_6032() / f;
        if (f2 <= 0.25f) {
            return 3;
        }
        if (f2 <= 0.6f) {
            return 2;
        }
        return 1;
    }

    private static void playPhaseRoar(EchoWardenMonarchEntity echoWardenMonarchEntity, int n) {
        class_1937 class_19372 = echoWardenMonarchEntity.method_37908();
        if (!(class_19372 instanceof class_3218)) {
            return;
        }
        class_3218 class_32182 = (class_3218)class_19372;
        float f = switch (n) {
            case 3 -> 4.5f;
            case 2 -> 3.5f;
            default -> 2.5f;
        };
        float f2 = switch (n) {
            case 3 -> 0.55f;
            case 2 -> 0.7f;
            default -> 0.85f;
        };
        class_32182.method_8396(null, echoWardenMonarchEntity.method_24515(), class_3417.field_38075, class_3419.field_15251, f, f2);
        class_32182.method_8396(null, echoWardenMonarchEntity.method_24515(), class_3417.field_38830, class_3419.field_15251, f * 0.6f, f2);
    }

    private static void spawnPhaseBurst(EchoWardenMonarchEntity echoWardenMonarchEntity, int n) {
        class_1937 class_19372 = echoWardenMonarchEntity.method_37908();
        if (!(class_19372 instanceof class_3218)) {
            return;
        }
        class_3218 class_32182 = (class_3218)class_19372;
        class_32182.method_14199((class_2394)class_2398.field_38908, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 4.0, echoWardenMonarchEntity.method_23321(), 1, 0.0, 0.0, 0.0, 0.0);
        int n2 = switch (n) {
            case 3 -> 7;
            case 2 -> 12;
            default -> 8;
        };
        double d = switch (n) {
            case 3 -> 0.75;
            case 2 -> 0.85;
            default -> 0.65;
        };
        class_32182.method_14199((class_2394)class_2398.field_38002, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 2.0, echoWardenMonarchEntity.method_23321(), n2, d, 0.7, d, 0.02);
    }

    private static void broadcastPhaseMessage(EchoWardenMonarchEntity echoWardenMonarchEntity, int n) {
        class_1937 class_19372 = echoWardenMonarchEntity.method_37908();
        if (!(class_19372 instanceof class_3218)) {
            return;
        }
        class_3218 class_32182 = (class_3218)class_19372;
        String string = switch (n) {
            case 2 -> "\u00a73Echo Warden Monarch enters Phase II: the arena begins to answer him.";
            case 3 -> "\u00a74Echo Warden Monarch enters Phase III: RAGE OF THE ECHO VOID.";
            default -> "\u00a77Echo Warden Monarch awakens.";
        };
        class_238 class_2382 = echoWardenMonarchEntity.method_5829().method_1014(96.0);
        for (class_3222 class_32222 : class_32182.method_8390(class_3222.class, class_2382, class_1309::method_5805)) {
            class_32222.method_7353((class_2561)class_2561.method_43470((String)string), false);
        }
    }
}

