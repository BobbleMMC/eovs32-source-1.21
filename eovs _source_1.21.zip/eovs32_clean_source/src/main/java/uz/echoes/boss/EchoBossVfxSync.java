/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_243
 *  net.minecraft.class_3218
 *  net.minecraft.class_3417
 */
package uz.echoes.boss;

import java.util.WeakHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossVfxSync {
    private static final WeakHashMap<class_1297, ClientAnim> CLIENT_ANIMS = new WeakHashMap();

    private EchoBossVfxSync() {
    }

    public static void play(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity, Ability ability, class_1309 class_13092) {
        class_32182.method_8421((class_1297)echoWardenMonarchEntity, ability.status);
        EchoBossVfxSync.spawnServerVfx(class_32182, echoWardenMonarchEntity, ability, class_13092);
    }

    public static void handleClientStatus(class_1297 class_12972, byte by) {
        Ability ability = EchoBossVfxSync.fromStatus(by);
        if (ability != null) {
            CLIENT_ANIMS.put(class_12972, new ClientAnim(ability, System.currentTimeMillis() + ability.clientLockMs));
        }
    }

    public static Ability getClientAnimation(class_1297 class_12972) {
        ClientAnim clientAnim = CLIENT_ANIMS.get(class_12972);
        if (clientAnim == null) {
            return null;
        }
        if (System.currentTimeMillis() > clientAnim.expireAtMs) {
            CLIENT_ANIMS.remove(class_12972);
            return null;
        }
        return clientAnim.ability;
    }

    public static boolean isEchoStatus(byte by) {
        return EchoBossVfxSync.fromStatus(by) != null;
    }

    private static Ability fromStatus(byte by) {
        for (Ability ability : Ability.values()) {
            if (ability.status != by) continue;
            return ability;
        }
        return null;
    }

    private static void spawnServerVfx(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity, Ability ability, class_1309 class_13092) {
        int n = echoWardenMonarchEntity.getEchoPhase();
        switch (ability.ordinal()) {
            case 0: {
                double d = n == 3 ? 16.0 : (n == 2 ? 12.5 : 9.0);
                echoWardenMonarchEntity.method_5783(class_3417.field_38064, 3.4f, n == 3 ? 0.52f : 0.68f);
                int stompParticles = n == 3 ? 72 : 120 + n * 35;
                double stompSpread = n == 3 ? d * 0.32 : d * 0.45;
                class_32182.method_14199((class_2394)class_2398.field_38002, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 0.25, echoWardenMonarchEntity.method_23321(), stompParticles, stompSpread, 0.10, stompSpread, 0.055);
                class_32182.method_14199((class_2394)class_2398.field_38908, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 1.1, echoWardenMonarchEntity.method_23321(), 2 + n, 0.9, 0.2, 0.9, 0.0);
                break;
            }
            case 1: {
                echoWardenMonarchEntity.method_5783(class_3417.field_38831, 3.8f, n == 3 ? 0.48f : 0.68f);
                if (class_13092 == null) break;
                class_243 class_2432 = echoWardenMonarchEntity.method_33571();
                class_243 class_2433 = class_13092.method_33571();
                class_243 class_2434 = class_2433.method_1020(class_2432).method_1029();
                for (int i = 0; i < (n == 3 ? 10 : 18); ++i) {
                    class_243 class_2435 = class_2432.method_1019(class_2434.method_1021((double)i * 0.9));
                    class_32182.method_14199((class_2394)class_2398.field_38002, class_2435.field_1352, class_2435.field_1351, class_2435.field_1350, 2, 0.08, 0.08, 0.08, 0.01);
                }
                break;
            }
            case 2: {
                echoWardenMonarchEntity.method_5783(class_3417.field_14879, 2.7f, 0.38f);
                class_32182.method_14199((class_2394)class_2398.field_23190, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 2.4, echoWardenMonarchEntity.method_23321(), 8, 0.55, 0.8, 0.55, 0.015);
                class_32182.method_14199((class_2394)class_2398.field_23114, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 2.5, echoWardenMonarchEntity.method_23321(), 10, 0.5, 0.75, 0.5, 0.008);
                break;
            }
            case 3: {
                echoWardenMonarchEntity.method_5783(class_3417.field_38060, 2.7f, 0.58f);
                class_32182.method_14199((class_2394)class_2398.field_38004, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 1.0, echoWardenMonarchEntity.method_23321(), n == 3 ? 30 : 55, n == 3 ? 3.2 : 4.5, 0.32, n == 3 ? 3.2 : 4.5, 0.018);
                break;
            }
            case 4: {
                echoWardenMonarchEntity.method_5783(class_3417.field_38075, 4.0f, 0.42f);
                class_32182.method_14199((class_2394)class_2398.field_38908, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 4.0, echoWardenMonarchEntity.method_23321(), n == 3 ? 3 : 7, n == 3 ? 1.1 : 2.0, 0.7, n == 3 ? 1.1 : 2.0, 0.0);
                class_32182.method_14199((class_2394)class_2398.field_38002, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 2.5, echoWardenMonarchEntity.method_23321(), n == 3 ? 80 : 160, n == 3 ? 5.2 : 8.0, n == 3 ? 1.4 : 2.0, n == 3 ? 5.2 : 8.0, n == 3 ? 0.055 : 0.09);
            }
        }
    }

    public static enum Ability {
        STOMP(61, 900L),
        SONIC(62, 1050L),
        TELEPORT(63, 800L),
        SPIKES(64, 950L),
        DARK_PULSE(65, 1300L);

        public final byte status;
        public final long clientLockMs;

        private Ability(int status, long l) {
            this.status = (byte) status;
            this.clientLockMs = l;
        }
    }

    private record ClientAnim(Ability ability, long expireAtMs) {
    }
}

