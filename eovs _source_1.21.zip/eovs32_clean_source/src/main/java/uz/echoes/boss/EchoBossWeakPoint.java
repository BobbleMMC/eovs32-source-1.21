package uz.echoes.boss;

import java.lang.reflect.Method;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import uz.echoes.EchoesMod;
import uz.echoes.entity.EchoWardenMonarchEntity;

/**
 * Soul-core/chest weak-point rule for Echo Warden Monarch.
 *
 * The previous patch multiplied every valid hit by 1.5x. This helper narrows
 * the bonus to hits that are plausibly aimed at the exposed chest/soul-core
 * band. It works without adding a fragile new entity registration: projectile
 * sources are checked by their actual position, and melee/player sources are
 * checked against the boss-relative chest band instead of applying globally.
 */
public final class EchoBossWeakPoint {
    private static final double CHEST_MIN_Y = 1.35;
    private static final double CHEST_MAX_Y = 3.65;
    private static final double CHEST_HORIZONTAL_RADIUS_SQ = 7.25;
    private static boolean warnedDamageSourceAccess = false;

    private EchoBossWeakPoint() {
    }

    public static boolean isSoulCoreHit(EchoWardenMonarchEntity boss, class_1282 source) {
        if (boss == null || source == null) {
            return false;
        }
        class_1297 sourceEntity = getDamageSourceEntity(source);
        if (sourceEntity == null) {
            return false;
        }
        double dx = sourceEntity.method_23317() - boss.method_23317();
        double dz = sourceEntity.method_23321() - boss.method_23321();
        double horizontalSq = dx * dx + dz * dz;
        if (horizontalSq > CHEST_HORIZONTAL_RADIUS_SQ) {
            return false;
        }
        double relativeY = approximateHitY(sourceEntity) - boss.method_23318();
        return relativeY >= CHEST_MIN_Y && relativeY <= CHEST_MAX_Y;
    }

    private static double approximateHitY(class_1297 sourceEntity) {
        // For melee attackers DamageSource normally exposes the attacker entity,
        // not the exact collision point. Eye-height approximation makes player
        // chest-aimed hits eligible without turning the multiplier global.
        return sourceEntity.method_23318() + 1.6;
    }

    private static class_1297 getDamageSourceEntity(class_1282 source) {
        // Intermediary names shifted across 1.20.x/1.21.x builds. Reflection
        // keeps this source safer while still preferring the normal attacker /
        // direct-source methods when they exist.
        String[] candidates = new String[]{"method_5529", "method_5526", "method_5514"};
        for (String methodName : candidates) {
            try {
                Method method = source.getClass().getMethod(methodName);
                Object value = method.invoke(source);
                if (value instanceof class_1297) {
                    return (class_1297)value;
                }
            } catch (ReflectiveOperationException ignored) {
                // Try next known intermediary accessor.
            }
        }
        if (!warnedDamageSourceAccess) {
            warnedDamageSourceAccess = true;
            EchoesMod.LOGGER.warn("EchoBossWeakPoint could not resolve DamageSource entity accessors; soul-core 1.5x weak-point bonus may not trigger on this mapping.");
        }
        return null;
    }
}
