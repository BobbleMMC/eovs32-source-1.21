/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1937
 *  net.minecraft.class_2338
 *  net.minecraft.class_3218
 */
package uz.echoes.boss;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import uz.echoes.boss.EchoBossArenaLock;
import uz.echoes.boss.EchoBossDeathHandler;
import uz.echoes.boss.EchoBossLootDropper;
import uz.echoes.entity.EchoWardenMonarchEntity;
import uz.echoes.world.EchoDimensionPersistentState;

public final class EchoBossDefeatManager {
    private EchoBossDefeatManager() {
    }

    public static void handleDefeat(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        class_1937 class_19372 = echoWardenMonarchEntity.method_37908();
        if (!(class_19372 instanceof class_3218)) {
            return;
        }
        class_3218 class_32182 = (class_3218)class_19372;
        class_2338 class_23382 = new class_2338(0, 80, 0);
        EchoDimensionPersistentState.get(class_32182).setBossDefeated(class_32182, true);
        echoWardenMonarchEntity.detachEchoBossBar();
        EchoBossLootDropper.dropBossLoot(echoWardenMonarchEntity);
        EchoBossLootDropper.dropBossExperience(class_32182, echoWardenMonarchEntity);
        EchoBossArenaLock.unlockArena(class_32182, class_23382);
        EchoBossDeathHandler.onBossDefeated(echoWardenMonarchEntity);
    }
}

