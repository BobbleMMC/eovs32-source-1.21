/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1303
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1935
 *  net.minecraft.class_243
 *  net.minecraft.class_3218
 */
package uz.echoes.boss;

import net.minecraft.class_1303;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import uz.echoes.entity.EchoWardenMonarchEntity;
import uz.echoes.item.ModItems;

public final class EchoBossLootDropper {
    private static boolean firstXpRewardDropped;

    private EchoBossLootDropper() {
    }

    public static void dropBossLoot(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        echoWardenMonarchEntity.method_5775(new class_1799((class_1935)ModItems.ECHOENERGY_STONE, 1));
        echoWardenMonarchEntity.method_5775(new class_1799((class_1935)ModItems.ECHO_WARDEN_HEART, 1));
        echoWardenMonarchEntity.method_5775(new class_1799((class_1935)class_1802.field_38746, 24));
        echoWardenMonarchEntity.method_5775(new class_1799((class_1935)class_1802.field_8137, 1));
        echoWardenMonarchEntity.method_5775(new class_1799((class_1935)class_1802.field_37525, 3));
    }

    public static void dropBossExperience(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity) {
        int n = firstXpRewardDropped ? 12000 : 24000;
        firstXpRewardDropped = true;
        class_1303.method_31493((class_3218)class_32182, (class_243)new class_243(echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 1.0, echoWardenMonarchEntity.method_23321()), (int)n);
    }
}

