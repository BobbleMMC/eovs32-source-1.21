/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_243
 *  net.minecraft.class_3218
 *  net.minecraft.class_3417
 */
package uz.echoes.boss;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import uz.echoes.entity.EchoWardenMonarchEntity;
import uz.echoes.item.EchoArmorMaterial;

public final class EchoBossSonicAttack {
    private EchoBossSonicAttack() {
    }

    public static void cast(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity, class_1309 class_13092) {
        class_243 class_2432 = echoWardenMonarchEntity.method_33571();
        class_243 class_2433 = class_13092.method_33571();
        class_243 class_2434 = class_2433.method_1020(class_2432).method_1029();
        int n = echoWardenMonarchEntity.getEchoPhase();
        echoWardenMonarchEntity.method_5783(class_3417.field_38830, 4.0f, n == 3 ? 0.55f : 0.78f);
        int n2 = n == 3 ? 46 : (n == 2 ? 40 : 34);
        for (int i = 0; i < n2; ++i) {
            class_243 class_2435 = class_2432.method_1019(class_2434.method_1021((double)i * 1.15));
            class_32182.method_14199((class_2394)class_2398.field_38908, class_2435.field_1352, class_2435.field_1351, class_2435.field_1350, 1, 0.0, 0.0, 0.0, 0.0);
        }
        float f = 10.0f + (float)n * 4.0f;
        if (EchoArmorMaterial.hasFullEchoArmor(class_13092)) {
            return;
        }
        class_13092.method_5643(class_32182.method_48963().method_48821((class_1297)echoWardenMonarchEntity), f);
        class_13092.method_6005(1.0 + (double)n * 0.15, echoWardenMonarchEntity.method_23317() - class_13092.method_23317(), echoWardenMonarchEntity.method_23321() - class_13092.method_23321());
    }
}

