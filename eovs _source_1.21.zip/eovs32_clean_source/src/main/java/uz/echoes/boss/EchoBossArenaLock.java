/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_3218
 */
package uz.echoes.boss;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public final class EchoBossArenaLock {
    private EchoBossArenaLock() {
    }

    public static void lockArena(class_3218 class_32182, class_2338 class_23382) {
        for (int i = -3; i <= 3; ++i) {
            class_32182.method_8501(class_23382.method_10069(i, 0, -25), class_2246.field_38420.method_9564());
        }
    }

    public static void unlockArena(class_3218 class_32182, class_2338 class_23382) {
        for (int i = -3; i <= 3; ++i) {
            class_32182.method_8501(class_23382.method_10069(i, 0, -25), class_2246.field_10124.method_9564());
            class_32182.method_8501(class_23382.method_10069(i, 1, -25), class_2246.field_10124.method_9564());
        }
    }
}

