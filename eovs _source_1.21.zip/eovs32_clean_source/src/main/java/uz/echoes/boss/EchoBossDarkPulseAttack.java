/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_3218
 *  net.minecraft.class_3222
 *  net.minecraft.class_3417
 */
package uz.echoes.boss;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossDarkPulseAttack {
    private EchoBossDarkPulseAttack() {
    }

    public static void cast(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity) {
        echoWardenMonarchEntity.method_5783(class_3417.field_38831, 4.0f, 0.55f);
        echoWardenMonarchEntity.method_5783(class_3417.field_38075, 4.0f, 0.45f);
        double d = 28.0;
        boolean phaseThree = echoWardenMonarchEntity.getEchoPhase() >= 3;
        class_32182.method_14199((class_2394)class_2398.field_38908, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 4.0, echoWardenMonarchEntity.method_23321(), phaseThree ? 4 : 10, phaseThree ? 1.4 : 2.6, 1.0, phaseThree ? 1.4 : 2.6, 0.0);
        class_32182.method_14199((class_2394)class_2398.field_38002, echoWardenMonarchEntity.method_23317(), echoWardenMonarchEntity.method_23318() + 3.0, echoWardenMonarchEntity.method_23321(), phaseThree ? 36 : 76, phaseThree ? 2.8 : 3.8, phaseThree ? 1.2 : 1.8, phaseThree ? 2.8 : 3.8, phaseThree ? 0.018 : 0.035);
        for (class_3222 class_32223 : class_32182.method_8390(class_3222.class, echoWardenMonarchEntity.method_5829().method_1014(d), class_32222 -> class_32222.method_5805() && !class_32222.method_7325() && !class_32222.method_7337())) {
            double d2 = Math.max(1.0, (double)echoWardenMonarchEntity.method_5739((class_1297)class_32223));
            float f = (float)Math.max(6.0, 22.0 - d2 * 0.35);
            class_32223.method_5643(class_32182.method_48963().method_48812((class_1309)echoWardenMonarchEntity), f);
            class_32223.method_37222(new class_1293(class_1294.field_38092, 120, 0, true, false, true), (class_1297)echoWardenMonarchEntity);
            class_32223.method_37222(new class_1293(class_1294.field_5909, 70, 0, true, false, true), (class_1297)echoWardenMonarchEntity);
        }
        for (class_1309 class_13092 : class_32182.method_8390(class_1309.class, echoWardenMonarchEntity.method_5829().method_1014(d), class_13092 -> class_13092.method_5805() && class_13092 != echoWardenMonarchEntity && !(class_13092 instanceof class_3222))) {
            class_13092.method_5643(class_32182.method_48963().method_48812((class_1309)echoWardenMonarchEntity), 10.0f);
        }
    }
}
