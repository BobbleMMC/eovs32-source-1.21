package uz.echoes.boss;

import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import uz.echoes.entity.EchoWardenMonarchEntity;
import uz.echoes.world.EchoAltarBossCycle;
import uz.echoes.world.EchoArenaFixer;
import uz.echoes.world.EchoProgressionManager;

public final class EchoBossDeathHandler {
    private EchoBossDeathHandler() {
    }

    public static void onBossDefeated(EchoWardenMonarchEntity boss) {
        class_1937 world = boss.method_37908();
        if (!(world instanceof class_3218)) {
            return;
        }
        class_3218 serverWorld = (class_3218)world;
        EchoArenaFixer.openExitPortal(serverWorld);
        replaceCenterAltar(serverWorld, EchoArenaFixer.ARENA_CENTER);
        clearBossSpawnBlockers(serverWorld, EchoArenaFixer.ARENA_CENTER);
        EchoProgressionManager.onBossDefeated(serverWorld);
    }

    public static void replaceCenterAltar(class_3218 world, class_2338 center) {
        EchoAltarBossCycle.restoreAltar(world);
    }

    private static void clearBossSpawnBlockers(class_3218 world, class_2338 center) {
        for (int x = -4; x <= 4; ++x) {
            for (int z = -4; z <= 4; ++z) {
                world.method_8652(center.method_10069(x, 1, z), class_2246.field_10124.method_9564(), 3);
                world.method_8652(center.method_10069(x, 2, z), class_2246.field_10124.method_9564(), 3);
            }
        }
        EchoAltarBossCycle.restoreAltar(world);
    }
}
