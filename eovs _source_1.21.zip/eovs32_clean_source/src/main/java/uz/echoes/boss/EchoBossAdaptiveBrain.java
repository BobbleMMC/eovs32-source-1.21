/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 */
package uz.echoes.boss;

import java.util.WeakHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import uz.echoes.boss.EchoBossVfxSync;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossAdaptiveBrain {
    private static final WeakHashMap<EchoWardenMonarchEntity, Memory> MEMORY = new WeakHashMap();

    private EchoBossAdaptiveBrain() {
    }

    public static Preference observe(EchoWardenMonarchEntity echoWardenMonarchEntity2, class_1309 class_13092) {
        Memory memory = MEMORY.computeIfAbsent(echoWardenMonarchEntity2, echoWardenMonarchEntity -> new Memory());
        double d = echoWardenMonarchEntity2.method_5858((class_1297)class_13092);
        double d2 = class_13092.method_23318() - echoWardenMonarchEntity2.method_23318();
        memory.closeTicks = d <= 121.0 ? (memory.closeTicks = memory.closeTicks + 1) : Math.max(0, memory.closeTicks - 2);
        memory.farTicks = d >= 1444.0 ? (memory.farTicks = memory.farTicks + 1) : Math.max(0, memory.farTicks - 2);
        memory.verticalTicks = d2 > 5.0 ? (memory.verticalTicks = memory.verticalTicks + 1) : Math.max(0, memory.verticalTicks - 2);
        ++memory.totalTicks;
        if (memory.verticalTicks > 45 && echoWardenMonarchEntity2.getEchoPhase() >= 2) {
            return Preference.PUNISH_VERTICAL;
        }
        if (memory.farTicks > 55 && echoWardenMonarchEntity2.getEchoPhase() >= 2) {
            return Preference.PUNISH_DISTANCE;
        }
        if (memory.closeTicks > 50) {
            return Preference.PUNISH_CLOSE;
        }
        if (memory.totalTicks % 180 > 125 && echoWardenMonarchEntity2.getEchoPhase() == 3) {
            return Preference.MIX_UP;
        }
        return Preference.DEFAULT;
    }

    public static void rememberCast(EchoWardenMonarchEntity echoWardenMonarchEntity2, EchoBossVfxSync.Ability ability) {
        Memory memory = MEMORY.computeIfAbsent(echoWardenMonarchEntity2, echoWardenMonarchEntity -> new Memory());
        memory.lastAbility = ability;
        memory.lastCastTick = memory.totalTicks;
    }

    public static boolean recentlyUsed(EchoWardenMonarchEntity echoWardenMonarchEntity, EchoBossVfxSync.Ability ability, int n) {
        Memory memory = MEMORY.get((Object)echoWardenMonarchEntity);
        if (memory == null || memory.lastAbility != ability) {
            return false;
        }
        return memory.totalTicks - memory.lastCastTick < n;
    }

    private static final class Memory {
        int closeTicks;
        int farTicks;
        int verticalTicks;
        int totalTicks;
        int lastCastTick = -9999;
        EchoBossVfxSync.Ability lastAbility;

        private Memory() {
        }
    }

    public static enum Preference {
        DEFAULT,
        PUNISH_CLOSE,
        PUNISH_DISTANCE,
        PUNISH_VERTICAL,
        MIX_UP;

    }
}

