/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1309
 *  net.minecraft.class_238
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_2561
 *  net.minecraft.class_3218
 *  net.minecraft.class_3222
 *  net.minecraft.class_3419
 */
package uz.echoes.boss;

import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import uz.echoes.sound.ModSounds;

public final class EchoBossCinematicIntro {
    private EchoBossCinematicIntro() {
    }

    public static void play(class_3218 class_32182, class_1309 class_13092) {
        class_32182.method_8396(null, class_13092.method_24515(), ModSounds.ECHO_MONARCH_ROAR, class_3419.field_15251, 4.0f, 0.75f);
        class_32182.method_14199((class_2394)class_2398.field_38002, class_13092.method_23317(), class_13092.method_23318() + 1.0, class_13092.method_23321(), 80, 2.0, 1.0, 2.0, 0.04);
        class_32182.method_14199((class_2394)class_2398.field_38908, class_13092.method_23317(), class_13092.method_23318() + 1.0, class_13092.method_23321(), 1, 0.0, 0.0, 0.0, 0.0);
        class_238 class_2382 = class_13092.method_5829().method_1014(64.0);
        for (class_3222 class_32223 : class_32182.method_8390(class_3222.class, class_2382, class_32222 -> true)) {
            class_32223.method_7353((class_2561)class_2561.method_43470((String)"\u00a75\u00a7lECHO WARDEN MONARCH"), true);
        }
    }
}

