/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 */
package uz.echoes.boss;

import java.util.WeakHashMap;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossCooldowns {
    private static final WeakHashMap<EchoWardenMonarchEntity, Cooldowns> DATA = new WeakHashMap();

    private EchoBossCooldowns() {
    }

    private static Cooldowns data(EchoWardenMonarchEntity echoWardenMonarchEntity2) {
        return DATA.computeIfAbsent(echoWardenMonarchEntity2, echoWardenMonarchEntity -> new Cooldowns());
    }

    public static void tick(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        Cooldowns cooldowns = EchoBossCooldowns.data(echoWardenMonarchEntity);
        if (cooldowns.sonic > 0) {
            --cooldowns.sonic;
        }
        if (cooldowns.stomp > 0) {
            --cooldowns.stomp;
        }
        if (cooldowns.summon > 0) {
            --cooldowns.summon;
        }
        if (cooldowns.teleport > 0) {
            --cooldowns.teleport;
        }
        if (cooldowns.spikes > 0) {
            --cooldowns.spikes;
        }
        if (cooldowns.darkPulse > 0) {
            --cooldowns.darkPulse;
        }
    }

    public static boolean readySonic(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        return EchoBossCooldowns.data((EchoWardenMonarchEntity)echoWardenMonarchEntity).sonic <= 0;
    }

    public static boolean readyStomp(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        return EchoBossCooldowns.data((EchoWardenMonarchEntity)echoWardenMonarchEntity).stomp <= 0;
    }

    public static boolean readySummon(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        return EchoBossCooldowns.data((EchoWardenMonarchEntity)echoWardenMonarchEntity).summon <= 0;
    }

    public static boolean readyTeleport(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        return EchoBossCooldowns.data((EchoWardenMonarchEntity)echoWardenMonarchEntity).teleport <= 0;
    }

    public static boolean readySpikes(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        return EchoBossCooldowns.data((EchoWardenMonarchEntity)echoWardenMonarchEntity).spikes <= 0;
    }

    public static boolean readyDarkPulse(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        return EchoBossCooldowns.data((EchoWardenMonarchEntity)echoWardenMonarchEntity).darkPulse <= 0;
    }

    public static void resetSonic(EchoWardenMonarchEntity echoWardenMonarchEntity, int n) {
        EchoBossCooldowns.data((EchoWardenMonarchEntity)echoWardenMonarchEntity).sonic = n;
    }

    public static void resetStomp(EchoWardenMonarchEntity echoWardenMonarchEntity, int n) {
        EchoBossCooldowns.data((EchoWardenMonarchEntity)echoWardenMonarchEntity).stomp = n;
    }

    public static void resetSummon(EchoWardenMonarchEntity echoWardenMonarchEntity, int n) {
        EchoBossCooldowns.data((EchoWardenMonarchEntity)echoWardenMonarchEntity).summon = n;
    }

    public static void resetTeleport(EchoWardenMonarchEntity echoWardenMonarchEntity, int n) {
        EchoBossCooldowns.data((EchoWardenMonarchEntity)echoWardenMonarchEntity).teleport = n;
    }

    public static void resetSpikes(EchoWardenMonarchEntity echoWardenMonarchEntity, int n) {
        EchoBossCooldowns.data((EchoWardenMonarchEntity)echoWardenMonarchEntity).spikes = n;
    }

    public static void resetDarkPulse(EchoWardenMonarchEntity echoWardenMonarchEntity, int n) {
        EchoBossCooldowns.data((EchoWardenMonarchEntity)echoWardenMonarchEntity).darkPulse = n;
    }

    public static void onPhaseChanged(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        Cooldowns cooldowns = EchoBossCooldowns.data(echoWardenMonarchEntity);
        cooldowns.sonic = 150;
        cooldowns.stomp = 45;
        cooldowns.summon = echoWardenMonarchEntity.getEchoPhase() >= 2 ? 80 : 200;
        cooldowns.teleport = 60;
        cooldowns.spikes = echoWardenMonarchEntity.getEchoPhase() >= 2 ? 90 : 220;
        cooldowns.darkPulse = echoWardenMonarchEntity.getEchoPhase() == 3 ? 80 : 260;
    }

    private static final class Cooldowns {
        int sonic = 180;
        int stomp = 90;
        int summon = 180;
        int teleport = 120;
        int spikes = 140;
        int darkPulse = 180;

        private Cooldowns() {
        }
    }
}

