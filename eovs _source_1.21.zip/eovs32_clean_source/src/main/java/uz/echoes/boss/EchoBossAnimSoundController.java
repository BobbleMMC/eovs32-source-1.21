/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1309
 *  net.minecraft.class_1937
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_243
 *  net.minecraft.class_3218
 *  net.minecraft.class_3414
 *  net.minecraft.class_3419
 */
package uz.echoes.boss;

import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import uz.echoes.sound.ModSounds;

public final class EchoBossAnimSoundController {
    private int breathCooldown = 0;
    private int walkCooldown = 0;
    private int sniffCooldown = 0;
    private int roarCooldown = 0;
    private int waveCooldown = 0;
    private int attackCooldown = 0;

    public void tick(class_1309 class_13092) {
        class_3218 class_32182;
        block10: {
            block9: {
                class_1937 class_19372 = class_13092.method_37908();
                if (!(class_19372 instanceof class_3218)) break block9;
                class_32182 = (class_3218)class_19372;
                if (class_13092.method_5805()) break block10;
            }
            return;
        }
        if (this.breathCooldown-- <= 0) {
            EchoBossAnimSoundController.play(class_32182, class_13092, ModSounds.ECHO_MONARCH_IDLE_BREATH, 0.55f, 0.85f);
            EchoBossAnimSoundController.softSoulParticles(class_32182, class_13092, 10);
            this.breathCooldown = 58;
        }
        class_243 class_2433 = class_13092.method_18798();
        boolean bl = class_2433.method_37268() > 0.003;
        boolean bl2 = bl;
        if (bl && class_13092.method_24828() && this.walkCooldown-- <= 0) {
            EchoBossAnimSoundController.play(class_32182, class_13092, ModSounds.ECHO_MONARCH_WALK, 0.85f, 0.75f);
            EchoBossAnimSoundController.footstepVfx(class_32182, class_13092);
            this.walkCooldown = 12;
        }
        if (this.sniffCooldown > 0) {
            --this.sniffCooldown;
        }
        if (this.roarCooldown > 0) {
            --this.roarCooldown;
        }
        if (this.waveCooldown > 0) {
            --this.waveCooldown;
        }
        if (this.attackCooldown > 0) {
            --this.attackCooldown;
        }
    }

    public void onAttackHit(class_1309 class_13092, class_1309 class_13093) {
        class_3218 class_32182;
        block3: {
            block2: {
                class_1937 class_19372 = class_13092.method_37908();
                if (!(class_19372 instanceof class_3218)) break block2;
                class_32182 = (class_3218)class_19372;
                if (this.attackCooldown <= 0) break block3;
            }
            return;
        }
        EchoBossAnimSoundController.play(class_32182, class_13092, ModSounds.ECHO_MONARCH_ATTACK_HIT, 1.2f, 0.9f);
        class_32182.method_14199((class_2394)class_2398.field_38908, class_13093.method_23317(), class_13093.method_23323(0.55), class_13093.method_23321(), 1, 0.0, 0.0, 0.0, 0.0);
        class_32182.method_14199((class_2394)class_2398.field_38002, class_13093.method_23317(), class_13093.method_23323(0.5), class_13093.method_23321(), 22, 0.6, 0.8, 0.6, 0.03);
        this.attackCooldown = 18;
    }

    public void onJumpWave(class_1309 class_13092) {
        class_3218 class_32182;
        block3: {
            block2: {
                class_1937 class_19372 = class_13092.method_37908();
                if (!(class_19372 instanceof class_3218)) break block2;
                class_32182 = (class_3218)class_19372;
                if (this.waveCooldown <= 0) break block3;
            }
            return;
        }
        EchoBossAnimSoundController.play(class_32182, class_13092, ModSounds.ECHO_MONARCH_JUMP_WAVE, 1.5f, 0.8f);
        EchoBossAnimSoundController.ringParticles(class_32182, class_13092, 5.5, 72);
        this.waveCooldown = 70;
    }

    public void onSniff(class_1309 class_13092) {
        class_3218 class_32182;
        block3: {
            block2: {
                class_1937 class_19372 = class_13092.method_37908();
                if (!(class_19372 instanceof class_3218)) break block2;
                class_32182 = (class_3218)class_19372;
                if (this.sniffCooldown <= 0) break block3;
            }
            return;
        }
        EchoBossAnimSoundController.play(class_32182, class_13092, ModSounds.ECHO_MONARCH_SNIFF, 1.0f, 0.9f);
        EchoBossAnimSoundController.softSoulParticles(class_32182, class_13092, 28);
        this.sniffCooldown = 120;
    }

    public void onRoar(class_1309 class_13092) {
        class_3218 class_32182;
        block3: {
            block2: {
                class_1937 class_19372 = class_13092.method_37908();
                if (!(class_19372 instanceof class_3218)) break block2;
                class_32182 = (class_3218)class_19372;
                if (this.roarCooldown <= 0) break block3;
            }
            return;
        }
        EchoBossAnimSoundController.play(class_32182, class_13092, ModSounds.ECHO_MONARCH_ROAR, 1.8f, 0.75f);
        class_32182.method_14199((class_2394)class_2398.field_38908, class_13092.method_23317(), class_13092.method_23323(0.65), class_13092.method_23321(), 1, 0.0, 0.0, 0.0, 0.0);
        EchoBossAnimSoundController.ringParticles(class_32182, class_13092, 8.5, 120);
        this.roarCooldown = 140;
    }

    public void onDeath(class_1309 class_13092) {
        class_1937 class_19372 = class_13092.method_37908();
        if (!(class_19372 instanceof class_3218)) {
            return;
        }
        class_3218 class_32182 = (class_3218)class_19372;
        EchoBossAnimSoundController.play(class_32182, class_13092, ModSounds.ECHO_MONARCH_DEATH, 2.0f, 0.65f);
        class_32182.method_14199((class_2394)class_2398.field_22246, class_13092.method_23317(), class_13092.method_23323(0.55), class_13092.method_23321(), 90, 1.4, 1.8, 1.4, 0.08);
        EchoBossAnimSoundController.ringParticles(class_32182, class_13092, 10.5, 160);
    }

    private static void play(class_3218 class_32182, class_1309 class_13092, class_3414 class_34142, float f, float f2) {
        class_32182.method_8396(null, class_13092.method_24515(), class_34142, class_3419.field_15251, f, f2);
    }

    private static void softSoulParticles(class_3218 class_32182, class_1309 class_13092, int n) {
        class_32182.method_14199((class_2394)class_2398.field_38002, class_13092.method_23317(), class_13092.method_23323(0.65), class_13092.method_23321(), n, 0.45, 0.75, 0.45, 0.02);
    }

    private static void footstepVfx(class_3218 class_32182, class_1309 class_13092) {
        class_2338 class_23382 = class_13092.method_24515();
        class_32182.method_14199((class_2394)class_2398.field_38004, (double)class_23382.method_10263() + 0.5, (double)class_23382.method_10264() + 0.08, (double)class_23382.method_10260() + 0.5, 8, 0.55, 0.02, 0.55, 0.01);
    }

    private static void ringParticles(class_3218 class_32182, class_1309 class_13092, double d, int n) {
        for (int i = 0; i < n; ++i) {
            double d2 = Math.PI * 2 * (double)i / (double)n;
            double d3 = class_13092.method_23317() + Math.cos(d2) * d;
            double d4 = class_13092.method_23321() + Math.sin(d2) * d;
            class_32182.method_14199((class_2394)class_2398.field_38002, d3, class_13092.method_23318() + 0.25, d4, 1, 0.02, 0.02, 0.02, 0.0);
        }
        class_238 class_2382 = class_13092.method_5829().method_1009(d, 2.5, d);
        for (class_1309 class_13094 : class_32182.method_8390(class_1309.class, class_2382, class_13093 -> class_13093 != class_13092 && class_13093.method_5805())) {
            class_32182.method_14199((class_2394)class_2398.field_38908, class_13094.method_23317(), class_13094.method_23323(0.5), class_13094.method_23321(), 1, 0.0, 0.0, 0.0, 0.0);
        }
    }
}

