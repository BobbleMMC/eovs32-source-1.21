/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_238
 *  net.minecraft.class_3218
 *  net.minecraft.class_3222
 */
package uz.echoes.boss;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossScreenShake {
    private EchoBossScreenShake() {
    }

    public static void pulse(class_3218 class_32182, EchoWardenMonarchEntity echoWardenMonarchEntity, double d, int n, int n2) {
        class_238 class_2382 = echoWardenMonarchEntity.method_5829().method_1009(d, 10.0, d);
        for (class_3222 class_32223 : class_32182.method_8390(class_3222.class, class_2382, class_32222 -> class_32222.method_5805() && !class_32222.method_7325() && !class_32222.method_7337())) {
            class_32223.method_37222(new class_1293(class_1294.field_5916, n, Math.max(0, n2), true, false, false), (class_1297)echoWardenMonarchEntity);
            if (echoWardenMonarchEntity.getEchoPhase() < 3) continue;
            class_32223.method_37222(new class_1293(class_1294.field_38092, n + 30, 0, true, false, true), (class_1297)echoWardenMonarchEntity);
        }
    }
}
