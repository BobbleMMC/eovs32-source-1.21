package uz.echoes.world;

import net.minecraft.class_2248;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;

/**
 * Echo Dimension one-time setup state.
 *
 * The runtime flags prevent repeated work in the active server session. The
 * in-world marker blocks mirror important flags so a saved dimension does not
 * rebuild/reset arena, progression or boss-defeat state after restart.
 */
public final class EchoDimensionPersistentState {
    private static final class_2338 ARENA_MARKER = new class_2338(0, 79, 0);
    private static final class_2338 EXPANDER_MARKER = new class_2338(8, -63, 8);
    private static final class_2338 PROGRESSION_MARKER = new class_2338(12, -63, 8);
    private static final class_2338 SAFETY_MARKER = new class_2338(14, -63, 8);
    private static final class_2338 BOSS_DEFEATED_MARKER = new class_2338(16, -63, 8);

    private static boolean arenaGenerated;
    private static boolean expanderGenerated;
    private static boolean progressionGenerated;
    private static boolean safetyDone;
    private static boolean bossDefeated;
    private static boolean seededFromWorld;

    private EchoDimensionPersistentState() {
    }

    public static EchoDimensionPersistentState get(class_3218 world) {
        if (!seededFromWorld && world != null) {
            seedFromWorld(world);
            seededFromWorld = true;
        }
        return Holder.INSTANCE;
    }

    private static void seedFromWorld(class_3218 world) {
        arenaGenerated = world.method_8320(ARENA_MARKER).method_27852(class_2246.field_9987);
        expanderGenerated = world.method_8320(EXPANDER_MARKER).method_27852(block("crying_obsidian"));
        progressionGenerated = world.method_8320(PROGRESSION_MARKER).method_27852(block("crying_obsidian"));
        safetyDone = world.method_8320(SAFETY_MARKER).method_27852(block("crying_obsidian"));
        bossDefeated = world.method_8320(BOSS_DEFEATED_MARKER).method_27852(block("crying_obsidian"));
    }

    public boolean isArenaGenerated() { return arenaGenerated; }
    public void setArenaGenerated(class_3218 world, boolean value) {
        arenaGenerated = value;
        if (value && world != null) {
            world.method_8501(ARENA_MARKER, class_2246.field_9987.method_9564());
        }
    }

    public boolean isExpanderGenerated() { return expanderGenerated; }
    public void setExpanderGenerated(class_3218 world, boolean value) {
        expanderGenerated = value;
        if (value && world != null) {
            world.method_8501(EXPANDER_MARKER, block("crying_obsidian").method_9564());
        }
    }

    public boolean isProgressionGenerated() { return progressionGenerated; }
    public void setProgressionGenerated(class_3218 world, boolean value) {
        progressionGenerated = value;
        if (value && world != null) {
            world.method_8501(PROGRESSION_MARKER, block("crying_obsidian").method_9564());
        }
    }

    public boolean isSafetyDone() { return safetyDone; }
    public void setSafetyDone(class_3218 world, boolean value) {
        safetyDone = value;
        if (value && world != null) {
            world.method_8501(SAFETY_MARKER, block("crying_obsidian").method_9564());
        }
    }

    public boolean isBossDefeated() { return bossDefeated; }
    public void setBossDefeated(class_3218 world, boolean value) {
        bossDefeated = value;
        if (value && world != null) {
            world.method_8501(BOSS_DEFEATED_MARKER, block("crying_obsidian").method_9564());
        }
    }

    public boolean setupComplete() {
        return arenaGenerated && expanderGenerated && progressionGenerated && safetyDone;
    }

    private static class_2248 block(String id) {
        return (class_2248)class_7923.field_41175.method_10223(class_2960.method_60655("minecraft", id));
    }

    private static final class Holder {
        private static final EchoDimensionPersistentState INSTANCE = new EchoDimensionPersistentState();
    }
}
