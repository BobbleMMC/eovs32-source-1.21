/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_3218
 */
package uz.echoes.world;

import net.minecraft.class_3218;
import uz.echoes.boss.EchoBossArenaTrigger;

public final class EchoBossWorldHook {
    private EchoBossWorldHook() {
    }

    public static void tickEchoWorld(class_3218 class_32182) {
        if (class_32182.method_8510() % 100L == 0L) {
            EchoBossArenaTrigger.ensureBossAtArena(class_32182);
        }
    }
}

