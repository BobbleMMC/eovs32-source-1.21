package uz.echoes.world;

import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import uz.echoes.block.EchoPortalBlock;
import uz.echoes.block.ModBlocks;
import uz.echoes.structure.EchoArenaChestFiller;

/**
 * Restores the original tall Echo citadel arena layout.
 *
 * Layout restored from the uploaded 1.0.1 source:
 * - round 40 radius arena at 0/80/0;
 * - 58-block tall citadel wall/crown;
 * - entrance bridge from negative Z into the arena;
 * - opposite-side 20x6 exit portal frame on positive Z;
 * - 8 sculk-shrieker regen pillars;
 * - 4 ground chests + 8 balcony chests with full randomized slots.
 */
public final class EchoArenaFixer {
    public static final class_2338 ARENA_CENTER = new class_2338(0, 80, 0);
    public static final class_2338 ALTAR_POS = new class_2338(0, 80, 0);
    public static final class_2338 PLAYER_BRIDGE_SPAWN = new class_2338(0, 82, -54);
    public static final class_2338 BOSS_SPAWN = new class_2338(0, 82, 0);

    public static final class_2338 MARKER_POS = new class_2338(0, 79, 0);
    public static final class_2338 TALL_MARKER_POS = new class_2338(1, 79, 0);
    public static final class_2338 REGEN_MARKER_POS = new class_2338(2, 79, 0);
    public static final class_2338 CLEANUP_MARKER_POS = new class_2338(3, 79, 0);

    public static final int FLOOR_Y = 80;
    public static final int OUTER_RADIUS = 40;
    public static final int INNER_RADIUS = 34;
    public static final int WALL_HEIGHT = 58;
    public static final int ROOF_RING_Y = 138;
    public static final int REGEN_SHRIEKER_Y = 123;

    public static final int EXIT_PORTAL_Z = 37;
    public static final int EXIT_PORTAL_INTERIOR_MIN_X = -10;
    public static final int EXIT_PORTAL_INTERIOR_Y = 81;
    public static final int EXIT_PORTAL_WIDTH = 20;
    public static final int EXIT_PORTAL_HEIGHT = 6;

    private EchoArenaFixer() {
    }

    public static class_2338 getArenaCenter() {
        return ARENA_CENTER;
    }

    public static class_2338 getPlayerBridgeSpawn() {
        return PLAYER_BRIDGE_SPAWN;
    }

    public static class_2338 getMarkerPos() {
        return MARKER_POS;
    }

    public static boolean isArenaGenerated(class_3218 world) {
        return world != null && world.method_8320(REGEN_MARKER_POS).method_27852(class_2246.field_9987);
    }

    public static void markArenaGenerated(class_3218 world) {
        if (world == null) {
            return;
        }
        world.method_8501(MARKER_POS, class_2246.field_9987.method_9564());
        world.method_8501(TALL_MARKER_POS, class_2246.field_9987.method_9564());
        world.method_8501(REGEN_MARKER_POS, class_2246.field_9987.method_9564());
        world.method_8501(CLEANUP_MARKER_POS, class_2246.field_9987.method_9564());
    }

    public static void generateArena(class_3218 world) {
        if (world == null) {
            return;
        }
        if (isArenaGenerated(world)) {
            ensureRoundCitadelSafety(world);
            return;
        }
        clearArenaAirVolume(world);
        buildRoundFoundation(world);
        buildRoundCitadelWalls(world);
        buildArenaFloorDetails(world);
        buildPhaseBalconies(world);
        buildDecoratedEntranceBridge(world);
        carveBridgeEntrance(world);
        clearBossBlockingBlocks(world);
        buildOppositeExitPortalFrame(world, EchoDimensionPersistentState.get(world).isBossDefeated());
        placeCenterAltar(world);
        placeLootPedestals(world);
        replaceFixedYLevelEndStoneAndDeepslateBricksWithStone(world);
        EchoSpawnPlatform.createPlatform(world, PLAYER_BRIDGE_SPAWN);
        markArenaGenerated(world);
    }

    public static void ensureArena(class_3218 world) { generateArena(world); }
    public static void ensureArenaGenerated(class_3218 world) { generateArena(world); }
    public static void fixArena(class_3218 world) { generateArena(world); }
    public static void repairArena(class_3218 world) { generateArena(world); }

    public static void ensureRoundCitadelSafety(class_3218 world) {
        if (world == null) {
            return;
        }
        buildDecoratedEntranceBridge(world);
        carveBridgeEntrance(world);
        buildOppositeExitPortalFrame(world, EchoDimensionPersistentState.get(world).isBossDefeated());
        replaceFixedYLevelEndStoneAndDeepslateBricksWithStone(world);
        EchoSpawnPlatform.createPlatform(world, PLAYER_BRIDGE_SPAWN);
        clearBossBlockingBlocks(world);
        if (!EchoArenaChestBossTrigger.isTriggered(world) && !hasLivingBossMarkerOnly(world)) {
            if (!world.method_8320(ALTAR_POS).method_27852(ModBlocks.ECHO_ALTAR)) {
                placeCenterAltar(world);
            }
        }
    }

    private static boolean hasLivingBossMarkerOnly(class_3218 world) {
        // Kept deliberately conservative; the runtime boss check lives in the
        // trigger/cycle classes. This method only prevents altar replacement when
        // the chest-trigger marker is present.
        return EchoArenaChestBossTrigger.isTriggered(world);
    }

    private static boolean inCircle(int x, int z, int radius) {
        return x * x + z * z <= radius * radius;
    }

    private static boolean inRing(int x, int z, int inner, int outer) {
        int d2 = x * x + z * z;
        return d2 >= inner * inner && d2 <= outer * outer;
    }

    private static boolean onSmoothOuterEdge(int x, int z) {
        int d2 = x * x + z * z;
        return d2 >= 1444 && d2 <= 1600;
    }

    private static void clearArenaAirVolume(class_3218 world) {
        class_2680 air = class_2246.field_10124.method_9564();
        for (int x = -42; x <= 42; ++x) {
            for (int z = -42; z <= 42; ++z) {
                if (!inCircle(x, z, 42)) {
                    continue;
                }
                for (int y = 81; y <= 132; ++y) {
                    world.method_8501(new class_2338(x, y, z), air);
                }
            }
        }
        for (int x = -10; x <= 10; ++x) {
            for (int z = -104; z <= -34; ++z) {
                for (int y = 82; y <= 96; ++y) {
                    world.method_8501(new class_2338(x, y, z), air);
                }
            }
        }
        for (int x = -10; x <= 10; ++x) {
            for (int z = -10; z <= 10; ++z) {
                for (int y = 80; y <= 142; ++y) {
                    world.method_8501(new class_2338(x, y, z), air);
                }
            }
        }
    }

    private static void buildRoundFoundation(class_3218 world) {
        class_2680 reinforced = class_2246.field_38420.method_9564();
        class_2680 deepslate = class_2246.field_28896.method_9564();
        class_2680 sculk = class_2246.field_37568.method_9564();
        class_2680 stone = block("stone").method_9564();
        class_2680 bedrock = class_2246.field_9987.method_9564();
        for (int x = -40; x <= 40; ++x) {
            for (int z = -40; z <= 40; ++z) {
                if (!inCircle(x, z, 40)) {
                    continue;
                }
                class_2338 floor = new class_2338(x, 80, z);
                world.method_8501(floor.method_10087(4), bedrock);
                world.method_8501(floor.method_10087(3), bedrock);
                // Old jar used an end-stone support band here. Per request,
                // that fixed Y-level support band is converted to stone.
                world.method_8501(floor.method_10087(2), stone);
                world.method_8501(floor.method_10074(), deepslate);
                int d2 = x * x + z * z;
                boolean rune = Math.abs(x) <= 1 || Math.abs(z) <= 1 || Math.abs(d2 - 324) < 28;
                boolean center = Math.abs(x) <= 4 && Math.abs(z) <= 4;
                world.method_8501(floor, center ? ModBlocks.SCULK_REINFORCED_STONE.method_9564() : (rune ? sculk : reinforced));
            }
        }
    }

    private static void buildRoundCitadelWalls(class_3218 world) {
        class_2680 deepslateBricks = class_2246.field_28892.method_9564();
        class_2680 deepslateTiles = class_2246.field_28900.method_9564();
        class_2680 reinforced = class_2246.field_38420.method_9564();
        class_2680 sculk = class_2246.field_37568.method_9564();
        class_2680 glass = class_2246.field_27115.method_9564();
        for (int y = 1; y <= WALL_HEIGHT; ++y) {
            for (int x = -40; x <= 40; ++x) {
                for (int z = -40; z <= 40; ++z) {
                    if (!inRing(x, z, INNER_RADIUS, OUTER_RADIUS)) {
                        continue;
                    }
                    boolean entrance = z < -34 && Math.abs(x) <= 5 && y <= 15;
                    boolean exit = z > 34 && Math.abs(x) <= 12 && y <= 9;
                    if (entrance || exit) {
                        continue;
                    }
                    double angle = Math.atan2(z, x);
                    boolean rib = Math.abs(angle * 8.0 / Math.PI - Math.round(angle * 8.0 / Math.PI)) < 0.045;
                    boolean ring = y == WALL_HEIGHT || y == WALL_HEIGHT - 1 || y % 14 == 0;
                    boolean sculkBand = y % 11 == 0;
                    class_2338 pos = new class_2338(x, 80 + y, z);
                    if (rib || ring) {
                        world.method_8501(pos, reinforced);
                    } else if (sculkBand && onSmoothOuterEdge(x, z)) {
                        world.method_8501(pos, sculk);
                    } else if (y > 48 && inRing(x, z, 35, 38)) {
                        world.method_8501(pos, glass);
                    } else {
                        world.method_8501(pos, deepslateBricks);
                    }
                }
            }
        }
        for (int x = -40; x <= 40; ++x) {
            for (int z = -40; z <= 40; ++z) {
                if (!inRing(x, z, 37, 40)) {
                    continue;
                }
                world.method_8501(new class_2338(x, 139, z), deepslateTiles);
                if ((x + z) % 5 == 0) {
                    world.method_8501(new class_2338(x, 140, z), reinforced);
                }
            }
        }
        int[][] spires = new int[][]{{0, -40}, {40, 0}, {0, 40}, {-40, 0}};
        for (int[] spire : spires) {
            for (int y = 54; y <= 70; ++y) {
                for (int dx = -1; dx <= 1; ++dx) {
                    for (int dz = -1; dz <= 1; ++dz) {
                        world.method_8501(new class_2338(spire[0] + dx, 80 + y, spire[1] + dz), reinforced);
                    }
                }
            }
            world.method_8501(new class_2338(spire[0], 151, spire[1]), class_2246.field_37571.method_9564());
        }
    }

    private static void buildArenaFloorDetails(class_3218 world) {
        int pillarRadius = 25;
        for (int i = 0; i < 8; ++i) {
            double angle = Math.PI * 2.0 * (double)i / 8.0;
            int px = (int)Math.round(Math.cos(angle) * (double)pillarRadius);
            int pz = (int)Math.round(Math.sin(angle) * (double)pillarRadius);
            for (int y = 1; y <= 42; ++y) {
                class_2680 state = y % 9 == 0 ? class_2246.field_38420.method_9564() : class_2246.field_28892.method_9564();
                for (int dx = -1; dx <= 1; ++dx) {
                    for (int dz = -1; dz <= 1; ++dz) {
                        world.method_8501(new class_2338(px + dx, 80 + y, pz + dz), state);
                    }
                }
            }
            world.method_8501(new class_2338(px, REGEN_SHRIEKER_Y, pz), class_2246.field_37571.method_9564());
        }
        for (int x = -8; x <= 8; ++x) {
            for (int z = -8; z <= 8; ++z) {
                for (int y = 2; y <= 36; ++y) {
                    world.method_8501(new class_2338(x, 80 + y, z), class_2246.field_10124.method_9564());
                }
            }
        }
    }

    private static void buildPhaseBalconies(class_3218 world) {
        int[] ys = new int[]{98, 112, 126};
        for (int y : ys) {
            for (int x = -40; x <= 40; ++x) {
                for (int z = -40; z <= 40; ++z) {
                    if (inRing(x, z, 28, 34)) {
                        world.method_8501(new class_2338(x, y, z), class_2246.field_28896.method_9564());
                    }
                    if (inRing(x, z, 27, 27) || inRing(x, z, 35, 35)) {
                        world.method_8501(new class_2338(x, y + 1, z), class_2246.field_10364.method_9564());
                    }
                }
            }
        }
        int[][] chestOffsets = new int[][]{{0, -31}, {31, 0}, {0, 31}, {-31, 0}};
        for (int[] offset : chestOffsets) {
            EchoArenaChestFiller.placeArenaChest(world, new class_2338(offset[0], 99, offset[1]), true);
            EchoArenaChestFiller.placeArenaChest(world, new class_2338(offset[0], 113, offset[1]), true);
        }
    }

    private static void buildDecoratedEntranceBridge(class_3218 world) {
        for (int z = -96; z <= -40; ++z) {
            for (int x = -4; x <= 4; ++x) {
                class_2680 floor = Math.abs(x) == 4 ? class_2246.field_10266.method_9564() : class_2246.field_38420.method_9564();
                world.method_8501(new class_2338(x, 81, z), floor);
                world.method_8501(new class_2338(x, 80, z), class_2246.field_28896.method_9564());
            }
            world.method_8501(new class_2338(-5, 82, z), class_2246.field_10364.method_9564());
            world.method_8501(new class_2338(5, 82, z), class_2246.field_10364.method_9564());
            if (z % 8 == 0) {
                for (int y = 20; y <= 81; ++y) {
                    world.method_8501(new class_2338(-5, y, z), class_2246.field_10266.method_9564());
                    world.method_8501(new class_2338(5, y, z), class_2246.field_10266.method_9564());
                }
                world.method_8501(new class_2338(-5, 83, z), class_2246.field_22110.method_9564());
                world.method_8501(new class_2338(5, 83, z), class_2246.field_22110.method_9564());
            }
        }
        for (int x = -7; x <= 7; ++x) {
            for (int z = -98; z <= -86; ++z) {
                world.method_8501(new class_2338(x, 81, z), class_2246.field_38420.method_9564());
                world.method_8501(new class_2338(x, 80, z), class_2246.field_28896.method_9564());
                for (int y = 82; y <= 89; ++y) {
                    world.method_8501(new class_2338(x, y, z), class_2246.field_10124.method_9564());
                }
            }
        }
    }

    private static void carveBridgeEntrance(class_3218 world) {
        // Exact requested connector cut: rectangular 10x11 entrance between
        // the relocated negative-Z bridge and the arena interior.
        for (int z = -44; z <= -34; ++z) {
            for (int x = -5; x <= 4; ++x) {
                for (int y = 1; y <= 11; ++y) {
                    world.method_8652(new class_2338(x, 80 + y, z), class_2246.field_10124.method_9564(), 3);
                }
            }
        }
    }

    private static void clearBossBlockingBlocks(class_3218 world) {
        for (int x = -4; x <= 4; ++x) {
            for (int z = -4; z <= 4; ++z) {
                // Keep the floor intact; only clear boss head/body space.
                world.method_8652(new class_2338(x, 81, z), class_2246.field_10124.method_9564(), 3);
                world.method_8652(new class_2338(x, 82, z), class_2246.field_10124.method_9564(), 3);
                world.method_8652(new class_2338(x, 83, z), class_2246.field_10124.method_9564(), 3);
            }
        }
        world.method_8652(MARKER_POS, class_2246.field_9987.method_9564(), 3);
    }

    public static void ensureCenterAltar(class_3218 world) {
        placeCenterAltar(world);
    }

    private static void placeCenterAltar(class_3218 world) {
        clearBossBlockingBlocks(world);
        // Restore the old jar-style altar layout: Echo Altar in the center floor
        // at Y=80, with altar decorations one block above it.
        for (int dx = -2; dx <= 2; ++dx) {
            for (int dz = -2; dz <= 2; ++dz) {
                world.method_8501(new class_2338(dx, 80, dz), ModBlocks.SCULK_REINFORCED_STONE.method_9564());
            }
        }
        world.method_8501(ALTAR_POS, ModBlocks.ECHO_ALTAR.method_9564());
        world.method_8501(ALTAR_POS.method_10084(), class_2246.field_10124.method_9564());
        world.method_8501(ALTAR_POS.method_10069(1, 1, 0), class_2246.field_28108.method_9564());
        world.method_8501(ALTAR_POS.method_10069(-1, 1, 0), class_2246.field_28108.method_9564());
        world.method_8501(ALTAR_POS.method_10069(0, 1, 1), class_2246.field_37571.method_9564());
        world.method_8501(ALTAR_POS.method_10069(0, 1, -1), class_2246.field_37571.method_9564());
    }

    private static void placeLootPedestals(class_3218 world) {
        int[][] positions = new int[][]{{-22, 0}, {22, 0}, {0, -22}, {0, 22}};
        for (int[] p : positions) {
            class_2338 chestPos = new class_2338(p[0], 81, p[1]);
            world.method_8501(chestPos.method_10074(), class_2246.field_38420.method_9564());
            EchoArenaChestFiller.placeArenaChest(world, chestPos, false);
        }
    }

    private static void replaceFixedYLevelEndStoneAndDeepslateBricksWithStone(class_3218 world) {
        if (world == null) {
            return;
        }
        class_2680 stone = block("stone").method_9564();
        class_2248 endStone = block("end_stone");
        class_2248 deepslateBricks = block("deepslate_bricks");
        class_2248 deepslateTiles = block("deepslate_tiles");
        // Flat-terrain layers that used to show end-stone / deepslate-brick-like
        // bands around the arena are normalized to stone near the gameplay area.
        for (int y = 43; y <= 60; ++y) {
            for (int x = -48; x <= 48; ++x) {
                for (int z = -104; z <= 48; ++z) {
                    boolean inArena = inCircle(x, z, 46);
                    boolean inBridge = Math.abs(x) <= 12 && z >= -104 && z <= -34;
                    if (!inArena && !inBridge) {
                        continue;
                    }
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 state = world.method_8320(pos);
                    if (state.method_27852(endStone) || state.method_27852(deepslateBricks) || state.method_27852(deepslateTiles)) {
                        world.method_8501(pos, stone);
                    }
                }
            }
        }
    }

    public static void buildOppositeExitPortalFrame(class_3218 world, boolean openPortal) {
        if (world == null) {
            return;
        }
        class_2680 frame = class_2246.field_38420.method_9564();
        class_2680 air = class_2246.field_10124.method_9564();
        class_2680 portal = (class_2680)ModBlocks.ECHO_PORTAL.method_9564().method_11657(EchoPortalBlock.AXIS, class_2350.class_2351.field_11048);

        int minX = EXIT_PORTAL_INTERIOR_MIN_X;
        int maxX = minX + EXIT_PORTAL_WIDTH - 1;
        int minY = EXIT_PORTAL_INTERIOR_Y;
        int maxY = minY + EXIT_PORTAL_HEIGHT - 1;
        int z = EXIT_PORTAL_Z;

        // Clear the arena-facing side first. The inside of the frame must stay open,
        // not sealed by reinforced deepslate.
        for (int x = minX - 3; x <= maxX + 3; ++x) {
            for (int y = minY - 1; y <= maxY + 2; ++y) {
                for (int dz = -3; dz <= 1; ++dz) {
                    world.method_8652(new class_2338(x, y, z + dz), air, 3);
                }
            }
        }

        for (int x = minX - 1; x <= maxX + 1; ++x) {
            world.method_8652(new class_2338(x, minY - 1, z), frame, 3);
            world.method_8652(new class_2338(x, maxY + 1, z), frame, 3);
        }
        for (int y = minY; y <= maxY; ++y) {
            world.method_8652(new class_2338(minX - 1, y, z), frame, 3);
            world.method_8652(new class_2338(maxX + 1, y, z), frame, 3);
        }
        for (int x = minX; x <= maxX; ++x) {
            for (int y = minY; y <= maxY; ++y) {
                world.method_8652(new class_2338(x, y, z), openPortal ? portal : air, 3);
            }
        }
    }

    public static void openExitPortal(class_3218 world) {
        buildOppositeExitPortalFrame(world, true);
    }

    private static class_2248 block(String id) {
        return (class_2248)class_7923.field_41175.method_10223(class_2960.method_60655("minecraft", id));
    }
}
