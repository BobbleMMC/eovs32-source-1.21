/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_1935
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2586
 *  net.minecraft.class_2595
 *  net.minecraft.class_2680
 *  net.minecraft.class_2960
 *  net.minecraft.class_3218
 *  net.minecraft.class_52
 *  net.minecraft.class_5321
 *  net.minecraft.class_7923
 *  net.minecraft.class_7924
 */
package uz.echoes.world;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import uz.echoes.block.ModBlocks;
import uz.echoes.item.ModItems;

public final class EchoDimensionExpander {
    private static final class_2338 MARKER = new class_2338(8, -63, 8);
    private static final class_2338 MARKER_V2 = new class_2338(10, -63, 8);
    private static final class_2338 MARKER_V3 = new class_2338(12, -63, 8);
    private static final class_2338 MARKER_V4_STRUCTURES = new class_2338(14, -63, 8);
    private static final class_2338 MARKER_V5_STRUCTURE_DENSITY = new class_2338(16, -63, 8);
    private static final int STRUCTURE_SPAWN_RADIUS = 100000;
    private static final int STRUCTURE_DENSITY_DIVISOR = 4;
    private static final int[][] MINI_ALTAR_BASES = new int[][]{{144, 70, -48}, {-142, 68, 76}, {64, 72, 168}, {238, 74, -166}, {-246, 70, 210}, {28, 72, -236}};
    private static final int[][] ECHO_SHRINE_BASES = new int[][]{{92, 66, 112}, {-96, 65, -118}, {188, 72, 86}, {-184, 70, -36}, {266, 74, 146}, {-268, 69, -156}, {56, 68, -248}, {-48, 72, 244}};
    private static final class_5321<class_52> COMMON_LOOT = class_5321.method_29179((class_5321)class_7924.field_50079, (class_2960)class_2960.method_60655((String)"eovs32", (String)"chests/echo_arena_common_chest"));
    private static final class_5321<class_52> RARE_LOOT = class_5321.method_29179((class_5321)class_7924.field_50079, (class_2960)class_2960.method_60655((String)"eovs32", (String)"chests/echo_arena_rare_treasure"));

    private EchoDimensionExpander() {
    }

    public static void ensureGenerated(class_3218 class_32182) {
        if (class_32182.method_8320(MARKER).method_27852(EchoDimensionExpander.block("crying_obsidian"))) {
            EchoDimensionExpander.ensureV2Generated(class_32182);
            EchoDimensionExpander.ensureV3Cleaned(class_32182);
            EchoDimensionExpander.ensureV4Structures(class_32182);
            EchoDimensionExpander.ensureV5StructureDensity(class_32182);
            return;
        }
        EchoDimensionExpander.buildBedrockSample(class_32182);
        EchoDimensionExpander.buildBrokenBridges(class_32182);
        EchoDimensionExpander.buildSculkTowers(class_32182);
        EchoDimensionExpander.buildWardenFossils(class_32182);
        EchoDimensionExpander.buildFloatingOreIslands(class_32182);
        EchoDimensionExpander.buildBiomeIdentityFields(class_32182);
        EchoDimensionExpander.cleanupSmallStructures(class_32182);
        EchoDimensionExpander.buildMiniAltars(class_32182);
        EchoDimensionExpander.buildEchoShrines(class_32182);
        EchoDimensionExpander.buildV5StructureDensity(class_32182);
        EchoDimensionExpander.cleanupWaterSurfaceSculkDevices(class_32182);
        class_32182.method_8501(MARKER, EchoDimensionExpander.block("crying_obsidian").method_9564());
        class_32182.method_8501(MARKER_V2, EchoDimensionExpander.block("crying_obsidian").method_9564());
        class_32182.method_8501(MARKER_V3, EchoDimensionExpander.block("crying_obsidian").method_9564());
        class_32182.method_8501(MARKER_V4_STRUCTURES, EchoDimensionExpander.block("crying_obsidian").method_9564());
        class_32182.method_8501(MARKER_V5_STRUCTURE_DENSITY, EchoDimensionExpander.block("crying_obsidian").method_9564());
    }

    private static void ensureV2Generated(class_3218 class_32182) {
        if (class_32182.method_8320(MARKER_V2).method_27852(EchoDimensionExpander.block("crying_obsidian"))) {
            return;
        }
        EchoDimensionExpander.buildBiomeIdentityFields(class_32182);
        class_32182.method_8501(MARKER_V2, EchoDimensionExpander.block("crying_obsidian").method_9564());
    }

    private static void ensureV3Cleaned(class_3218 class_32182) {
        if (class_32182.method_8320(MARKER_V3).method_27852(EchoDimensionExpander.block("crying_obsidian"))) {
            return;
        }
        EchoDimensionExpander.cleanupSmallStructures(class_32182);
        EchoDimensionExpander.cleanupWaterSurfaceSculkDevices(class_32182);
        class_32182.method_8501(MARKER_V3, EchoDimensionExpander.block("crying_obsidian").method_9564());
    }

    private static void ensureV4Structures(class_3218 class_32182) {
        if (class_32182.method_8320(MARKER_V4_STRUCTURES).method_27852(EchoDimensionExpander.block("crying_obsidian"))) {
            return;
        }
        EchoDimensionExpander.cleanupSmallStructures(class_32182);
        EchoDimensionExpander.buildMiniAltars(class_32182);
        EchoDimensionExpander.buildEchoShrines(class_32182);
        class_32182.method_8501(MARKER_V4_STRUCTURES, EchoDimensionExpander.block("crying_obsidian").method_9564());
    }

    private static void ensureV5StructureDensity(class_3218 class_32182) {
        if (class_32182.method_8320(MARKER_V5_STRUCTURE_DENSITY).method_27852(EchoDimensionExpander.block("crying_obsidian"))) {
            return;
        }
        EchoDimensionExpander.buildV5StructureDensity(class_32182);
        class_32182.method_8501(MARKER_V5_STRUCTURE_DENSITY, EchoDimensionExpander.block("crying_obsidian").method_9564());
    }

    private static void buildV5StructureDensity(class_3218 class_32182) {
        // Extra mini structures added after v4.1: doubles the known mini altar
        // and shrine count without deleting existing worlds' generated content.
        EchoDimensionExpander.buildExtraMiniAltars(class_32182);
        EchoDimensionExpander.buildExtraEchoShrines(class_32182);
    }

    private static void buildBedrockSample(class_3218 class_32182) {
        // Terrain now comes from the Echo Overworld-style noise settings.
    }

    private static void buildMiniAltars(class_3218 class_32182) {
        EchoDimensionExpander.placeMiniAltarBatch(class_32182, EchoDimensionExpander.wideSparsePositions(MINI_ALTAR_BASES, 11), 0);
    }

    private static void buildExtraMiniAltars(class_3218 class_32182) {
        EchoDimensionExpander.placeMiniAltarBatch(class_32182, EchoDimensionExpander.wideSparsePositions(MINI_ALTAR_BASES, 211), 100);
    }

    private static void placeMiniAltarBatch(class_3218 class_32182, int[][] nArrayArray, int lootOffset) {
        for (int i = 0; i < nArrayArray.length; ++i) {
            int[] nArray = nArrayArray[i];
            class_2338 class_23382 = EchoDimensionExpander.surfaceCenter(class_32182, new class_2338(nArray[0], nArray[1], nArray[2]));
            EchoDimensionExpander.platform(class_32182, class_23382, 7, EchoDimensionExpander.state("polished_deepslate"));
            EchoDimensionExpander.ring(class_32182, class_23382, 7, ModBlocks.SCULK_REINFORCED_STONE.method_9564());
            EchoDimensionExpander.ring(class_32182, class_23382.method_10084(), 5, EchoDimensionExpander.state("deepslate_tiles"));
            for (int step = 0; step <= 2; ++step) {
                EchoDimensionExpander.ring(class_32182, class_23382.method_10086(step), 3 - step, step == 0 ? EchoDimensionExpander.state("chiseled_deepslate") : EchoDimensionExpander.state("reinforced_deepslate"));
            }
            for (int axis = -5; axis <= 5; axis += 10) {
                class_32182.method_8501(class_23382.method_10069(axis, 1, 0), ModBlocks.VOID_GLASS.method_9564());
                class_32182.method_8501(class_23382.method_10069(0, 1, axis), ModBlocks.VOID_GLASS.method_9564());
                class_32182.method_8501(class_23382.method_10069(axis, 2, 0), ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
                class_32182.method_8501(class_23382.method_10069(0, 2, axis), ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
            }
            class_32182.method_8501(class_23382.method_10084(), ModBlocks.ECHO_ALTAR.method_9564());
            class_32182.method_8501(class_23382.method_10069(0, 2, 0), ModBlocks.VOID_GLASS.method_9564());
            class_32182.method_8501(class_23382.method_10069(0, 3, 0), ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
            EchoDimensionExpander.placeFilledChest(class_32182, class_23382.method_10069(2, 1, 0), true, lootOffset + i);
        }
    }

    private static void buildEchoShrines(class_3218 class_32182) {
        EchoDimensionExpander.placeEchoShrineBatch(class_32182, EchoDimensionExpander.wideSparsePositions(ECHO_SHRINE_BASES, 23));
    }

    private static void buildExtraEchoShrines(class_3218 class_32182) {
        EchoDimensionExpander.placeEchoShrineBatch(class_32182, EchoDimensionExpander.wideSparsePositions(ECHO_SHRINE_BASES, 223));
    }

    private static void placeEchoShrineBatch(class_3218 class_32182, int[][] nArrayArray) {
        for (int[] nArray : nArrayArray) {
            class_2338 class_23382 = EchoDimensionExpander.surfaceCenter(class_32182, new class_2338(nArray[0], nArray[1], nArray[2]));
            EchoDimensionExpander.platform(class_32182, class_23382, 5, ModBlocks.SCULK_REINFORCED_STONE.method_9564());
            EchoDimensionExpander.ring(class_32182, class_23382.method_10084(), 5, EchoDimensionExpander.state("deepslate_bricks"));
            EchoDimensionExpander.ring(class_32182, class_23382.method_10086(2), 4, EchoDimensionExpander.state("deepslate_tiles"));
            for (int i = 1; i <= 7; ++i) {
                class_2680 pillar = i % 2 == 0 ? EchoDimensionExpander.state("polished_deepslate") : EchoDimensionExpander.state("reinforced_deepslate");
                class_32182.method_8501(class_23382.method_10069(-4, i, -4), pillar);
                class_32182.method_8501(class_23382.method_10069(4, i, -4), pillar);
                class_32182.method_8501(class_23382.method_10069(-4, i, 4), pillar);
                class_32182.method_8501(class_23382.method_10069(4, i, 4), pillar);
            }
            for (int x = -2; x <= 2; ++x) {
                class_32182.method_8501(class_23382.method_10069(x, 5, -4), ModBlocks.VOID_GLASS.method_9564());
                class_32182.method_8501(class_23382.method_10069(x, 5, 4), ModBlocks.VOID_GLASS.method_9564());
                class_32182.method_8501(class_23382.method_10069(-4, 5, x), ModBlocks.VOID_GLASS.method_9564());
                class_32182.method_8501(class_23382.method_10069(4, 5, x), ModBlocks.VOID_GLASS.method_9564());
            }
            class_32182.method_8501(class_23382.method_10069(0, 1, 0), EchoDimensionExpander.state("sculk_catalyst"));
            class_32182.method_8501(class_23382.method_10069(0, 2, 0), ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
            class_32182.method_8501(class_23382.method_10069(0, 6, 0), ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
            EchoDimensionExpander.placeLootChest(class_32182, class_23382.method_10069(0, 1, -4), COMMON_LOOT);
        }
    }

    private static void buildBrokenBridges(class_3218 class_32182) {
        for (int[] center : EchoDimensionExpander.wideSparsePositions(new int[][]{{118, 70, 103}, {-120, 70, -132}, {220, 72, -84}, {-224, 72, 116}}, 97)) {
            for (int offset = -45; offset <= 45; ++offset) {
                if (offset % 11 == 0 || offset % 13 == 0) continue;
                for (int width = -2; width <= 2; ++width) {
                    int x = center[0] + width;
                    int z = center[2] + offset;
                    int y = EchoDimensionExpander.surfaceY(class_32182, x, z);
                    class_32182.method_8501(new class_2338(x, y, z), Math.abs(width) == 2 ? ModBlocks.SCULK_REINFORCED_STONE.method_9564() : ModBlocks.VOID_GLASS.method_9564());
                }
            }
        }
    }

    private static void buildSculkTowers(class_3218 class_32182) {
        int[][] nArrayArray;
        for (int[] nArray : nArrayArray = EchoDimensionExpander.wideSparsePositions(new int[][]{{-52, 66, 154}, {176, 68, -144}, {-210, 70, 114}, {34, 64, -204}}, 37)) {
            class_2338 class_23382 = EchoDimensionExpander.surfaceCenter(class_32182, new class_2338(nArray[0], nArray[1], nArray[2]));
            for (int i = 0; i <= 22; ++i) {
                for (int j = -1; j <= 1; ++j) {
                    for (int k = -1; k <= 1; ++k) {
                        class_32182.method_8501(class_23382.method_10069(j, i, k), i % 5 == 0 ? EchoDimensionExpander.state("sculk_shrieker") : ModBlocks.SCULK_REINFORCED_STONE.method_9564());
                    }
                }
            }
            class_32182.method_8501(class_23382.method_10069(0, 23, 0), EchoDimensionExpander.state("sculk_sensor"));
        }
    }

    private static void buildWardenFossils(class_3218 class_32182) {
        int[][] nArrayArray;
        for (int[] nArray : nArrayArray = EchoDimensionExpander.wideSparsePositions(new int[][]{{-130, 64, 160}, {166, 66, 34}, {-58, 62, -184}}, 41)) {
            class_2338 class_23382 = EchoDimensionExpander.surfaceCenter(class_32182, new class_2338(nArray[0], nArray[1], nArray[2]));
            for (int i = -10; i <= 10; ++i) {
                class_32182.method_8501(class_23382.method_10069(i, 0, 0), EchoDimensionExpander.state("bone_block"));
                if (i % 3 != 0) continue;
                for (int j = 1; j <= 5; ++j) {
                    class_32182.method_8501(class_23382.method_10069(i, j, j), EchoDimensionExpander.state("bone_block"));
                    class_32182.method_8501(class_23382.method_10069(i, j, -j), EchoDimensionExpander.state("bone_block"));
                }
            }
            EchoDimensionExpander.placeLootChest(class_32182, class_23382.method_10069(0, 1, 3), COMMON_LOOT);
        }
    }

    private static void buildFloatingOreIslands(class_3218 class_32182) {
        int[][] nArrayArray;
        for (int[] nArray : nArrayArray = EchoDimensionExpander.wideSparsePositions(new int[][]{{210, 92, 0}, {-210, 96, -92}, {32, 104, 226}, {-44, 88, -228}}, 53)) {
            class_2338 class_23382 = EchoDimensionExpander.surfaceCenter(class_32182, new class_2338(nArray[0], nArray[1], nArray[2]));
            for (int i = -7; i <= 7; ++i) {
                for (int j = -7; j <= 7; ++j) {
                    for (int k = -2; k <= 1; ++k) {
                        int n = i * i + j * j + k * k * 5;
                        if (n > 54) continue;
                        class_2680 class_26802 = n < 12 && k >= 0 ? ModBlocks.ECHO_ORE.method_9564() : (k == -2 ? EchoDimensionExpander.state("sculk") : ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
                        class_32182.method_8501(class_23382.method_10069(i, k, j), class_26802);
                    }
                }
            }
            class_32182.method_8501(class_23382.method_10069(0, 2, 0), ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
            EchoDimensionExpander.placeLootChest(class_32182, class_23382.method_10069(2, 2, 0), RARE_LOOT);
        }
    }

    private static void buildBiomeIdentityFields(class_3218 class_32182) {
        int n;
        int[][] nArrayArray;
        int[][] nArrayArray2 = nArrayArray = EchoDimensionExpander.wideSparsePositions(new int[][]{{-84, 64, -78}, {-122, 67, 28}, {-36, 63, 126}, {86, 65, -176}, {-176, 66, -154}, {152, 68, 148}}, 67);
        int n2 = nArrayArray2.length;
        for (n = 0; n < n2; ++n) {
            int[] nArray = nArrayArray2[n];
            EchoDimensionExpander.sculkField(class_32182, new class_2338(nArray[0], nArray[1], nArray[2]), 13);
        }
        int[][] nArrayArray3 = nArrayArray2 = EchoDimensionExpander.wideSparsePositions(new int[][]{{74, 70, 78}, {138, 76, -62}, {-154, 72, 92}, {-88, 74, -206}, {222, 86, 126}}, 79);
        n = nArrayArray3.length;
        for (int i = 0; i < n; ++i) {
            int[] nArray = nArrayArray3[i];
            EchoDimensionExpander.crystalCluster(class_32182, new class_2338(nArray[0], nArray[1], nArray[2]), 8);
        }
        for (int[] nArray : nArrayArray3 = EchoDimensionExpander.wideSparsePositions(new int[][]{{-238, 65, 18}, {196, 67, 208}, {-16, 64, 238}, {242, 68, -214}}, 83)) {
            EchoDimensionExpander.ribScatter(class_32182, new class_2338(nArray[0], nArray[1], nArray[2]));
        }
    }

    private static void sculkField(class_3218 class_32182, class_2338 class_23382, int n) {
        class_23382 = EchoDimensionExpander.surfaceCenter(class_32182, class_23382);
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                int n2 = i * i + j * j;
                if (n2 > n * n || n2 % 3 == 1) continue;
                class_2338 class_23383 = class_23382.method_10069(i, 0, j);
                class_32182.method_8501(class_23383, EchoDimensionExpander.state("sculk"));
                if (n2 % 11 == 0) {
                    EchoDimensionExpander.placeDrySculkDevice(class_32182, class_23383.method_10084(), EchoDimensionExpander.state("sculk_sensor"));
                    continue;
                }
                if (n2 % 17 == 0) {
                    EchoDimensionExpander.placeDrySculkDevice(class_32182, class_23383.method_10084(), EchoDimensionExpander.state("sculk_shrieker"));
                    continue;
                }
                if (n2 % 23 != 0) continue;
                class_32182.method_8501(class_23383.method_10084(), EchoDimensionExpander.state("sculk_catalyst"));
            }
        }
    }

    private static void crystalCluster(class_3218 class_32182, class_2338 class_23382, int n) {
        class_23382 = EchoDimensionExpander.surfaceCenter(class_32182, class_23382);
        EchoDimensionExpander.platform(class_32182, class_23382, n, ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
        for (int i = -n; i <= n; i += 3) {
            int n2 = 2 + Math.abs(i) % 5;
            for (int j = 1; j <= n2; ++j) {
                class_32182.method_8501(class_23382.method_10069(i, j, n - Math.abs(i / 2)), ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
                class_32182.method_8501(class_23382.method_10069(-i, j, -n + Math.abs(i / 2)), ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
            }
        }
        EchoDimensionExpander.placeLootChest(class_32182, class_23382.method_10069(0, 1, 0), RARE_LOOT);
    }

    private static void ribScatter(class_3218 class_32182, class_2338 class_23382) {
        class_23382 = EchoDimensionExpander.surfaceCenter(class_32182, class_23382);
        for (int i = -14; i <= 14; ++i) {
            class_32182.method_8501(class_23382.method_10069(i, 0, 0), EchoDimensionExpander.state("bone_block"));
            if (i % 4 != 0) continue;
            for (int j = 1; j <= 7; ++j) {
                class_32182.method_8501(class_23382.method_10069(i, j, j / 2), EchoDimensionExpander.state("bone_block"));
                class_32182.method_8501(class_23382.method_10069(i, j, -j / 2), EchoDimensionExpander.state("bone_block"));
            }
        }
        EchoDimensionExpander.placeLootChest(class_32182, class_23382.method_10069(0, 1, 4), COMMON_LOOT);
    }

    private static void placeFilledChest(class_3218 class_32182, class_2338 class_23382, boolean bl, int n) {
        class_32182.method_8652(class_23382, class_2246.field_10124.method_9564(), 3);
        class_32182.method_8652(class_23382, class_2246.field_10034.method_9564(), 3);
        class_2586 class_25862 = class_32182.method_8321(class_23382);
        if (!(class_25862 instanceof class_2595)) {
            return;
        }
        class_2595 class_25952 = (class_2595)class_25862;
        class_25952.method_5447(0, new class_1799((class_1935)ModItems.ECHO_FRAGMENT, bl ? 1 : 0));
        class_25952.method_5447(1, new class_1799((class_1935)ModItems.ECHOENERGY_STONE, n == 2 ? 2 : 1));
        class_25952.method_5447(2, new class_1799((class_1935)ModItems.ECHO_KEY, 1));
        class_25952.method_5447(3, new class_1799((class_1935)ModItems.ECHO_CRYSTAL_SHARD, 4 + n * 2));
    }

    private static void placeLootChest(class_3218 class_32182, class_2338 class_23382, class_5321<class_52> class_53212) {
        class_32182.method_8652(class_23382, class_2246.field_10124.method_9564(), 3);
        class_32182.method_8652(class_23382, class_2246.field_10034.method_9564(), 3);
        class_2586 class_25862 = class_32182.method_8321(class_23382);
        if (class_25862 instanceof class_2595) {
            ((class_2595)class_25862).method_54867(class_53212, class_32182.method_8409().method_43055());
        }
    }

    private static void platform(class_3218 class_32182, class_2338 class_23382, int n, class_2680 class_26802) {
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                if (i * i + j * j > n * n) continue;
                class_32182.method_8501(class_23382.method_10069(i, 0, j), class_26802);
                class_32182.method_8501(class_23382.method_10069(i, -1, j), EchoDimensionExpander.state("deepslate"));
            }
        }
    }

    private static void ring(class_3218 class_32182, class_2338 class_23382, int n, class_2680 class_26802) {
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                int n2 = i * i + j * j;
                if (n2 < (n - 1) * (n - 1) || n2 > n * n) continue;
                class_32182.method_8501(class_23382.method_10069(i, 1, j), class_26802);
            }
        }
    }

    private static void cleanupSmallStructures(class_3218 class_32182) {
        int[][] nArrayArray = new int[][]{{144, 70, -48}, {-142, 68, 76}, {64, 72, 168}, {92, 66, 112}, {-96, 65, -118}, {188, 72, 86}, {-184, 70, -36}};
        for (int[] nArray : nArrayArray) {
            EchoDimensionExpander.clearKnownSmallStructure(class_32182, new class_2338(nArray[0], nArray[1], nArray[2]), 9, 10);
        }
    }

    private static void clearKnownSmallStructure(class_3218 class_32182, class_2338 class_23382, int n, int n2) {
        class_2680 class_26802 = EchoDimensionExpander.state("air");
        for (int i = -n; i <= n; ++i) {
            for (int j = -2; j <= n2; ++j) {
                for (int k = -n; k <= n; ++k) {
                    class_2338 class_23383 = class_23382.method_10069(i, j, k);
                    if (!EchoDimensionExpander.isSmallStructureBlock(class_32182.method_8320(class_23383))) continue;
                    class_32182.method_8652(class_23383, class_26802, 3);
                }
            }
        }
    }

    private static boolean isSmallStructureBlock(class_2680 class_26802) {
        return class_26802.method_27852(EchoDimensionExpander.block("reinforced_deepslate"))
            || class_26802.method_27852(EchoDimensionExpander.block("sculk"))
            || class_26802.method_27852(EchoDimensionExpander.block("sculk_catalyst"))
            || class_26802.method_27852(EchoDimensionExpander.block("chest"))
            || class_26802.method_27852(EchoDimensionExpander.block("polished_deepslate"))
            || class_26802.method_27852(EchoDimensionExpander.block("deepslate_bricks"))
            || class_26802.method_27852(EchoDimensionExpander.block("deepslate_tiles"))
            || class_26802.method_27852(EchoDimensionExpander.block("chiseled_deepslate"))
            || class_26802.method_27852(ModBlocks.ECHO_ALTAR)
            || class_26802.method_27852(ModBlocks.ECHO_CRYSTAL_BLOCK)
            || class_26802.method_27852(ModBlocks.VOID_GLASS)
            || class_26802.method_27852(ModBlocks.SCULK_REINFORCED_STONE);
    }

    private static void cleanupWaterSurfaceSculkDevices(class_3218 class_32182) {
        // Chunk-load cleanup owns this now; keep dimension setup light.
    }


    public static List<class_2338> getKnownMiniStructureCenters(class_3218 class_32182) {
        List<class_2338> result = new ArrayList<class_2338>();
        EchoDimensionExpander.collectPlannedCenters(class_32182, result, MINI_ALTAR_BASES, 11);
        EchoDimensionExpander.collectPlannedCenters(class_32182, result, MINI_ALTAR_BASES, 211);
        EchoDimensionExpander.collectPlannedCenters(class_32182, result, ECHO_SHRINE_BASES, 23);
        EchoDimensionExpander.collectPlannedCenters(class_32182, result, ECHO_SHRINE_BASES, 223);
        return result;
    }

    public static List<class_2338> getKnownMiniAltarCenters(class_3218 class_32182) {
        List<class_2338> result = new ArrayList<class_2338>();
        EchoDimensionExpander.collectPlannedCenters(class_32182, result, MINI_ALTAR_BASES, 11);
        EchoDimensionExpander.collectPlannedCenters(class_32182, result, MINI_ALTAR_BASES, 211);
        return result;
    }

    public static List<class_2338> getKnownEchoShrineCenters(class_3218 class_32182) {
        List<class_2338> result = new ArrayList<class_2338>();
        EchoDimensionExpander.collectPlannedCenters(class_32182, result, ECHO_SHRINE_BASES, 23);
        EchoDimensionExpander.collectPlannedCenters(class_32182, result, ECHO_SHRINE_BASES, 223);
        return result;
    }

    private static void collectPlannedCenters(class_3218 class_32182, List<class_2338> result, int[][] bases, int salt) {
        int[][] positions = EchoDimensionExpander.wideSparsePositions(bases, salt);
        for (int[] p : positions) {
            result.add(EchoDimensionExpander.surfaceCenter(class_32182, new class_2338(p[0], p[1], p[2])));
        }
    }

    private static int[][] wideSparsePositions(int[][] source, int salt) {
        int count = Math.max(1, (source.length + STRUCTURE_DENSITY_DIVISOR - 1) / STRUCTURE_DENSITY_DIVISOR);
        int[][] result = new int[count][3];
        for (int i = 0; i < count; ++i) {
            int[] base = source[Math.min(source.length - 1, i * STRUCTURE_DENSITY_DIVISOR)];
            double angle = (salt * 0.6180339887498949 + i * 2.399963229728653) % (Math.PI * 2.0);
            int radius = STRUCTURE_SPAWN_RADIUS - Math.floorMod(salt * 997 + i * 7919, 25000);
            result[i][0] = (int)Math.round(Math.cos(angle) * radius);
            result[i][1] = base[1];
            result[i][2] = (int)Math.round(Math.sin(angle) * radius);
        }
        return result;
    }

    private static class_2338 surfaceCenter(class_3218 class_32182, class_2338 class_23382) {
        return new class_2338(class_23382.method_10263(), EchoDimensionExpander.surfaceY(class_32182, class_23382.method_10263(), class_23382.method_10260()), class_23382.method_10260());
    }

    private static int surfaceY(class_3218 class_32182, int x, int z) {
        return Math.max(-63, class_32182.method_8624(class_2902.class_2903.field_13194, x, z));
    }

    private static void placeDrySculkDevice(class_3218 class_32182, class_2338 class_23382, class_2680 class_26802) {
        if (EchoDimensionExpander.touchesWaterSurface(class_32182, class_23382)) {
            return;
        }
        class_32182.method_8501(class_23382, class_26802);
    }

    private static boolean isSculkDevice(class_2680 class_26802) {
        return class_26802.method_27852(EchoDimensionExpander.block("sculk_sensor")) || class_26802.method_27852(EchoDimensionExpander.block("sculk_shrieker"));
    }

    private static boolean touchesWaterSurface(class_3218 class_32182, class_2338 class_23382) {
        return EchoDimensionExpander.isWater(class_32182.method_8320(class_23382))
            || EchoDimensionExpander.isWater(class_32182.method_8320(class_23382.method_10074()))
            || EchoDimensionExpander.isWater(class_32182.method_8320(class_23382.method_10069(1, 0, 0)))
            || EchoDimensionExpander.isWater(class_32182.method_8320(class_23382.method_10069(-1, 0, 0)))
            || EchoDimensionExpander.isWater(class_32182.method_8320(class_23382.method_10069(0, 0, 1)))
            || EchoDimensionExpander.isWater(class_32182.method_8320(class_23382.method_10069(0, 0, -1)))
            || EchoDimensionExpander.isWater(class_32182.method_8320(class_23382.method_10069(1, -1, 0)))
            || EchoDimensionExpander.isWater(class_32182.method_8320(class_23382.method_10069(-1, -1, 0)))
            || EchoDimensionExpander.isWater(class_32182.method_8320(class_23382.method_10069(0, -1, 1)))
            || EchoDimensionExpander.isWater(class_32182.method_8320(class_23382.method_10069(0, -1, -1)));
    }

    private static boolean isWater(class_2680 class_26802) {
        return class_26802.method_27852(EchoDimensionExpander.block("water"));
    }

    private static class_2680 state(String string) {
        return EchoDimensionExpander.block(string).method_9564();
    }

    private static class_2248 block(String string) {
        return (class_2248)class_7923.field_41175.method_10223(class_2960.method_60655((String)"minecraft", (String)string));
    }
}
