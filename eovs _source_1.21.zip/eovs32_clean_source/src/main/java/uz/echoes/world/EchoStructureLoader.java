/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_3218
 */
package uz.echoes.world;

import net.minecraft.class_3218;
import uz.echoes.world.EchoStructureInitializer;

public class EchoStructureLoader {
    public static void load(class_3218 class_32182) {
        EchoStructureInitializer.initArena(class_32182);
    }
}

