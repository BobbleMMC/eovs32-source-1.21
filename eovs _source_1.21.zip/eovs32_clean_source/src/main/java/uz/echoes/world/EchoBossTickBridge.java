/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1309
 *  net.minecraft.class_238
 *  net.minecraft.class_3218
 */
package uz.echoes.world;

import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_3218;
import uz.echoes.boss.EchoBossCombatManager;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoBossTickBridge {
    private EchoBossTickBridge() {
    }

    public static void tickBosses(class_3218 class_32182) {
        double d = class_32182.method_8621().method_11976();
        double d2 = class_32182.method_8621().method_11963();
        double d3 = class_32182.method_8621().method_11958();
        double d4 = class_32182.method_8621().method_11977();
        class_238 class_2382 = new class_238(d, (double)class_32182.method_31607(), d3, d2, (double)class_32182.method_31600(), d4);
        for (EchoWardenMonarchEntity echoWardenMonarchEntity : class_32182.method_8390(EchoWardenMonarchEntity.class, class_2382, class_1309::method_5805)) {
            EchoBossCombatManager.tickCombat(echoWardenMonarchEntity);
        }
    }
}

