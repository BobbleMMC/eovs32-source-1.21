package uz.echoes.world;

import java.util.List;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_3218;
import uz.echoes.block.ModBlocks;
import uz.echoes.boss.EchoBossSpawner;
import uz.echoes.entity.EchoWardenMonarchEntity;
import uz.echoes.structure.EchoArenaChestFiller;

/**
 * One-time boss trigger for the restored arena.
 *
 * The first player integration with any arena chest starts the fight exactly
 * once. Later chest opens, breaks, attacks, missing-chest scans, or nearby block
 * placement attempts are ignored after the trigger marker is written.
 */
public final class EchoArenaChestBossTrigger {
    private static final class_2338 TRIGGER_MARKER_POS = new class_2338(4, 79, 0);
    private static final class_2338 BOSS_SPAWNED_MARKER_POS = new class_2338(5, 79, 0);
    private static final class_2338 CHEST_CENTER = new class_2338(0, 81, 0);
    private static int scanTicks;

    private EchoArenaChestBossTrigger() {
    }

    public static void register() {
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.method_8608()) {
                class_2338 pos = hitResult.method_17777();
                if (isArenaChestInteraction(world, pos)) {
                    trigger((class_3218)world, "chest_or_nearby_interaction");
                }
            }
            return class_1269.field_5811;
        });

        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (!world.method_8608() && isTrackedArenaChestBlock(world, pos)) {
                trigger((class_3218)world, "chest_attacked");
            }
            return class_1269.field_5811;
        });

        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world instanceof class_3218 && isEchoWorld((class_3218)world) && EchoArenaChestFiller.isArenaChestPosition(pos)) {
                trigger((class_3218)world, "chest_broken");
            }
            return true;
        });

        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (!(world instanceof class_3218)) {
                return;
            }
            class_3218 serverWorld = (class_3218)world;
            if (!isEchoWorld(serverWorld) || serverWorld.method_18456().isEmpty()) {
                return;
            }
            if (++scanTicks % 40 != 0) {
                return;
            }
            scanArenaChestIntegrity(serverWorld);
        });
    }

    public static boolean isTriggered(class_3218 world) {
        return world != null && world.method_8320(TRIGGER_MARKER_POS).method_27852(class_2246.field_9987);
    }

    public static boolean hasBossSpawned(class_3218 world) {
        return world != null && world.method_8320(BOSS_SPAWNED_MARKER_POS).method_27852(class_2246.field_9987);
    }

    public static void trigger(class_3218 world, String reason) {
        if (world == null || !isEchoWorld(world)) {
            return;
        }
        if (isTriggered(world) || EchoDimensionPersistentState.get(world).isBossDefeated()) {
            return;
        }
        world.method_8501(TRIGGER_MARKER_POS, class_2246.field_9987.method_9564());
        removeAltar(world);
        spawnBossOnce(world);
    }

    public static void spawnBossOnce(class_3218 world) {
        if (world == null || hasBossSpawned(world) || EchoDimensionPersistentState.get(world).isBossDefeated()) {
            return;
        }
        world.method_8501(BOSS_SPAWNED_MARKER_POS, class_2246.field_9987.method_9564());
        spawnBossIfMissing(world);
    }

    private static boolean isEchoWorld(class_3218 world) {
        return world != null && world.method_27983().equals(EchoDimensionKeys.ECHO_DIMENSION);
    }

    private static boolean isArenaChestInteraction(net.minecraft.class_1937 world, class_2338 pos) {
        if (!(world instanceof class_3218)) {
            return false;
        }
        class_3218 serverWorld = (class_3218)world;
        if (!isEchoWorld(serverWorld)) {
            return false;
        }
        return isTrackedArenaChestBlock(world, pos) || isWithinOneBlockOfArenaChest(pos);
    }

    private static boolean isTrackedArenaChestBlock(net.minecraft.class_1937 world, class_2338 pos) {
        if (!(world instanceof class_3218)) {
            return false;
        }
        class_3218 serverWorld = (class_3218)world;
        if (!isEchoWorld(serverWorld) || !EchoArenaChestFiller.isArenaChestPosition(pos)) {
            return false;
        }
        return serverWorld.method_8320(pos).method_27852(class_2246.field_10034);
    }

    private static boolean isWithinOneBlockOfArenaChest(class_2338 pos) {
        if (pos == null) {
            return false;
        }
        List<class_2338> positions = EchoArenaChestFiller.getArenaChestPositions(CHEST_CENTER);
        for (class_2338 chest : positions) {
            if (Math.abs(pos.method_10263() - chest.method_10263()) <= 1
                    && Math.abs(pos.method_10264() - chest.method_10264()) <= 1
                    && Math.abs(pos.method_10260() - chest.method_10260()) <= 1) {
                return true;
            }
        }
        return false;
    }

    private static void scanArenaChestIntegrity(class_3218 world) {
        if (isTriggered(world) || !EchoArenaFixer.isArenaGenerated(world) || EchoDimensionPersistentState.get(world).isBossDefeated()) {
            return;
        }
        List<class_2338> positions = EchoArenaChestFiller.getArenaChestPositions(CHEST_CENTER);
        for (class_2338 pos : positions) {
            class_2586 blockEntity = world.method_8321(pos);
            if (!world.method_8320(pos).method_27852(class_2246.field_10034) || !(blockEntity instanceof class_2595)) {
                trigger(world, "chest_integrity_changed");
                return;
            }
        }
    }

    private static void removeAltar(class_3218 world) {
        class_2338 altar = EchoArenaFixer.ALTAR_POS;
        for (int dx = -1; dx <= 1; ++dx) {
            for (int dz = -1; dz <= 1; ++dz) {
                world.method_8652(altar.method_10069(dx, 0, dz), ModBlocks.SCULK_REINFORCED_STONE.method_9564(), 3);
                world.method_8652(altar.method_10069(dx, 1, dz), class_2246.field_10124.method_9564(), 3);
                world.method_8652(altar.method_10069(dx, 2, dz), class_2246.field_10124.method_9564(), 3);
            }
        }
    }

    private static void spawnBossIfMissing(class_3218 world) {
        class_238 area = new class_238(-58.0D, 60.0D, -58.0D, 58.0D, 170.0D, 58.0D);
        List bosses = world.method_8390(EchoWardenMonarchEntity.class, area, class_1309::method_5805);
        if (!bosses.isEmpty()) {
            return;
        }
        EchoBossSpawner.spawnBoss(world, EchoArenaFixer.BOSS_SPAWN);
    }
}
