/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2818
 *  net.minecraft.class_2902$class_2903
 *  net.minecraft.class_2960
 *  net.minecraft.class_3218
 */
package uz.echoes.world;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;

public final class EchoSurfaceSculkFixer {
    private static final class_2960 ECHO_DIMENSION_ID = class_2960.method_60655((String)"eovs32", (String)"echo_dimension");

    private EchoSurfaceSculkFixer() {
    }

    public static void register() {
        ServerChunkEvents.CHUNK_LOAD.register((class_32182, class_28182) -> {
            if (!EchoSurfaceSculkFixer.isEchoDimension(class_32182)) {
                return;
            }
            EchoSurfaceSculkFixer.replaceSurfaceWithSculk(class_32182, class_28182);
            EchoSurfaceSculkFixer.removeWaterSurfaceSculkDevices(class_32182, class_28182);
        });
    }

    private static void removeWaterSurfaceSculkDevices(class_3218 class_32182, class_2818 class_28182) {
        int n = class_28182.method_12004().method_8326();
        int n2 = class_28182.method_12004().method_8328();
        for (int i = 0; i < 16; ++i) {
            for (int j = 0; j < 16; ++j) {
                for (int y = 62; y <= 66; ++y) {
                    class_2338 class_23382 = new class_2338(n + i, y, n2 + j);
                    if (!EchoSurfaceSculkFixer.isSculkDevice(class_32182.method_8320(class_23382)) || !EchoSurfaceSculkFixer.touchesWaterSurface(class_32182, class_23382)) continue;
                    class_32182.method_8652(class_23382, EchoSurfaceSculkFixer.block("air").method_9564(), 3);
                }
            }
        }
    }

    private static boolean isSculkDevice(class_2680 class_26802) {
        return class_26802.method_27852(EchoSurfaceSculkFixer.block("sculk_sensor")) || class_26802.method_27852(EchoSurfaceSculkFixer.block("sculk_shrieker"));
    }

    private static boolean touchesWaterSurface(class_3218 class_32182, class_2338 class_23382) {
        return EchoSurfaceSculkFixer.isWater(class_32182.method_8320(class_23382))
            || EchoSurfaceSculkFixer.isWater(class_32182.method_8320(class_23382.method_10074()))
            || EchoSurfaceSculkFixer.isWater(class_32182.method_8320(class_23382.method_10069(1, 0, 0)))
            || EchoSurfaceSculkFixer.isWater(class_32182.method_8320(class_23382.method_10069(-1, 0, 0)))
            || EchoSurfaceSculkFixer.isWater(class_32182.method_8320(class_23382.method_10069(0, 0, 1)))
            || EchoSurfaceSculkFixer.isWater(class_32182.method_8320(class_23382.method_10069(0, 0, -1)))
            || EchoSurfaceSculkFixer.isWater(class_32182.method_8320(class_23382.method_10069(1, -1, 0)))
            || EchoSurfaceSculkFixer.isWater(class_32182.method_8320(class_23382.method_10069(-1, -1, 0)))
            || EchoSurfaceSculkFixer.isWater(class_32182.method_8320(class_23382.method_10069(0, -1, 1)))
            || EchoSurfaceSculkFixer.isWater(class_32182.method_8320(class_23382.method_10069(0, -1, -1)));
    }

    private static boolean isWater(class_2680 class_26802) {
        return class_26802.method_27852(EchoSurfaceSculkFixer.block("water"));
    }

    private static class_2248 block(String string) {
        return (class_2248)class_7923.field_41175.method_10223(class_2960.method_60655((String)"minecraft", (String)string));
    }

    private static boolean isEchoDimension(class_3218 class_32182) {
        return class_32182.method_27983().method_29177().equals((Object)ECHO_DIMENSION_ID);
    }

    private static void replaceSurfaceWithSculk(class_3218 class_32182, class_2818 class_28182) {
        int n = class_28182.method_12004().method_8326();
        int n2 = class_28182.method_12004().method_8328();
        for (int i = 0; i < 16; ++i) {
            for (int j = 0; j < 16; ++j) {
                int n3 = n + i;
                int n4 = n2 + j;
                int n5 = class_32182.method_8624(class_2902.class_2903.field_13194, n3, n4) - 1;
                class_2338 class_23382 = new class_2338(n3, n5, n4);
                if (EchoSurfaceSculkFixer.touchesWaterSurface(class_32182, class_23382)) continue;
                if (!class_32182.method_8320(class_23382).method_27852(class_2246.field_10219) && !class_32182.method_8320(class_23382).method_27852(class_2246.field_10566) && !class_32182.method_8320(class_23382).method_27852(class_2246.field_10340) && !class_32182.method_8320(class_23382).method_27852(class_2246.field_28888) && !class_32182.method_8320(class_23382).method_27852(class_2246.field_10443)) continue;
                class_32182.method_8652(class_23382, class_2246.field_37568.method_9564(), 2);
            }
        }
    }
}
