package uz.echoes.world;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import uz.echoes.block.ModBlocks;

/**
 * Small idempotent safety repair pass for the Echo Dimension.
 *
 * This class intentionally does not replace datapack worldgen. It only repairs
 * known runtime hazards around important gameplay areas: player arrival, arena,
 * boss floor, vault approach, and the old void-test chunks near the center.
 */
public final class EchoDimensionSafetyManager {
    private static final class_2338 ARRIVAL = EchoArenaFixer.PLAYER_BRIDGE_SPAWN;
    private static final class_2338 ARENA = EchoArenaFixer.ARENA_CENTER;
    private static final Set<String> FORCED_ENTRY_WORLDS = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());

    private EchoDimensionSafetyManager() {
    }


    /**
     * Absolute portal-arrival guarantee: this method is intentionally tiny and
     * safe to call on every portal travel. It only touches the protected bridge
     * spawn and corridor, so teleport never depends on full worldgen/arena setup.
     */
    public static class_2338 forceBridgeArrivalPlatform(class_3218 world) {
        // Keep teleport path extremely light. Heavy bridge/hazard/arena repair
        // is delayed by EchoArenaWorldEvents to avoid chunk-loading freezes.
        forceEssentialChunks(world);
        EchoSpawnPlatform.createPlatform(world, ARRIVAL);
        return ARRIVAL.method_10084();
    }

    /**
     * Forces only the tiny set of gameplay-critical chunks.
     *
     * This fixes the client getting stuck on "Waiting for chunk" after dimension
     * transfer. The method is guarded per world key, so it does not spam
     * setChunkForced every tick.
     */
    public static void forceEssentialChunks(class_3218 world) {
        if (world == null) {
            return;
        }
        String key = String.valueOf(world.method_27983());
        if (!FORCED_ENTRY_WORLDS.add(key)) {
            return;
        }

        forceChunksAround(world, ARRIVAL, 1); // arrival pad + nearby client view
        forceChunksAround(world, ARENA, 2);   // boss arena + bridge start
    }

    private static void forceChunksAround(class_3218 world, class_2338 center, int radius) {
        int chunkX = center.method_10263() >> 4;
        int chunkZ = center.method_10260() >> 4;
        for (int dx = -radius; dx <= radius; ++dx) {
            for (int dz = -radius; dz <= radius; ++dz) {
                world.method_17988(chunkX + dx, chunkZ + dz, true);
            }
        }
    }

    /**
     * Emergency entry safety for command teleports and first dimension load.
     *
     * Portal and Gate Sigil travel already call forceBridgeArrivalPlatform(),
     * but commands such as:
     * /execute in eovs32:echo_dimension run tp @s 0 82 -54
     * bypass the portal pipeline completely. This tick-level guard builds the
     * small landing pad as soon as any player is present in the Echo Dimension
     * and rescues players who are already falling into the void.
     */
    public static void tickPlayerSafety(class_3218 world) {
        if (world == null || world.method_18456().isEmpty()) {
            return;
        }

        forceEssentialChunks(world);
        class_2338 safeArrival = forceBridgeArrivalPlatform(world);
        for (class_3222 player : world.method_18456()) {
            if (player == null) {
                continue;
            }
            // Real terrain is now restored below the arena. Only rescue true void falls,
            // not normal cave/surface exploration under Y=81.
            if (player.method_23318() < -70.0D) {
                teleportToSafeArrival(world, player, safeArrival);
            }
        }
    }

    private static void teleportToSafeArrival(class_3218 world, class_3222 player, class_2338 safeArrival) {
        if (world == null || player == null || safeArrival == null) {
            return;
        }
        player.method_14251(
                world,
                (double)safeArrival.method_10263() + 0.5D,
                (double)safeArrival.method_10264(),
                (double)safeArrival.method_10260() + 0.5D,
                player.method_36454(),
                player.method_36455()
        );
    }

    public static void runOneTimeSafetyPass(class_3218 world) {
        // Deliberately bounded pass: avoid huge scans on low-end clients.
        repairOldVoidCenter(world);
        sanitizeArrival(world);
        sanitizeBridge(world);
        sanitizeArena(world);
        cleanupWaterSurfaceSculkDevices(world, 62, 66, 64);

        // Start async arena generation if not already complete
        EchoArenaAsyncBuilder.startAsyncGeneration(world);
    }

    private static void repairOldVoidCenter(class_3218 world) {
        // If an old test build generated only void around 0,0, add a light base
        // so the restored dimension has land again without overwriting normal chunks.
        int solidSamples = 0;
        for (int x = -48; x <= 48; x += 16) {
            for (int z = -48; z <= 48; z += 16) {
                if (!world.method_8320(new class_2338(x, 63, z)).method_27852(block("air"))) {
                    ++solidSamples;
                }
            }
        }
        if (solidSamples >= 4) {
            return;
        }

        class_2680 stone = ModBlocks.SCULK_REINFORCED_STONE.method_9564();
        class_2680 sculk = block("sculk").method_9564();
        class_2680 bedrock = block("bedrock").method_9564();
        for (int x = -40; x <= 40; ++x) {
            for (int z = -40; z <= 40; ++z) {
                int r2 = x * x + z * z;
                if (r2 > 40 * 40) {
                    continue;
                }
                world.method_8501(new class_2338(x, -64, z), bedrock);
                if (r2 <= 36 * 36) {
                    world.method_8501(new class_2338(x, 61, z), stone);
                    world.method_8501(new class_2338(x, 62, z), stone);
                    world.method_8501(new class_2338(x, 63, z), sculk);
                }
            }
        }
    }

    private static void sanitizeArrival(class_3218 world) {
        clearWaterAndHazards(world, ARRIVAL, 8, 6);
        clearHeadroom(world, ARRIVAL, 6, 6);
    }


    private static void sanitizeBridge(class_3218 world) {
        class_2680 air = block("air").method_9564();

        // Restored jar-style bridge: negative-Z arrival side -> arena gate.
        for (int z = -96; z <= -40; ++z) {
            for (int x = -4; x <= 4; ++x) {
                class_2680 floor = Math.abs(x) == 4 ? class_2246.field_10266.method_9564() : class_2246.field_38420.method_9564();
                world.method_8501(new class_2338(x, 81, z), floor);
                world.method_8501(new class_2338(x, 80, z), class_2246.field_28896.method_9564());
            }
            world.method_8501(new class_2338(-5, 82, z), class_2246.field_10364.method_9564());
            world.method_8501(new class_2338(5, 82, z), class_2246.field_10364.method_9564());
            if (z % 8 == 0) {
                for (int y = 20; y <= 81; ++y) {
                    world.method_8501(new class_2338(-5, y, z), class_2246.field_10266.method_9564());
                    world.method_8501(new class_2338(5, y, z), class_2246.field_10266.method_9564());
                }
                world.method_8501(new class_2338(-5, 83, z), class_2246.field_22110.method_9564());
                world.method_8501(new class_2338(5, 83, z), class_2246.field_22110.method_9564());
            }
        }

        // Obsidian landing pad from EchoSpawnPlatform is intentionally separate
        // and one block above the bridge, exactly like the uploaded jar source.
        EchoSpawnPlatform.createPlatform(world, ARRIVAL);

        // Requested 10x11 rectangular connector cut between bridge and arena.
        for (int z = -44; z <= -34; ++z) {
            for (int x = -5; x <= 4; ++x) {
                for (int dy = 1; dy <= 11; ++dy) {
                    world.method_8501(new class_2338(x, 80 + dy, z), air);
                }
            }
        }
        clearWaterAndHazards(world, new class_2338(0, 81, -68), 18, 8);
    }

    private static void sanitizeArena(class_3218 world) {
        clearWaterAndHazards(world, ARENA, 28, 10);
        clearHeadroom(world, new class_2338(0, 81, 0), 8, 18);
        world.method_8501(new class_2338(0, 79, 0), block("bedrock").method_9564());
        if (!EchoArenaChestBossTrigger.isTriggered(world)) {
            EchoArenaFixer.ensureCenterAltar(world);
        }
    }

    private static void clearWaterAndHazards(class_3218 world, class_2338 center, int radius, int yRange) {
        class_2680 air = block("air").method_9564();
        class_2680 floor = ModBlocks.SCULK_REINFORCED_STONE.method_9564();
        int cx = center.method_10263();
        int cy = center.method_10264();
        int cz = center.method_10260();
        for (int x = -radius; x <= radius; ++x) {
            for (int z = -radius; z <= radius; ++z) {
                if (x * x + z * z > radius * radius) {
                    continue;
                }
                for (int y = -2; y <= yRange; ++y) {
                    class_2338 pos = new class_2338(cx + x, cy + y, cz + z);
                    class_2680 state = world.method_8320(pos);
                    if (state.method_27852(block("water")) || state.method_27852(block("lava"))) {
                        world.method_8501(pos, y <= 0 ? floor : air);
                    }
                }
            }
        }
    }

    private static void clearHeadroom(class_3218 world, class_2338 center, int radius, int height) {
        class_2680 air = block("air").method_9564();
        int cx = center.method_10263();
        int cy = center.method_10264();
        int cz = center.method_10260();
        for (int x = -radius; x <= radius; ++x) {
            for (int z = -radius; z <= radius; ++z) {
                if (x * x + z * z > radius * radius) {
                    continue;
                }
                for (int y = 1; y <= height; ++y) {
                    class_2338 pos = new class_2338(cx + x, cy + y, cz + z);
                    if (!world.method_8320(pos).method_27852(ModBlocks.ECHO_ALTAR)) {
                        world.method_8501(pos, air);
                    }
                }
            }
        }
    }

    private static void cleanupWaterSurfaceSculkDevices(class_3218 world, int minY, int maxY, int radius) {
        class_2680 air = block("air").method_9564();
        for (int x = -radius; x <= radius; ++x) {
            for (int z = -radius; z <= radius; ++z) {
                if (x * x + z * z > radius * radius) {
                    continue;
                }
                for (int y = minY; y <= maxY; ++y) {
                    class_2338 pos = new class_2338(x, y, z);
                    if (isSculkDevice(world.method_8320(pos)) && touchesWater(world, pos)) {
                        world.method_8501(pos, air);
                    }
                }
            }
        }
    }

    private static boolean touchesWater(class_3218 world, class_2338 pos) {
        return world.method_8320(pos).method_27852(block("water"))
                || world.method_8320(pos.method_10074()).method_27852(block("water"))
                || world.method_8320(pos.method_10069(1, 0, 0)).method_27852(block("water"))
                || world.method_8320(pos.method_10069(-1, 0, 0)).method_27852(block("water"))
                || world.method_8320(pos.method_10069(0, 0, 1)).method_27852(block("water"))
                || world.method_8320(pos.method_10069(0, 0, -1)).method_27852(block("water"));
    }

    private static boolean isSculkDevice(class_2680 state) {
        return state.method_27852(block("sculk_sensor")) || state.method_27852(block("sculk_shrieker"));
    }

    private static class_2248 block(String id) {
        return (class_2248)class_7923.field_41175.method_10223(class_2960.method_60655("minecraft", id));
    }
}
