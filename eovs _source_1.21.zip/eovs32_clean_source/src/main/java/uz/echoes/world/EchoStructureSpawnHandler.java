/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_3218
 */
package uz.echoes.world;

import net.minecraft.class_3218;
import uz.echoes.structure.EchoStructurePlacer;

public final class EchoStructureSpawnHandler {
    private static boolean generated = false;

    private EchoStructureSpawnHandler() {
    }

    public static void ensureArenaGenerated(class_3218 class_32182) {
        if (generated) {
            return;
        }
        EchoStructurePlacer.placeBossArena(class_32182);
        generated = true;
    }
}

