package uz.echoes.world;

import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_3218;
import uz.echoes.boss.EchoBossSpawner;
import uz.echoes.entity.EchoWardenMonarchEntity;

/**
 * Boss cycle now waits for the arena chest trigger.
 *
 * The trigger itself spawns exactly one boss. This tick class only prevents
 * duplicates and restores the altar while the fight has not started.
 */
public final class EchoAltarBossCycle {
    public static final class_2338 ALTAR_POS = EchoArenaFixer.ALTAR_POS;
    private static int cooldown;

    private EchoAltarBossCycle() {
    }

    public static void tick(class_3218 world) {
        if (cooldown > 0) {
            --cooldown;
            return;
        }
        removeDuplicateBosses(world);
        if (EchoDimensionPersistentState.get(world).isBossDefeated()) {
            return;
        }
        if (EchoArenaChestBossTrigger.isTriggered(world)) {
            // One trigger = one boss. Do not respawn another boss from tick logic.
            world.method_8652(ALTAR_POS, class_2246.field_10124.method_9564(), 3);
            cooldown = 200;
            return;
        }
        if (!world.method_8320(ALTAR_POS).method_27852(uz.echoes.block.ModBlocks.ECHO_ALTAR)) {
            restoreAltar(world);
        }
    }

    private static boolean hasLivingBoss(class_3218 world) {
        List list = world.method_8390(EchoWardenMonarchEntity.class, new class_238(0.0, 60.0, 0.0, 1.0, 160.0, 1.0).method_1014(96.0), class_1309::method_5805);
        return !list.isEmpty();
    }

    private static void removeDuplicateBosses(class_3218 world) {
        List list = world.method_8390(EchoWardenMonarchEntity.class, new class_238(0.0, 60.0, 0.0, 1.0, 170.0, 1.0).method_1014(128.0), class_1309::method_5805);
        if (list.size() <= 1) {
            return;
        }
        EchoWardenMonarchEntity keep = (EchoWardenMonarchEntity)((Object)list.get(0));
        for (int i = 1; i < list.size(); ++i) {
            EchoWardenMonarchEntity duplicate = (EchoWardenMonarchEntity)((Object)list.get(i));
            if (duplicate != keep) {
                duplicate.method_5768();
            }
        }
    }

    public static void restoreAltar(class_3218 world) {
        EchoArenaFixer.ensureCenterAltar(world);
    }
}
