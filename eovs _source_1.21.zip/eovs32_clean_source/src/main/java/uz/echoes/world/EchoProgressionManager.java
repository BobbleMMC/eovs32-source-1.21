/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1661
 *  net.minecraft.class_1799
 *  net.minecraft.class_1935
 *  net.minecraft.class_1937
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2382
 *  net.minecraft.class_2561
 *  net.minecraft.class_2586
 *  net.minecraft.class_2595
 *  net.minecraft.class_2680
 *  net.minecraft.class_2960
 *  net.minecraft.class_3218
 *  net.minecraft.class_52
 *  net.minecraft.class_5321
 *  net.minecraft.class_7923
 *  net.minecraft.class_7924
 */
package uz.echoes.world;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import uz.echoes.block.ModBlocks;
import uz.echoes.item.ModItems;

public final class EchoProgressionManager {
    private static final class_2338 MARKER = new class_2338(12, -63, 8);
    private static final class_2338 VAULT_CENTER = new class_2338(0, 82, -126);
    private static final class_5321<class_52> RARE_LOOT = class_5321.method_29179((class_5321)class_7924.field_50079, (class_2960)class_2960.method_60655((String)"eovs32", (String)"chests/echo_arena_rare_treasure"));
    private static final int[][] TRIALS = new int[][]{{150, 72, -132}, {-170, 70, 118}, {92, 76, 214}};

    private EchoProgressionManager() {
    }

    public static void tick(class_3218 class_32182) {
        EchoProgressionManager.ensureGenerated(class_32182);
        EchoProgressionManager.tryOpenVault(class_32182);
    }

    public static void ensureGenerated(class_3218 class_32182) {
        if (class_32182.method_8320(MARKER).method_27852(EchoProgressionManager.block("crying_obsidian"))) {
            return;
        }
        EchoProgressionManager.buildTrials(class_32182);
        EchoProgressionManager.buildLockedVault(class_32182);
        class_32182.method_8501(MARKER, EchoProgressionManager.block("crying_obsidian").method_9564());
    }

    public static void onBossDefeated(class_3218 class_32182) {
        class_2338 class_23382 = EchoProgressionManager.surfaceCenter(class_32182, new class_2338(0, 82, 0));
        class_32182.method_8652(class_23382, ModBlocks.ECHO_ALTAR.method_9564(), 3);
        for (int i = -3; i <= 3; ++i) {
            for (int j = -3; j <= 3; ++j) {
                if (Math.abs(i) != 3 && Math.abs(j) != 3) continue;
                class_32182.method_8652(class_23382.method_10069(i, -1, j), class_2246.field_10124.method_9564(), 3);
                if ((i + j) % 2 != 0) continue;
                class_32182.method_8652(class_23382.method_10069(i, 0, j), class_2246.field_10124.method_9564(), 3);
            }
        }
        EchoProgressionManager.placeRarePostBossVault(class_32182, new class_2338(48, 84, 48));
        EchoProgressionManager.placeRarePostBossVault(class_32182, new class_2338(-52, 86, 54));
    }

    private static void buildTrials(class_3218 class_32182) {
        for (int i = 0; i < TRIALS.length; ++i) {
            int[] nArray = TRIALS[i];
            class_2338 class_23382 = EchoProgressionManager.surfaceCenter(class_32182, new class_2338(nArray[0], nArray[1], nArray[2]));
            EchoProgressionManager.platform(class_32182, class_23382, 8, ModBlocks.SCULK_REINFORCED_STONE.method_9564());
            EchoProgressionManager.ring(class_32182, class_23382, 7, ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
            class_32182.method_8501(class_23382.method_10084(), EchoProgressionManager.block("sculk_shrieker").method_9564());
            class_32182.method_8501(class_23382.method_10069(0, 2, 0), ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
            EchoProgressionManager.placeTrialChest(class_32182, class_23382.method_10069(3, 1, 0), i);
            EchoProgressionManager.spawnGuardian(class_32182, class_23382.method_10069(0, 2, 0), i);
        }
    }

    private static void buildLockedVault(class_3218 class_32182) {
        int n;
        int n2;
        class_2338 vaultCenter = EchoProgressionManager.surfaceCenter(class_32182, VAULT_CENTER);
        class_2338 vaultDoor = vaultCenter.method_10069(0, 0, 10);
        EchoProgressionManager.platform(class_32182, vaultCenter, 9, ModBlocks.SCULK_REINFORCED_STONE.method_9564());
        for (n2 = -8; n2 <= 8; ++n2) {
            for (n = 0; n <= 7; ++n) {
                for (int i = -8; i <= 8; ++i) {
                    boolean bl;
                    boolean bl2 = bl = Math.abs(n2) == 8 || Math.abs(i) == 8 || n == 7;
                    if (!bl) continue;
                    class_32182.method_8501(vaultCenter.method_10069(n2, n, i), ModBlocks.SCULK_REINFORCED_STONE.method_9564());
                }
            }
        }
        for (n2 = -3; n2 <= 3; ++n2) {
            for (n = 0; n <= 5; ++n) {
                class_32182.method_8501(vaultDoor.method_10069(n2, n, 0), ModBlocks.SCULK_REINFORCED_STONE.method_9564());
            }
        }
        EchoProgressionManager.placeLootChest(class_32182, vaultCenter.method_10069(0, 1, 0), RARE_LOOT);
    }

    private static void tryOpenVault(class_3218 class_32182) {
        class_2338 vaultCenter = EchoProgressionManager.surfaceCenter(class_32182, VAULT_CENTER);
        class_2338 vaultDoor = vaultCenter.method_10069(0, 0, 10);
        if (!class_32182.method_8320(vaultDoor).method_27852(ModBlocks.SCULK_REINFORCED_STONE)) {
            return;
        }
        for (class_1657 class_16572 : class_32182.method_18456()) {
            if (class_16572.method_24515().method_10262((class_2382)vaultDoor) > 196.0 || EchoProgressionManager.countFragments(class_16572) < 3) continue;
            EchoProgressionManager.consumeFragments(class_16572, 3);
            EchoProgressionManager.openVault(class_32182);
            break;
        }
    }

    private static void openVault(class_3218 class_32182) {
        class_2338 vaultCenter = EchoProgressionManager.surfaceCenter(class_32182, VAULT_CENTER);
        class_2338 vaultDoor = vaultCenter.method_10069(0, 0, 10);
        for (int i = -3; i <= 3; ++i) {
            for (int j = 0; j <= 5; ++j) {
                class_32182.method_8652(vaultDoor.method_10069(i, j, 0), class_2246.field_10124.method_9564(), 3);
            }
        }
        class_32182.method_8652(vaultDoor.method_10069(0, 6, 0), ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564(), 3);
        EchoProgressionManager.placeSigilChest(class_32182, vaultCenter.method_10069(0, 1, -3));
    }

    private static int countFragments(class_1657 class_16572) {
        int n = 0;
        class_1661 class_16612 = class_16572.method_31548();
        for (int i = 0; i < class_16612.method_5439(); ++i) {
            class_1799 class_17992 = class_16612.method_5438(i);
            if (!class_17992.method_31574(ModItems.ECHO_FRAGMENT)) continue;
            n += class_17992.method_7947();
        }
        return n;
    }

    private static void consumeFragments(class_1657 class_16572, int n) {
        class_1661 class_16612 = class_16572.method_31548();
        for (int i = 0; i < class_16612.method_5439() && n > 0; ++i) {
            class_1799 class_17992 = class_16612.method_5438(i);
            if (!class_17992.method_31574(ModItems.ECHO_FRAGMENT)) continue;
            int n2 = Math.min(n, class_17992.method_7947());
            class_17992.method_7934(n2);
            n -= n2;
        }
    }

    private static void spawnGuardian(class_3218 class_32182, class_2338 class_23382, int n) {
        String string = n == 0 ? "iron_golem" : (n == 1 ? "evoker" : "enderman");
        class_1299 class_12992 = (class_1299)class_7923.field_41177.method_10223(class_2960.method_60655((String)"minecraft", (String)string));
        class_1297 class_12972 = class_12992.method_5883((class_1937)class_32182);
        if (!(class_12972 instanceof class_1309)) {
            return;
        }
        class_1309 class_13092 = (class_1309)class_12972;
        class_13092.method_5665((class_2561)class_2561.method_43470((String)(n == 0 ? "Echo Sentinel" : (n == 1 ? "Sculk Binder" : "Void Stalker"))));
        class_13092.method_5880(true);
        class_13092.method_5808((double)class_23382.method_10263() + 0.5, (double)class_23382.method_10264(), (double)class_23382.method_10260() + 0.5, 0.0f, 0.0f);
        class_32182.method_8649(class_12972);
    }

    private static void placeTrialChest(class_3218 class_32182, class_2338 class_23382, int n) {
        class_32182.method_8652(class_23382, class_2246.field_10124.method_9564(), 3);
        class_32182.method_8652(class_23382, class_2246.field_10034.method_9564(), 3);
        class_2586 class_25862 = class_32182.method_8321(class_23382);
        if (!(class_25862 instanceof class_2595)) {
            return;
        }
        class_2595 class_25952 = (class_2595)class_25862;
        class_25952.method_5447(0, new class_1799((class_1935)ModItems.ECHO_FRAGMENT, 1));
        class_25952.method_5447(1, new class_1799((class_1935)(n == 0 ? ModItems.ECHO_SENTINEL_CORE : (n == 1 ? ModItems.SCULK_BINDER_EYE : ModItems.VOID_STALKER_PEARL)), 1));
        class_25952.method_5447(2, new class_1799((class_1935)ModItems.ECHO_CRYSTAL_SHARD, 8 + n * 4));
    }

    private static void placeSigilChest(class_3218 class_32182, class_2338 class_23382) {
        class_32182.method_8652(class_23382, class_2246.field_10124.method_9564(), 3);
        class_32182.method_8652(class_23382, class_2246.field_10034.method_9564(), 3);
        class_2586 class_25862 = class_32182.method_8321(class_23382);
        if (class_25862 instanceof class_2595) {
            class_2595 class_25952 = (class_2595)class_25862;
            class_25952.method_5447(0, new class_1799((class_1935)ModItems.ECHO_GATE_SIGIL, 1));
            class_25952.method_5447(1, new class_1799((class_1935)ModItems.ECHOENERGY_STONE, 3));
            class_25952.method_5447(2, new class_1799((class_1935)ModItems.ECHO_CRYSTAL_SHARD, 16));
        }
    }

    private static void placeRarePostBossVault(class_3218 class_32182, class_2338 class_23382) {
        class_23382 = EchoProgressionManager.surfaceCenter(class_32182, class_23382);
        EchoProgressionManager.platform(class_32182, class_23382, 5, ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
        class_32182.method_8652(class_23382.method_10084(), EchoProgressionManager.block("sculk_sensor").method_9564(), 3);
        EchoProgressionManager.placeLootChest(class_32182, class_23382.method_10069(1, 1, 0), RARE_LOOT);
    }

    private static void placeLootChest(class_3218 class_32182, class_2338 class_23382, class_5321<class_52> class_53212) {
        class_32182.method_8652(class_23382, class_2246.field_10124.method_9564(), 3);
        class_32182.method_8652(class_23382, class_2246.field_10034.method_9564(), 3);
        class_2586 class_25862 = class_32182.method_8321(class_23382);
        if (class_25862 instanceof class_2595) {
            ((class_2595)class_25862).method_54867(class_53212, class_32182.method_8409().method_43055());
        }
    }

    private static void platform(class_3218 class_32182, class_2338 class_23382, int n, class_2680 class_26802) {
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                if (i * i + j * j > n * n) continue;
                class_32182.method_8501(class_23382.method_10069(i, 0, j), class_26802);
                class_32182.method_8501(class_23382.method_10069(i, -1, j), EchoProgressionManager.block("deepslate").method_9564());
            }
        }
    }

    private static void ring(class_3218 class_32182, class_2338 class_23382, int n, class_2680 class_26802) {
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                int n2 = i * i + j * j;
                if (n2 < (n - 1) * (n - 1) || n2 > n * n) continue;
                class_32182.method_8501(class_23382.method_10069(i, 1, j), class_26802);
            }
        }
    }

    private static class_2248 block(String string) {
        return (class_2248)class_7923.field_41175.method_10223(class_2960.method_60655((String)"minecraft", (String)string));
    }

    private static class_2338 surfaceCenter(class_3218 class_32182, class_2338 class_23382) {
        int y = Math.max(-63, class_32182.method_8624(class_2902.class_2903.field_13194, class_23382.method_10263(), class_23382.method_10260()));
        return new class_2338(class_23382.method_10263(), y, class_23382.method_10260());
    }
}
