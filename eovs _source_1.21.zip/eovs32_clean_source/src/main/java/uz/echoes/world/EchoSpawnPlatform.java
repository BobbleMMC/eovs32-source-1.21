package uz.echoes.world;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/** Safe bridge-arrival platform for Echo dimension portal entry. */
public final class EchoSpawnPlatform {
    private EchoSpawnPlatform() {
    }

    public static class_2338 createPlatform(class_3218 world, class_2338 center) {
        if (world == null || center == null) {
            return center;
        }

        if (isPlatformReady(world, center)) {
            return center.method_10084();
        }

        class_2680 bedrock = class_2246.field_9987.method_9564();
        class_2680 obsidian = class_2246.field_10540.method_9564();
        class_2680 air = class_2246.field_10124.method_9564();

        // PERFORMANCE FIX:
        // This is intentionally small and idempotent. It avoids writing the same
        // blocks every tick, which can keep the client on "Waiting for chunk".
        for (int x = -3; x <= 3; ++x) {
            for (int z = -3; z <= 3; ++z) {
                class_2338 floor = center.method_10069(x, 0, z);
                setIfNotBlock(world, floor.method_10074(), class_2246.field_9987, bedrock);
                setIfNotBlock(world, floor, class_2246.field_10540, obsidian);
                for (int y = 1; y <= 4; ++y) {
                    setIfNotBlock(world, floor.method_10086(y), class_2246.field_10124, air);
                }
            }
        }
        return center.method_10084();
    }

    public static boolean isPlatformReady(class_3218 world, class_2338 center) {
        if (world == null || center == null) {
            return false;
        }

        return isPlatformColumnReady(world, center)
                && isPlatformColumnReady(world, center.method_10069(3, 0, 3))
                && isPlatformColumnReady(world, center.method_10069(-3, 0, 3))
                && isPlatformColumnReady(world, center.method_10069(3, 0, -3))
                && isPlatformColumnReady(world, center.method_10069(-3, 0, -3));
    }

    private static boolean isPlatformColumnReady(class_3218 world, class_2338 floor) {
        return world.method_8320(floor.method_10074()).method_27852(class_2246.field_9987)
                && world.method_8320(floor).method_27852(class_2246.field_10540)
                && world.method_8320(floor.method_10086(1)).method_27852(class_2246.field_10124)
                && world.method_8320(floor.method_10086(2)).method_27852(class_2246.field_10124);
    }

    private static void setIfNotBlock(class_3218 world, class_2338 pos, net.minecraft.class_2248 expectedBlock, class_2680 targetState) {
        if (!world.method_8320(pos).method_27852(expectedBlock)) {
            world.method_8501(pos, targetState);
        }
    }
}
