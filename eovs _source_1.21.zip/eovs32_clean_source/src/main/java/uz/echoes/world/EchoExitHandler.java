/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 *  net.minecraft.class_3218
 *  net.minecraft.class_3222
 *  net.minecraft.server.MinecraftServer
 */
package uz.echoes.world;

import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public final class EchoExitHandler {
    private EchoExitHandler() {
    }

    public static void exitToOverworld(class_3222 class_32222) {
        class_3218 class_32182;
        MinecraftServer minecraftServer = class_32222.method_5682();
        if (minecraftServer == null) {
            return;
        }
        class_3218 class_32183 = minecraftServer.method_30002();
        class_2338 class_23382 = class_32183.method_43126();
        float f = class_32222.method_36454();
        class_2338 class_23383 = class_32222.method_26280();
        if (class_23383 != null && (class_32182 = minecraftServer.method_3847(class_32222.method_26281())) != null) {
            class_32183 = class_32182;
            class_23382 = class_23383;
            f = class_32222.method_30631();
        }
        class_32222.method_14251(class_32183, (double)class_23382.method_10263() + 0.5, (double)class_23382.method_10264() + 0.2, (double)class_23382.method_10260() + 0.5, f, class_32222.method_36455());
    }
}

