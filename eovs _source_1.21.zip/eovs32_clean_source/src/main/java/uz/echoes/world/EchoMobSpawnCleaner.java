/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1308
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_238
 *  net.minecraft.class_3218
 *  net.minecraft.class_7923
 */
package uz.echoes.world;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import uz.echoes.item.ModItems;
import uz.echoes.portal.EchoDimensionKeys;

public final class EchoMobSpawnCleaner {
    private static int tickCounter = 0;

    private EchoMobSpawnCleaner() {
    }

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(EchoMobSpawnCleaner::cleanEchoDimension);
    }

    private static void cleanEchoDimension(class_3218 class_32182) {
        if (++tickCounter < 100) {
            return;
        }
        tickCounter = 0;
        EchoMobSpawnCleaner.applyEchoProtectorStaff(class_32182);
        if (!class_32182.method_27983().equals(EchoDimensionKeys.ECHO_DIMENSION)) {
            return;
        }
        EchoWardenSpawnLimiter.enforceLoadedCap(class_32182);
        for (class_1657 class_16572 : class_32182.method_18456()) {
            class_238 class_2382 = class_16572.method_5829().method_1014(96.0);
            for (class_1297 class_12973 : class_32182.method_8390(class_1297.class, class_2382, EchoMobSpawnCleaner::shouldCleanFromEchoDimension)) {
                class_12973.method_31472();
            }
        }
    }


    private static boolean shouldCleanFromEchoDimension(class_1297 entity) {
        // Safety whitelist: never touch players, item/projectile-like entities or
        // the custom boss. Only clean vanilla mobs that are known to break the
        // Echo-dimension rule set.
        String id = class_7923.field_41177.method_10221((class_1299<?>)entity.method_5864()).toString();
        return id.equals("minecraft:zombie") || id.equals("minecraft:skeleton") || id.equals("minecraft:creeper") || id.equals("minecraft:spider");
    }

    private static void applyEchoProtectorStaff(class_3218 class_32182) {
        for (class_1657 class_16572 : class_32182.method_18456()) {
            if (!EchoMobSpawnCleaner.hasEchoProtectorStaff(class_16572)) continue;
            class_238 class_2382 = class_16572.method_5829().method_1014(32.0);
            for (class_1309 class_13092 : class_32182.method_8390(class_1309.class, class_2382, EchoMobSpawnCleaner::isWarden)) {
                if (class_13092 instanceof class_1308) {
                    ((class_1308)class_13092).method_5980(null);
                }
                class_13092.method_31472();
            }
        }
    }

    private static boolean hasEchoProtectorStaff(class_1657 class_16572) {
        class_1799 class_17992 = class_16572.method_5998(class_1268.field_5808);
        class_1799 class_17993 = class_16572.method_5998(class_1268.field_5810);
        return class_17992.method_31574(ModItems.ECHO_PROTECTOR_STAFF) || class_17993.method_31574(ModItems.ECHO_PROTECTOR_STAFF) || class_17992.method_31574(ModItems.SOUL_PROTECTOR) || class_17993.method_31574(ModItems.SOUL_PROTECTOR);
    }

    private static boolean isWarden(class_1309 class_13092) {
        return class_7923.field_41177.method_10221((class_1299<?>)class_13092.method_5864()).toString().equals("minecraft:warden");
    }
}

