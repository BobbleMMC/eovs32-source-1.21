package uz.echoes.world;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import uz.echoes.block.ModBlocks;
import uz.echoes.structure.EchoArenaChestFiller;

/**
 * Tick-staged Echo arena generation coordinator.
 *
 * Content-restored version:
 * - keeps the chunk-wait safe staged build;
 * - restores a real themed boss arena instead of a plain bedrock disk;
 * - connects the arrival bridge directly into the arena;
 * - keeps the bridge entrance open by clearing the wall gate;
 * - restores altar, tall citadel ribs, balconies, loot chests and outer access.
 */
public final class EchoArenaAsyncBuilder {
    public enum BuildPhase {
        NONE(0, "none", false, false),
        IDLE(0, "idle", false, false),
        QUEUED(5, "queued", true, false),
        STARTED(10, "started", true, false),
        PREPARING(20, "preparing", true, false),
        GENERATING(40, "generating", true, false),
        BUILDING_PLATFORM(50, "building_platform", true, false),
        BUILDING_WALLS(65, "building_walls", true, false),
        BUILDING_BRIDGE(80, "building_bridge", true, false),
        MARKING_COMPLETE(95, "marking_complete", true, false),
        COMPLETE(100, "complete", false, true),
        FINISHED(100, "finished", false, true),
        FAILED(0, "failed", false, false),
        ERROR(0, "error", false, false);

        public final int progress;
        public final String displayName;
        public final boolean active;
        public final boolean complete;

        BuildPhase(int progress, String displayName, boolean active, boolean complete) {
            this.progress = progress;
            this.displayName = displayName;
            this.active = active;
            this.complete = complete;
        }

        public int getProgress() {
            return progress;
        }

        public String getDisplayName() {
            return displayName;
        }

        public boolean isActive() {
            return active;
        }

        public boolean isComplete() {
            return complete;
        }
    }

    private static final int CENTER_X = 0;
    private static final int CENTER_Y = 80;
    private static final int CENTER_Z = 0;
    private static final int PLATFORM_RADIUS = 40;
    private static final int INNER_SUPPORT_RADIUS = 34;
    private static final int WALL_RADIUS = 43;
    private static final int WALL_HEIGHT = 18;
    private static final int TOWER_HEIGHT = 58;
    private static final int ENTRY_GATE_HALF_WIDTH = 6;
    private static final int ENTRY_GATE_MIN_Z = -44;
    private static final int ENTRY_GATE_MAX_Z = -34;
    private static final int BRIDGE_START_Z = -96;
    private static final int BRIDGE_END_Z = -40;
    private static final int BRIDGE_HALF_WIDTH = 4;
    private static final int STEPS_PER_TICK = 384;

    private static final Set<UUID> BUILT_WORLDS = Collections.newSetFromMap(new ConcurrentHashMap<UUID, Boolean>());
    private static final Map<UUID, BuildPhase> PHASES = new ConcurrentHashMap<UUID, BuildPhase>();
    private static final Map<UUID, BuildTask> TASKS = new ConcurrentHashMap<UUID, BuildTask>();

    private EchoArenaAsyncBuilder() {
    }

    private static UUID getStableWorldId(class_3218 world) {
        String key = String.valueOf(world.method_27983());
        return UUID.nameUUIDFromBytes(key.getBytes(StandardCharsets.UTF_8));
    }

    public static void tickAllBuilds() {
        List<BuildTask> snapshot = new ArrayList<BuildTask>(TASKS.values());
        for (BuildTask task : snapshot) {
            task.tick();
        }
    }

    public static boolean isGenerating(class_3218 world) {
        if (world == null) {
            return false;
        }
        return TASKS.containsKey(getStableWorldId(world));
    }

    public static boolean startAsyncGeneration(class_3218 world) {
        if (world == null) {
            return false;
        }

        UUID worldId = getStableWorldId(world);
        if (isArenaBuilt(world)) {
            BUILT_WORLDS.add(worldId);
            TASKS.remove(worldId);
            PHASES.put(worldId, BuildPhase.COMPLETE);
            return false;
        }

        if (TASKS.containsKey(worldId)) {
            return false;
        }

        EchoDimensionSafetyManager.forceEssentialChunks(world);
        PHASES.put(worldId, BuildPhase.QUEUED);
        TASKS.put(worldId, new BuildTask(world, worldId));
        return true;
    }

    public static BuildPhase getCurrentPhase(class_3218 world) {
        if (world == null) {
            return BuildPhase.NONE;
        }

        UUID worldId = getStableWorldId(world);
        BuildPhase phase = PHASES.get(worldId);
        if (phase != null) {
            return phase;
        }
        if (isArenaBuilt(world)) {
            PHASES.put(worldId, BuildPhase.COMPLETE);
            return BuildPhase.COMPLETE;
        }
        return BuildPhase.IDLE;
    }

    public static boolean isArenaBuilt(class_3218 world) {
        if (world == null) {
            return false;
        }

        UUID worldId = getStableWorldId(world);
        if (BUILT_WORLDS.contains(worldId)) {
            return true;
        }

        boolean markerExists = world.method_8320(EchoArenaFixer.REGEN_MARKER_POS).method_27852(class_2246.field_9987);
        if (markerExists) {
            BUILT_WORLDS.add(worldId);
            PHASES.put(worldId, BuildPhase.COMPLETE);
            return true;
        }
        return false;
    }

    public static boolean hasBuilt(class_3218 world) {
        return isArenaBuilt(world);
    }

    public static boolean isBuilt(class_3218 world) {
        return isArenaBuilt(world);
    }

    public static boolean isComplete(class_3218 world) {
        return isArenaBuilt(world);
    }

    public static void requestBuild(class_3218 world) {
        startAsyncGeneration(world);
    }

    public static void buildNow(class_3218 world) {
        startAsyncGeneration(world);
    }

    public static void buildIfNeeded(class_3218 world) {
        if (!isArenaBuilt(world) && !isGenerating(world)) {
            startAsyncGeneration(world);
        }
    }

    public static void ensureBuilt(class_3218 world) {
        buildIfNeeded(world);
    }

    public static void ensureArenaBuilt(class_3218 world) {
        buildIfNeeded(world);
    }

    public static void ensureArena(class_3218 world) {
        buildIfNeeded(world);
    }

    public static void tick(class_3218 world) {
        if (world == null) {
            return;
        }
        buildIfNeeded(world);
        BuildTask task = TASKS.get(getStableWorldId(world));
        if (task != null) {
            task.tick();
        }
    }

    public static void serverTick(class_3218 world) {
        tick(world);
    }

    public static void onWorldTick(class_3218 world) {
        tick(world);
    }

    public static void markBuilt(class_3218 world) {
        if (world == null) {
            return;
        }
        UUID worldId = getStableWorldId(world);
        BUILT_WORLDS.add(worldId);
        TASKS.remove(worldId);
        PHASES.put(worldId, BuildPhase.COMPLETE);
    }

    private static final class BuildTask {
        private final class_3218 world;
        private final UUID worldId;
        private BuildPhase phase = BuildPhase.QUEUED;
        private int x;
        private int z;
        private int y;

        private BuildTask(class_3218 world, UUID worldId) {
            this.world = world;
            this.worldId = worldId;
            setPhase(BuildPhase.QUEUED);
        }

        private void tick() {
            int steps = 0;
            while (steps < STEPS_PER_TICK && phase.active) {
                switch (phase) {
                    case QUEUED:
                        setPhase(BuildPhase.STARTED);
                        break;
                    case STARTED:
                        EchoDimensionSafetyManager.forceEssentialChunks(world);
                        setPhase(BuildPhase.PREPARING);
                        break;
                    case PREPARING:
                        // Do not build the temporary custom arena/bridge here.
                        // The uploaded jar-style EchoArenaFixer is authoritative;
                        // this keeps the final arena, bridge and platform layout exact.
                        EchoSpawnPlatform.createPlatform(world, EchoArenaFixer.PLAYER_BRIDGE_SPAWN);
                        setPhase(BuildPhase.MARKING_COMPLETE);
                        break;
                    case BUILDING_PLATFORM:
                        steps += tickPlatform(STEPS_PER_TICK - steps);
                        break;
                    case BUILDING_WALLS:
                        steps += tickWalls(STEPS_PER_TICK - steps);
                        break;
                    case BUILDING_BRIDGE:
                        steps += tickBridge(STEPS_PER_TICK - steps);
                        break;
                    case MARKING_COMPLETE:
                        finishArenaDetails();
                        setState(EchoArenaFixer.MARKER_POS, class_2246.field_9987.method_9564());
                        setState(EchoArenaFixer.TALL_MARKER_POS, class_2246.field_9987.method_9564());
                        setState(EchoArenaFixer.REGEN_MARKER_POS, class_2246.field_9987.method_9564());
                        BUILT_WORLDS.add(worldId);
                        TASKS.remove(worldId);
                        setPhase(BuildPhase.COMPLETE);
                        break;
                    default:
                        TASKS.remove(worldId);
                        PHASES.put(worldId, BuildPhase.FAILED);
                        return;
                }
            }
        }

        private int tickPlatform(int budget) {
            int used = 0;
            while (x <= PLATFORM_RADIUS && used < budget) {
                int r2 = x * x + z * z;
                if (r2 <= PLATFORM_RADIUS * PLATFORM_RADIUS) {
                    setState(CENTER_X + x, CENTER_Y, CENTER_Z + z, arenaFloor(x, z));
                    if (r2 <= INNER_SUPPORT_RADIUS * INNER_SUPPORT_RADIUS) {
                        setState(CENTER_X + x, CENTER_Y - 1, CENTER_Z + z, UNDER_FLOOR);
                    }
                    if (r2 <= 7 * 7 && (Math.abs(x) == 7 || Math.abs(z) == 7)) {
                        setState(CENTER_X + x, CENTER_Y + 1, CENTER_Z + z, ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
                    }
                }
                advanceSquareCursor(-PLATFORM_RADIUS, PLATFORM_RADIUS);
                ++used;
            }
            if (x > PLATFORM_RADIUS) {
                setPhase(BuildPhase.BUILDING_WALLS);
            }
            return used;
        }

        private int tickWalls(int budget) {
            int used = 0;
            while (x <= WALL_RADIUS && used < budget) {
                int r2 = x * x + z * z;
                if (r2 >= PLATFORM_RADIUS * PLATFORM_RADIUS && r2 <= WALL_RADIUS * WALL_RADIUS) {
                    if (isOpenBridgeGate(x, z, y)) {
                        clearBlock(CENTER_X + x, CENTER_Y + y, CENTER_Z + z);
                    } else {
                        setState(CENTER_X + x, CENTER_Y + y, CENTER_Z + z, wallState(y));
                    }
                }
                ++y;
                if (y > WALL_HEIGHT) {
                    y = 1;
                    advanceSquareCursor(-WALL_RADIUS, WALL_RADIUS);
                }
                ++used;
            }
            if (x > WALL_RADIUS) {
                setPhase(BuildPhase.BUILDING_BRIDGE);
            }
            return used;
        }

        private int tickBridge(int budget) {
            int used = 0;
            while (z <= BRIDGE_END_Z && used < budget) {
                setState(CENTER_X + x, CENTER_Y, CENTER_Z + z, BRIDGE_FLOOR);
                setState(CENTER_X + x, CENTER_Y - 1, CENTER_Z + z, UNDER_FLOOR);
                clearBlock(CENTER_X + x, CENTER_Y + 1, CENTER_Z + z);
                clearBlock(CENTER_X + x, CENTER_Y + 2, CENTER_Z + z);
                clearBlock(CENTER_X + x, CENTER_Y + 3, CENTER_Z + z);
                if (x == -BRIDGE_HALF_WIDTH) {
                    setState(CENTER_X - BRIDGE_HALF_WIDTH - 1, CENTER_Y + 1, CENTER_Z + z, BRIDGE_RAIL);
                }
                if (x == BRIDGE_HALF_WIDTH) {
                    setState(CENTER_X + BRIDGE_HALF_WIDTH + 1, CENTER_Y + 1, CENTER_Z + z, BRIDGE_RAIL);
                }
                ++x;
                if (x > BRIDGE_HALF_WIDTH) {
                    x = -BRIDGE_HALF_WIDTH;
                    ++z;
                }
                ++used;
            }
            if (z > BRIDGE_END_Z) {
                reinforceArenaCenter();
                reinforcePlayerSpawn();
                openBridgeGate();
                setPhase(BuildPhase.MARKING_COMPLETE);
            }
            return used;
        }

        private void reinforceArenaCenter() {
            for (int dx = -2; dx <= 2; ++dx) {
                for (int dz = -2; dz <= 2; ++dz) {
                    setState(CENTER_X + dx, CENTER_Y, CENTER_Z + dz, ModBlocks.SCULK_REINFORCED_STONE.method_9564());
                    setState(CENTER_X + dx, CENTER_Y - 1, CENTER_Z + dz, UNDER_FLOOR);
                }
            }
            setState(CENTER_X, CENTER_Y + 1, CENTER_Z, ModBlocks.ECHO_ALTAR.method_9564());
        }

        private void reinforcePlayerSpawn() {
            int spawnX = EchoArenaFixer.PLAYER_BRIDGE_SPAWN.method_10263();
            int spawnY = EchoArenaFixer.PLAYER_BRIDGE_SPAWN.method_10264();
            int spawnZ = EchoArenaFixer.PLAYER_BRIDGE_SPAWN.method_10260();
            for (int dx = -3; dx <= 3; ++dx) {
                for (int dz = -3; dz <= 3; ++dz) {
                    setState(spawnX + dx, spawnY, spawnZ + dz, BRIDGE_FLOOR);
                    setState(spawnX + dx, spawnY - 1, spawnZ + dz, UNDER_FLOOR);
                    for (int dy = 1; dy <= 5; ++dy) {
                        clearBlock(spawnX + dx, spawnY + dy, spawnZ + dz);
                    }
                }
            }
        }

        private void finishArenaDetails() {
            // Final pass deliberately delegates to EchoArenaFixer so the restored
            // 1.0.1 tall citadel layout, old bridge, opposite exit frame, shrieker
            // regen pillars and exact chest positions are authoritative.
            EchoArenaFixer.generateArena(world);
        }

        private void openBridgeGate() {
            for (int gx = -ENTRY_GATE_HALF_WIDTH; gx <= ENTRY_GATE_HALF_WIDTH; ++gx) {
                for (int gz = ENTRY_GATE_MIN_Z; gz <= ENTRY_GATE_MAX_Z; ++gz) {
                    for (int gy = 1; gy <= WALL_HEIGHT + 4; ++gy) {
                        clearBlock(CENTER_X + gx, CENTER_Y + gy, CENTER_Z + gz);
                    }
                    setState(CENTER_X + gx, CENTER_Y, CENTER_Z + gz, BRIDGE_FLOOR);
                    setState(CENTER_X + gx, CENTER_Y - 1, CENTER_Z + gz, UNDER_FLOOR);
                }
            }
            for (int gz = ENTRY_GATE_MIN_Z; gz <= ENTRY_GATE_MAX_Z; ++gz) {
                setState(CENTER_X - ENTRY_GATE_HALF_WIDTH - 1, CENTER_Y + 1, CENTER_Z + gz, WALL_TRIM);
                setState(CENTER_X + ENTRY_GATE_HALF_WIDTH + 1, CENTER_Y + 1, CENTER_Z + gz, WALL_TRIM);
            }
        }

        private boolean isOpenBridgeGate(int rx, int rz, int ry) {
            return Math.abs(rx) <= ENTRY_GATE_HALF_WIDTH && rz >= ENTRY_GATE_MIN_Z && rz <= ENTRY_GATE_MAX_Z && ry >= 1 && ry <= WALL_HEIGHT + 4;
        }

        private void buildAnchorPillars() {
            int[][] anchors = regenPillarOffsets();
            for (int[] pair : anchors) {
                int px = pair[0];
                int pz = pair[1];
                for (int py = 1; py <= 42; ++py) {
                    class_2680 state = py % 4 == 0 ? ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564() : WALL_TRIM;
                    setState(CENTER_X + px, CENTER_Y + py, CENTER_Z + pz, state);
                    if (py <= 36) {
                        setState(CENTER_X + px + 1, CENTER_Y + py, CENTER_Z + pz, state);
                        setState(CENTER_X + px - 1, CENTER_Y + py, CENTER_Z + pz, state);
                        setState(CENTER_X + px, CENTER_Y + py, CENTER_Z + pz + 1, state);
                        setState(CENTER_X + px, CENTER_Y + py, CENTER_Z + pz - 1, state);
                    }
                }
                setState(CENTER_X + px, EchoArenaFixer.REGEN_SHRIEKER_Y - 1, CENTER_Z + pz, ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
                setState(CENTER_X + px, EchoArenaFixer.REGEN_SHRIEKER_Y, CENTER_Z + pz, block("sculk_shrieker").method_9564());
                setState(CENTER_X + px + 1, EchoArenaFixer.REGEN_SHRIEKER_Y, CENTER_Z + pz, block("sculk_sensor").method_9564());
                setState(CENTER_X + px - 1, EchoArenaFixer.REGEN_SHRIEKER_Y, CENTER_Z + pz, block("sculk_sensor").method_9564());
            }
        }

        private int[][] regenPillarOffsets() {
            int[][] result = new int[8][2];
            for (int i = 0; i < result.length; i++) {
                double radians = Math.PI * 2.0 * (double)i / (double)result.length;
                result[i][0] = (int)Math.round(Math.cos(radians) * 25.0);
                result[i][1] = (int)Math.round(Math.sin(radians) * 25.0);
            }
            return result;
        }

        private void buildTallCitadelFrame() {
            // Tall old-style citadel frame: high ribs, balcony rings and open sky.
            // This restores the earlier tower feeling without using a heavy full solid wall.
            for (int angle = 0; angle < 360; angle += 30) {
                double radians = Math.toRadians(angle);
                int px = (int)Math.round(Math.cos(radians) * (double)WALL_RADIUS);
                int pz = (int)Math.round(Math.sin(radians) * (double)WALL_RADIUS);
                if (pz <= ENTRY_GATE_MAX_Z + 2 && Math.abs(px) <= ENTRY_GATE_HALF_WIDTH + 2) {
                    continue;
                }
                for (int py = WALL_HEIGHT + 1; py <= TOWER_HEIGHT; ++py) {
                    class_2680 rib = py % 9 == 0 ? ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564() : WALL_TRIM;
                    setState(CENTER_X + px, CENTER_Y + py, CENTER_Z + pz, rib);
                    if (py % 12 == 0) {
                        setState(CENTER_X + px, CENTER_Y + py, CENTER_Z + pz + 1, WALL_TRIM);
                        setState(CENTER_X + px + 1, CENTER_Y + py, CENTER_Z + pz, WALL_TRIM);
                    }
                }
            }

            int[] ringHeights = new int[]{18, 30, 42, 54};
            for (int ringY : ringHeights) {
                for (int angle = 0; angle < 360; angle += 10) {
                    double radians = Math.toRadians(angle);
                    int px = (int)Math.round(Math.cos(radians) * (double)WALL_RADIUS);
                    int pz = (int)Math.round(Math.sin(radians) * (double)WALL_RADIUS);
                    if (pz <= ENTRY_GATE_MAX_Z + 2 && Math.abs(px) <= ENTRY_GATE_HALF_WIDTH + 2 && ringY <= 30) {
                        continue;
                    }
                    setState(CENTER_X + px, CENTER_Y + ringY, CENTER_Z + pz, ringY % 20 == 0 ? ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564() : WALL_TRIM);
                }
            }
        }

        private void buildBalconyLootChests() {
            int[][] balconies = new int[][]{
                    {24, 1, 24}, {-24, 1, 24}, {24, 1, -24}, {-24, 1, -24},
                    {31, 14, 0}, {-31, 14, 0}, {0, 14, 31}, {0, 14, -31},
                    {28, 30, 28}, {-28, 30, 28}, {28, 30, -28}, {-28, 30, -28}
            };
            for (int[] balcony : balconies) {
                buildLootBalcony(balcony[0], balcony[1], balcony[2]);
            }
            EchoArenaChestFiller.placeArenaChests(world, new class_2338(CENTER_X, CENTER_Y + 1, CENTER_Z));
            EchoArenaChestFiller.placeTallCitadelChests(world, new class_2338(CENTER_X, CENTER_Y, CENTER_Z));
        }

        private void buildLootBalcony(int rx, int ry, int rz) {
            for (int dx = -2; dx <= 2; ++dx) {
                for (int dz = -2; dz <= 2; ++dz) {
                    setState(CENTER_X + rx + dx, CENTER_Y + ry - 1, CENTER_Z + rz + dz, BRIDGE_FLOOR);
                    clearBlock(CENTER_X + rx + dx, CENTER_Y + ry, CENTER_Z + rz + dz);
                    clearBlock(CENTER_X + rx + dx, CENTER_Y + ry + 1, CENTER_Z + rz + dz);
                    clearBlock(CENTER_X + rx + dx, CENTER_Y + ry + 2, CENTER_Z + rz + dz);
                }
            }
            setState(CENTER_X + rx, CENTER_Y + ry - 2, CENTER_Z + rz, UNDER_FLOOR);
        }

        private void buildCitadelCrown() {
            for (int angle = 0; angle < 360; angle += 15) {
                double radians = Math.toRadians(angle);
                int px = (int)Math.round(Math.cos(radians) * (double)WALL_RADIUS);
                int pz = (int)Math.round(Math.sin(radians) * (double)WALL_RADIUS);
                if (pz <= ENTRY_GATE_MAX_Z + 2 && Math.abs(px) <= ENTRY_GATE_HALF_WIDTH + 2) {
                    continue;
                }
                setState(CENTER_X + px, CENTER_Y + TOWER_HEIGHT, CENTER_Z + pz, ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564());
                setState(CENTER_X + px, CENTER_Y + TOWER_HEIGHT - 1, CENTER_Z + pz, WALL_TRIM);
            }
        }

        private void buildArenaRunes() {
            for (int r = 8; r <= 32; r += 8) {
                for (int dx = -r; dx <= r; ++dx) {
                    int dz = r - Math.abs(dx);
                    setState(CENTER_X + dx, CENTER_Y + 1, CENTER_Z + dz, block("sculk_vein").method_9564());
                    setState(CENTER_X + dx, CENTER_Y + 1, CENTER_Z - dz, block("sculk_vein").method_9564());
                }
            }
            setState(CENTER_X + 6, CENTER_Y + 1, CENTER_Z, block("sculk_sensor").method_9564());
            setState(CENTER_X - 6, CENTER_Y + 1, CENTER_Z, block("sculk_sensor").method_9564());
            setState(CENTER_X, CENTER_Y + 1, CENTER_Z + 6, block("sculk_shrieker").method_9564());
            setState(CENTER_X, CENTER_Y + 1, CENTER_Z - 6, block("sculk_shrieker").method_9564());
        }

        private void buildExitPortalFramePreview() {
            // Locked preview frame on the far side of the arena. The real exit
            // portal is still opened by the boss-defeat handler.
            for (int fx = -5; fx <= 5; ++fx) {
                setState(CENTER_X + fx, CENTER_Y + 1, CENTER_Z - 39, block("reinforced_deepslate").method_9564());
                setState(CENTER_X + fx, CENTER_Y + 6, CENTER_Z - 39, block("reinforced_deepslate").method_9564());
            }
            for (int fy = 1; fy <= 6; ++fy) {
                setState(CENTER_X - 5, CENTER_Y + fy, CENTER_Z - 39, block("reinforced_deepslate").method_9564());
                setState(CENTER_X + 5, CENTER_Y + fy, CENTER_Z - 39, block("reinforced_deepslate").method_9564());
            }
        }

        private void clearArenaInterior() {
            for (int cx = -18; cx <= 18; ++cx) {
                for (int cz = -18; cz <= 18; ++cz) {
                    if (cx * cx + cz * cz > 18 * 18) {
                        continue;
                    }
                    for (int cy = 2; cy <= 35; ++cy) {
                        class_2338 pos = new class_2338(CENTER_X + cx, CENTER_Y + cy, CENTER_Z + cz);
                        if (!world.method_8320(pos).method_27852(ModBlocks.ECHO_ALTAR)
                                && !world.method_8320(pos).method_27852(ModBlocks.ECHO_CRYSTAL_BLOCK)) {
                            clearBlock(pos);
                        }
                    }
                }
            }
        }

        private void advanceSquareCursor(int min, int max) {
            ++z;
            if (z > max) {
                z = min;
                ++x;
            }
        }

        private void setPhase(BuildPhase newPhase) {
            this.phase = newPhase;
            PHASES.put(worldId, newPhase);
            if (newPhase == BuildPhase.BUILDING_PLATFORM) {
                x = -PLATFORM_RADIUS;
                z = -PLATFORM_RADIUS;
                y = 0;
            } else if (newPhase == BuildPhase.BUILDING_WALLS) {
                x = -WALL_RADIUS;
                z = -WALL_RADIUS;
                y = 1;
            } else if (newPhase == BuildPhase.BUILDING_BRIDGE) {
                x = -BRIDGE_HALF_WIDTH;
                z = BRIDGE_START_Z;
                y = 0;
            }
        }

        private class_2680 arenaFloor(int rx, int rz) {
            int stripe = Math.abs(rx) + Math.abs(rz);
            if (stripe % 9 == 0) {
                return ModBlocks.ECHO_CRYSTAL_BLOCK.method_9564();
            }
            if (stripe % 5 == 0) {
                return block("deepslate_tiles").method_9564();
            }
            return ModBlocks.SCULK_REINFORCED_STONE.method_9564();
        }

        private class_2680 wallState(int py) {
            if (py == WALL_HEIGHT) {
                return WALL_TRIM;
            }
            if (py % 4 == 0) {
                return block("chiseled_deepslate").method_9564();
            }
            return WALL;
        }

        private void clearBlock(int bx, int by, int bz) {
            clearBlock(new class_2338(bx, by, bz));
        }

        private void clearBlock(class_2338 pos) {
            setState(pos, AIR);
        }

        private void setState(int bx, int by, int bz, class_2680 state) {
            setState(new class_2338(bx, by, bz), state);
        }

        private void setState(class_2338 pos, class_2680 state) {
            world.method_8501(pos, state);
        }
    }

    private static class_2248 block(String id) {
        return (class_2248)class_7923.field_41175.method_10223(class_2960.method_60655("minecraft", id));
    }

    private static final class_2680 AIR = class_2246.field_10124.method_9564();
    private static final class_2680 UNDER_FLOOR = class_2246.field_9987.method_9564();
    private static final class_2680 BRIDGE_FLOOR = ModBlocks.SCULK_REINFORCED_STONE.method_9564();
    private static final class_2680 BRIDGE_RAIL = ModBlocks.VOID_GLASS.method_9564();
    private static final class_2680 WALL = block("deepslate_bricks").method_9564();
    private static final class_2680 WALL_TRIM = block("reinforced_deepslate").method_9564();
}
