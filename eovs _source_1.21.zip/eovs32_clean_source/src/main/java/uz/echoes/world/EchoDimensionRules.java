/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
 *  net.fabricmc.fabric.api.event.player.UseItemCallback
 *  net.minecraft.class_1271
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_2960
 *  net.minecraft.class_3218
 *  net.minecraft.class_7923
 */
package uz.echoes.world;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2784;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import uz.echoes.block.ModBlocks;
import uz.echoes.item.EchoArmorMaterial;
import uz.echoes.world.EchoDimensionKeys;

public final class EchoDimensionRules {
    private static int tickCounter;

    private EchoDimensionRules() {
    }

    public static void register() {
        ServerWorldEvents.LOAD.register((minecraftServer, class_32182) -> {
            if (class_32182.method_27983().equals(EchoDimensionKeys.ECHO_DIMENSION)) {
                EchoDimensionRules.applyEchoWorldBorder(class_32182);
            }
        });
        ServerTickEvents.END_SERVER_TICK.register(minecraftServer -> {
            class_3218 class_32182 = minecraftServer.method_3847(EchoDimensionKeys.ECHO_DIMENSION);
            if (class_32182 == null) {
                return;
            }
            if (class_32182.method_18456().isEmpty()) {
                return;
            }
            EchoDimensionRules.applyEchoArmorBuffs(class_32182);
            if (++tickCounter % 10 == 0) {
                EchoDimensionRules.poisonWaterTouchedEntities(class_32182);
            }
            if (tickCounter % 40 == 0) {
                EchoDimensionRules.suppressCoveredShriekers(class_32182);
            }
        });
        // Do not register a global UseItemCallback here.
        // Previous builds tried to block one vanilla item in the Echo Dimension,
        // but the obfuscated item constant pointed at a normal vanilla use item
        // and cancelled right-click processing before vanilla food/projectile/bow
        // style items could run. Dimension rules must not own the generic item
        // use pipeline; item-specific behavior belongs in item classes.
    }

    private static void applyEchoWorldBorder(class_3218 class_32182) {
        class_2784 class_27842 = class_32182.method_8621();
        if (Math.abs(class_27842.method_11964()) > 0.5 || Math.abs(class_27842.method_11980()) > 0.5) {
            class_27842.method_11978(0.0, 0.0);
        }
        if (Math.abs(class_27842.method_11958() - 1000000.0) > 1.0) {
            class_27842.method_11969(1000000.0);
        }
    }

    private static void poisonWaterTouchedEntities(class_3218 class_32182) {
        for (class_1657 class_16572 : class_32182.method_18456()) {
            class_238 class_2382 = class_16572.method_5829().method_1014(16.0);
            for (class_1309 class_13092 : class_32182.method_8390(class_1309.class, class_2382, class_1309::method_5805)) {
                if (!class_13092.method_5869() && !class_13092.method_5799() || EchoArmorMaterial.hasFullEchoArmor(class_13092)) continue;
                class_13092.method_6092(new class_1293(class_1294.field_5899, 60, 0, true, true, true));
            }
        }
    }

    private static void applyEchoArmorBuffs(class_3218 class_32182) {
        for (class_1657 class_16572 : class_32182.method_18456()) {
            if (EchoArmorMaterial.hasFullEchoArmor((class_1309)class_16572)) {
                class_16572.method_6092(new class_1293(class_1294.field_5907, 40, 4, true, false, true));
            }
            class_238 class_2382 = class_16572.method_5829().method_1014(32.0);
            for (class_1309 class_13093 : class_32182.method_8390(class_1309.class, class_2382, class_13092 -> class_13092 != class_16572 && class_13092.method_5805() && EchoArmorMaterial.hasFullEchoArmor(class_13092))) {
                class_13093.method_6092(new class_1293(class_1294.field_5907, 40, 4, true, false, true));
            }
        }
    }

    private static void suppressCoveredShriekers(class_3218 class_32182) {
        class_2248 class_22482 = (class_2248)class_7923.field_41175.method_10223(class_2960.method_60655((String)"minecraft", (String)"sculk_shrieker"));
        class_2248 class_22483 = (class_2248)class_7923.field_41175.method_10223(class_2960.method_60655((String)"minecraft", (String)"sculk"));
        for (class_1657 class_16572 : class_32182.method_18456()) {
            class_2338 class_23382 = class_16572.method_24515();
            for (int i = -8; i <= 8; ++i) {
                for (int j = -4; j <= 4; ++j) {
                    for (int k = -8; k <= 8; ++k) {
                        class_2338 class_23383;
                        class_2338 class_23384 = class_23382.method_10069(i, j, k);
                        if (!uz.echoes.world.EchoProtectorSpawnRules.isProtectorBlock(class_32182.method_8320(class_23384)) || !class_32182.method_8320(class_23383 = class_23384.method_10074()).method_27852(class_22482)) continue;
                        class_32182.method_8652(class_23383, class_22483.method_9564(), 3);
                    }
                }
            }
        }
    }
}
