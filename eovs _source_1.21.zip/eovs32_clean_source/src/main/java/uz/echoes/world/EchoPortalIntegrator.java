/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 */
package uz.echoes.world;

public class EchoPortalIntegrator {
    public static void integratePortal() {
        System.out.println("Portal integrated");
    }
}

