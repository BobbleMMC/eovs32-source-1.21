package uz.echoes.world;

import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import uz.echoes.entity.EchoWardenMonarchEntity;

/**
 * Alternating sculk-shrieker pillar regeneration.
 *
 * Only one pillar is active per pulse. This restores the old arena mechanic
 * without healing every tick and without creating a particle storm.
 */
public final class EchoAnchorRegeneration {
    private static final int ARENA_RADIUS = 25;
    private static final int PILLAR_COUNT = 8;
    private static final int PULSE_INTERVAL_TICKS = 60;
    private static int tickCounter;
    private static int activePillar = -1;

    private EchoAnchorRegeneration() {
    }

    public static void tick(class_3218 world) {
        if (world == null) {
            return;
        }
        if (++tickCounter < PULSE_INTERVAL_TICKS) {
            return;
        }
        tickCounter = 0;
        activePillar = (activePillar + 1) % PILLAR_COUNT;

        class_2338 center = EchoArenaFixer.ARENA_CENTER;
        List bosses = world.method_8390(EchoWardenMonarchEntity.class, new class_238(center).method_1014(96.0), class_1309::method_5805);
        if (bosses.isEmpty()) {
            return;
        }

        EchoWardenMonarchEntity boss = (EchoWardenMonarchEntity)((Object)bosses.get(0));
        if (boss.method_6032() >= boss.method_6063()) {
            return;
        }

        class_2338 shriekerPos = getPillarPos(activePillar);
        if (!world.method_8320(shriekerPos).method_27852(class_2246.field_37571)) {
            return;
        }

        float healAmount = boss.getEchoPhase() >= 3 ? 3.0f : 2.0f;
        boss.method_6025(healAmount);

        double x = (double)shriekerPos.method_10263() + 0.5;
        double y = (double)shriekerPos.method_10264() + 1.15;
        double z = (double)shriekerPos.method_10260() + 0.5;
        world.method_14199((class_2394)class_2398.field_38002, x, y, z, 4, 0.18, 0.25, 0.18, 0.004);
        world.method_14199((class_2394)class_2398.field_38908, boss.method_23317(), boss.method_23318() + 3.2, boss.method_23321(), 1, 0.10, 0.12, 0.10, 0.0);
    }

    private static class_2338 getPillarPos(int index) {
        double radians = Math.PI * 2.0 * (double)index / (double)PILLAR_COUNT;
        int x = (int)Math.round(Math.cos(radians) * (double)ARENA_RADIUS);
        int z = (int)Math.round(Math.sin(radians) * (double)ARENA_RADIUS);
        return new class_2338(x, EchoArenaFixer.REGEN_SHRIEKER_Y, z);
    }
}
