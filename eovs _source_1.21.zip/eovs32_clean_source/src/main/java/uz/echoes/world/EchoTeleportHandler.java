/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 */
package uz.echoes.world;

public class EchoTeleportHandler {
    public static void handleTeleport() {
        System.out.println("Teleport handled");
    }
}

