/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 */
package uz.echoes.world;

public class EchoDimensionHandler {
    public static void initDimension() {
        System.out.println("Echo dimension initialized");
    }
}

