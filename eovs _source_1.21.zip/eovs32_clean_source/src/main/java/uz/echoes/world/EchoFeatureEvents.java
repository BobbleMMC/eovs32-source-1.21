package uz.echoes.world;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import uz.echoes.block.EchoCrystalBlock;
import uz.echoes.block.EchoProtectorBlock;
import uz.echoes.block.ModBlocks;

public final class EchoFeatureEvents {
    private static final int FAST_INTERVAL_TICKS = 10;
    private static final int FULL_SCAN_INTERVAL_TICKS = 40;
    private static final int PLAYER_SCAN_RADIUS = 36;
    private static final int PLAYER_SCAN_VERTICAL_RADIUS = 16;
    private static final int MAX_CRYSTAL_RELAYS_PER_TICK = 8;

    private static final Map<String, Integer> WORLD_TICKS = new HashMap<>();
    private static final Map<String, Set<class_2338>> CACHED_PROTECTORS = new HashMap<>();
    private static final Map<String, Set<class_2338>> CACHED_CRYSTALS = new HashMap<>();
    private static final Map<String, Set<class_2338>> MANAGED_LIGHTS = new HashMap<>();
    private static final Map<String, Set<class_2338>> MANAGED_REDSTONE = new HashMap<>();

    private EchoFeatureEvents() {
    }

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(EchoFeatureEvents::tick);
    }

    private static void tick(class_3218 world) {
        String worldKey = String.valueOf(world.method_27983());
        int tick = WORLD_TICKS.getOrDefault(worldKey, 0) + 1;
        WORLD_TICKS.put(worldKey, tick);

        boolean fullScan = tick % FULL_SCAN_INTERVAL_TICKS == 0 || !CACHED_PROTECTORS.containsKey(worldKey);
        if (fullScan) {
            refreshCachedBlocks(world, worldKey);
        }
        if (tick % FAST_INTERVAL_TICKS != 0 && !fullScan) {
            return;
        }

        Set<class_2338> protectors = CACHED_PROTECTORS.getOrDefault(worldKey, Set.of());
        Set<class_2338> crystals = CACHED_CRYSTALS.getOrDefault(worldKey, Set.of());

        Set<class_2338> desiredLights = new HashSet<>();
        for (class_2338 protector : protectors) {
            if (!EchoProtectorSpawnRules.isProtectorBlock(world.method_8320(protector))) {
                continue;
            }
            protect(world, protector);
            installEchoLightField(world, protector, desiredLights);
        }
        cleanupManagedLights(world, worldKey, desiredLights);
        MANAGED_LIGHTS.put(worldKey, desiredLights);

        Set<class_2338> desiredRedstone = new HashSet<>();
        int relayed = 0;
        for (class_2338 crystal : crystals) {
            if (!world.method_8320(crystal).method_27852(ModBlocks.ECHO_CRYSTAL_BLOCK)) {
                continue;
            }
            energizeRedstoneNetwork(world, crystal, desiredRedstone);
            if (++relayed >= MAX_CRYSTAL_RELAYS_PER_TICK) {
                break;
            }
        }
        cleanupManagedRedstone(world, worldKey, desiredRedstone);
        MANAGED_REDSTONE.put(worldKey, desiredRedstone);
    }

    private static void refreshCachedBlocks(class_3218 world, String worldKey) {
        Set<class_2338> protectors = new HashSet<>();
        Set<class_2338> crystals = new HashSet<>();
        for (class_1657 player : world.method_18456()) {
            scanBlocks(world, player.method_24515(), PLAYER_SCAN_RADIUS, PLAYER_SCAN_VERTICAL_RADIUS, protectors, crystals);
        }
        CACHED_PROTECTORS.put(worldKey, protectors);
        CACHED_CRYSTALS.put(worldKey, crystals);
    }

    private static void scanBlocks(class_3218 world, class_2338 center, int radius, int verticalRadius, Set<class_2338> protectors, Set<class_2338> crystals) {
        int radiusSq = radius * radius;
        for (int x = -radius; x <= radius; ++x) {
            for (int y = -verticalRadius; y <= verticalRadius; ++y) {
                for (int z = -radius; z <= radius; ++z) {
                    if (x * x + z * z > radiusSq) {
                        continue;
                    }
                    class_2338 pos = center.method_10069(x, y, z);
                    class_2680 state = world.method_8320(pos);
                    if (EchoProtectorSpawnRules.isProtectorBlock(state)) {
                        protectors.add(pos);
                    } else if (state.method_27852(ModBlocks.ECHO_CRYSTAL_BLOCK)) {
                        crystals.add(pos);
                    }
                }
            }
        }
    }

    private static void protect(class_3218 world, class_2338 protector) {
        class_238 box = new class_238(protector).method_1014((double)EchoProtectorBlock.PROTECTION_RADIUS);
        for (class_1309 mob : world.method_8390(class_1309.class, box, EchoFeatureEvents::isDarkSpawnHostile)) {
            if (mob instanceof class_1308) {
                ((class_1308)mob).method_5980(null);
            }
            mob.method_31472();
        }
    }

    private static boolean isDarkSpawnHostile(class_1309 entity) {
        return EchoProtectorSpawnRules.isDarkSpawnHostile(entity);
    }

    private static void installEchoLightField(class_3218 world, class_2338 protector, Set<class_2338> desiredLights) {
        int radius = EchoProtectorBlock.ECHO_LIGHT_FIELD_RADIUS;
        int vertical = EchoProtectorBlock.ECHO_LIGHT_FIELD_VERTICAL_RADIUS;
        int spacing = EchoProtectorBlock.ECHO_LIGHT_SPACING;
        int radiusSq = radius * radius;

        for (int x = -radius; x <= radius; x += spacing) {
            for (int y = -vertical; y <= vertical; y += spacing) {
                for (int z = -radius; z <= radius; z += spacing) {
                    if (x * x + z * z > radiusSq) {
                        continue;
                    }
                    class_2338 lightPos = protector.method_10069(x, y, z);
                    desiredLights.add(lightPos);
                    class_2680 current = world.method_8320(lightPos);
                    if (current.method_26215() || current.method_27852(class_2246.field_31037)) {
                        class_2680 lightState = withComparableProperty(class_2246.field_31037.method_9564(), "level", Integer.valueOf(15));
                        world.method_8652(lightPos, lightState, 3);
                    }
                }
            }
        }
    }

    private static void cleanupManagedLights(class_3218 world, String worldKey, Set<class_2338> desiredLights) {
        Set<class_2338> previous = MANAGED_LIGHTS.get(worldKey);
        if (previous == null || previous.isEmpty()) {
            return;
        }
        for (class_2338 old : previous) {
            if (!desiredLights.contains(old) && world.method_8320(old).method_27852(class_2246.field_31037)) {
                world.method_8652(old, class_2246.field_10124.method_9564(), 3);
            }
        }
    }

    private static void energizeRedstoneNetwork(class_3218 world, class_2338 crystal, Set<class_2338> desiredRedstone) {
        int range = EchoCrystalBlock.REDSTONE_RANGE;
        int rangeSq = range * range;
        for (int x = -range; x <= range; ++x) {
            for (int y = -range; y <= range; ++y) {
                for (int z = -range; z <= range; ++z) {
                    if (x * x + y * y + z * z > rangeSq) {
                        continue;
                    }
                    class_2338 pos = crystal.method_10069(x, y, z);
                    class_2680 state = world.method_8320(pos);
                    if (!isRedstoneReceiver(state)) {
                        continue;
                    }
                    class_2680 energized = energizeState(state);
                    if (energized != state) {
                        world.method_8652(pos, energized, 3);
                        desiredRedstone.add(pos);
                    } else {
                        world.method_8652(pos, state, 3);
                    }
                }
            }
        }
    }

    private static void cleanupManagedRedstone(class_3218 world, String worldKey, Set<class_2338> desiredRedstone) {
        Set<class_2338> previous = MANAGED_REDSTONE.get(worldKey);
        if (previous == null || previous.isEmpty()) {
            return;
        }
        for (class_2338 old : previous) {
            if (desiredRedstone.contains(old)) {
                continue;
            }
            class_2680 state = world.method_8320(old);
            class_2680 reset = resetEchoRedstoneState(state);
            if (reset != state) {
                world.method_8652(old, reset, 3);
            } else {
                world.method_8652(old, state, 3);
            }
        }
    }

    private static boolean isRedstoneReceiver(class_2680 state) {
        String id = class_7923.field_41175.method_10221(state.method_26204()).toString();
        return id.equals("minecraft:redstone_wire") || id.equals("minecraft:redstone_lamp") || id.contains("repeater") || id.contains("comparator") || id.contains("piston") || id.contains("dispenser") || id.contains("dropper") || id.contains("observer") || id.contains("door") || id.contains("trapdoor") || id.contains("rail") || id.contains("note_block") || id.equals("minecraft:tnt") || hasComparableProperty(state, "power", Integer.class) || hasComparableProperty(state, "powered", Boolean.class) || hasComparableProperty(state, "lit", Boolean.class) || hasComparableProperty(state, "triggered", Boolean.class);
    }

    private static class_2680 energizeState(class_2680 state) {
        class_2680 out = state;
        out = withComparableProperty(out, "power", Integer.valueOf(15));
        out = withComparableProperty(out, "powered", Boolean.TRUE);
        out = withComparableProperty(out, "lit", Boolean.TRUE);
        out = withComparableProperty(out, "triggered", Boolean.TRUE);
        return out;
    }

    private static class_2680 resetEchoRedstoneState(class_2680 state) {
        class_2680 out = state;
        out = withComparableProperty(out, "power", Integer.valueOf(0));
        out = withComparableProperty(out, "powered", Boolean.FALSE);
        out = withComparableProperty(out, "lit", Boolean.FALSE);
        out = withComparableProperty(out, "triggered", Boolean.FALSE);
        return out;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static boolean hasComparableProperty(class_2680 state, String propertyName, Class<?> valueType) {
        for (Object raw : state.method_28501()) {
            class_2769 property = (class_2769)raw;
            if (propertyName.equals(property.method_11899()) && valueType.equals(property.method_11902())) {
                return true;
            }
        }
        return false;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static class_2680 withComparableProperty(class_2680 state, String propertyName, Comparable value) {
        for (Object raw : state.method_28501()) {
            class_2769 property = (class_2769)raw;
            if (propertyName.equals(property.method_11899()) && property.method_11902().isInstance(value)) {
                return (class_2680)state.method_11657(property, value);
            }
        }
        return state;
    }
}
