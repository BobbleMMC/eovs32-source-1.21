/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 *  net.minecraft.class_3218
 */
package uz.echoes.world;

import net.minecraft.class_2338;
import net.minecraft.class_3218;
import uz.echoes.structure.EchoArenaBoundary;
import uz.echoes.structure.EchoArenaHeightFix;
import uz.echoes.structure.EchoStructureValidator;

public class EchoStructureInitializer {
    public static void initArena(class_3218 class_32182) {
        class_2338 class_23382 = new class_2338(0, 80, 0);
        if (!EchoStructureValidator.isAreaSafe(class_32182, class_23382)) {
            class_23382 = EchoArenaHeightFix.adjustHeight(class_32182, class_23382);
        }
        EchoArenaBoundary.createBoundary(class_32182, class_23382);
    }
}

