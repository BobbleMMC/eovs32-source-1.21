package uz.echoes.world;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_3218;
import uz.echoes.portal.EchoDimensionKeys;

/**
 * Extra guard for first-load / command-teleport cases.
 *
 * EchoArenaWorldEvents already performs player safety, but this END_WORLD_TICK
 * hook runs directly on the Echo ServerWorld and keeps entry rescue independent
 * from arena generation state. It is deliberately tiny and idempotent.
 */
public final class EchoDimensionEntryRescueEvents {
    private EchoDimensionEntryRescueEvents() {
    }

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(EchoDimensionEntryRescueEvents::tickWorld);
    }

    private static void tickWorld(class_3218 world) {
        if (world == null || !world.method_27983().equals(EchoDimensionKeys.ECHO_DIMENSION)) {
            return;
        }
        EchoDimensionSafetyManager.tickPlayerSafety(world);
    }
}
