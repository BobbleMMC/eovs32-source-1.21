package uz.echoes.world;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import uz.echoes.portal.EchoDimensionKeys;

public final class EchoWardenSpawnLimiter {
    public static final int MAX_NATURAL_ECHO_WARDENS = 3;
    private static final double LOADED_SEARCH_RADIUS = 512.0;

    private EchoWardenSpawnLimiter() {
    }

    public static boolean shouldBlockWardenSpawn(class_3218 world, class_1297 entity) {
        if (world == null || entity == null || !world.method_27983().equals(EchoDimensionKeys.ECHO_DIMENSION)) {
            return false;
        }
        if (!(entity instanceof class_1309) || !isWarden((class_1309)entity)) {
            return false;
        }
        return countLoadedWardensNear(world, entity.method_5829().method_1014(LOADED_SEARCH_RADIUS), entity) >= MAX_NATURAL_ECHO_WARDENS;
    }

    public static void enforceLoadedCap(class_3218 world) {
        if (world == null || !world.method_27983().equals(EchoDimensionKeys.ECHO_DIMENSION)) {
            return;
        }
        Set<class_1309> seen = new HashSet<>();
        for (class_1657 player : world.method_18456()) {
            class_238 box = player.method_5829().method_1014(LOADED_SEARCH_RADIUS);
            for (class_1309 warden : world.method_8390(class_1309.class, box, EchoWardenSpawnLimiter::isWarden)) {
                seen.add(warden);
            }
        }
        int kept = 0;
        for (class_1309 warden : seen) {
            if (++kept > MAX_NATURAL_ECHO_WARDENS) {
                warden.method_31472();
            }
        }
    }

    private static int countLoadedWardensNear(class_3218 world, class_238 box, class_1297 ignoredEntity) {
        int count = 0;
        for (class_1309 warden : world.method_8390(class_1309.class, box, EchoWardenSpawnLimiter::isWarden)) {
            if (warden != ignoredEntity) {
                ++count;
            }
        }
        return count;
    }

    private static boolean isWarden(class_1309 entity) {
        return class_7923.field_41177.method_10221((class_1299<?>)entity.method_5864()).toString().equals("minecraft:warden");
    }
}
