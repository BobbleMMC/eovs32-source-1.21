package uz.echoes.world;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import uz.echoes.block.EchoProtectorBlock;
import uz.echoes.block.ModBlocks;

public final class EchoProtectorSpawnRules {
    private static final int VERTICAL_SCAN_RADIUS = 8;

    private EchoProtectorSpawnRules() {
    }

    public static boolean shouldBlockSpawn(class_3218 world, class_1297 entity) {
        if (world == null || entity == null || !(entity instanceof class_1309)) {
            return false;
        }
        class_1309 living = (class_1309)entity;
        if (!isDarkSpawnHostile(living)) {
            return false;
        }
        return hasProtectorNear(world, entity.method_24515(), EchoProtectorBlock.PROTECTION_RADIUS);
    }

    public static boolean hasProtectorNear(class_3218 world, class_2338 center, int radius) {
        int radiusSq = radius * radius;
        for (int x = -radius; x <= radius; ++x) {
            for (int y = -VERTICAL_SCAN_RADIUS; y <= VERTICAL_SCAN_RADIUS; ++y) {
                for (int z = -radius; z <= radius; ++z) {
                    if (x * x + z * z > radiusSq) {
                        continue;
                    }
                    class_2338 pos = center.method_10069(x, y, z);
                    if (isProtectorBlock(world.method_8320(pos))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static boolean isProtectorBlock(class_2680 state) {
        return state != null && (state.method_27852(ModBlocks.ECHO_PROTECTOR_BLOCK) || state.method_27852(ModBlocks.SOUL_PROTECTOR_BLOCK));
    }

    public static boolean isDarkSpawnHostile(class_1309 entity) {
        String id = class_7923.field_41177.method_10221((class_1299<?>)entity.method_5864()).toString();
        return id.startsWith("minecraft:zombie")
                || id.equals("minecraft:skeleton")
                || id.equals("minecraft:creeper")
                || id.equals("minecraft:spider")
                || id.equals("minecraft:cave_spider")
                || id.equals("minecraft:enderman")
                || id.equals("minecraft:witch")
                || id.equals("minecraft:slime")
                || id.equals("minecraft:phantom")
                || id.equals("minecraft:husk")
                || id.equals("minecraft:stray")
                || id.equals("minecraft:drowned")
                || id.equals("minecraft:warden")
                || id.equals("minecraft:piglin")
                || id.equals("minecraft:piglin_brute")
                || id.equals("minecraft:zombified_piglin")
                || id.equals("minecraft:magma_cube")
                || id.equals("minecraft:blaze")
                || id.equals("minecraft:ghast")
                || id.equals("minecraft:wither_skeleton");
    }

    public static void clearHostileTarget(class_1309 entity) {
        if (entity instanceof class_1308) {
            ((class_1308)entity).method_5980(null);
        }
    }
}
