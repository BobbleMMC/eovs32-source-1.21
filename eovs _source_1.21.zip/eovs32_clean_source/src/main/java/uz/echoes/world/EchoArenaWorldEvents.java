package uz.echoes.world;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import uz.echoes.world.EchoAltarBossCycle;
import uz.echoes.world.EchoAnchorRegeneration;
import uz.echoes.world.EchoArenaFixer;
import uz.echoes.world.EchoDimensionExpander;
import uz.echoes.world.EchoProgressionManager;
import uz.echoes.world.EchoDimensionPersistentState;

/**
 * Echo dimension runtime manager.
 *
 * The original restored dimension pass ran arena + expander + progression in the
 * same server tick as soon as a player entered the dimension. That can freeze
 * gameplay because the arena alone performs many block writes. This manager keeps
 * the real terrain/worldgen enabled, but stages runtime structures over several
 * ticks and only runs expensive validation at a safe cadence.
 */
public final class EchoArenaWorldEvents {
    private static int tickCounter = 0;
    private static int stageDelay = 0;
    private static int loadedWithPlayersTicks = 0;

    private EchoArenaWorldEvents() {
    }

    public static void register(class_5321<class_1937> dimensionKey) {
        ServerTickEvents.END_SERVER_TICK.register(minecraftServer -> {
            class_3218 echoWorld = minecraftServer.method_3847(dimensionKey);
            if (echoWorld == null || echoWorld.method_18456().isEmpty()) {
                loadedWithPlayersTicks = 0;
                stageDelay = 0;
                return;
            }

            ++tickCounter;
            ++loadedWithPlayersTicks;
            EchoDimensionPersistentState state = EchoDimensionPersistentState.get(echoWorld);

            // Absolute safety runs immediately. It is tiny and protects both
            // portal/sigil entry and direct /execute in ... tp command tests.
            EchoDimensionSafetyManager.tickPlayerSafety(echoWorld);

            // Tick async arena builder
            uz.echoes.world.EchoArenaAsyncBuilder.tickAllBuilds();

            runStagedGeneration(echoWorld, state);

            // Lightweight recurring systems only start after one-time setup.
            // Boss spawning is also gated by persistent state so the monarch does
            // not respawn after defeat or while setup is still repairing terrain.
            if (state.setupComplete()) {
                if (!state.isBossDefeated()) {
                    EchoAltarBossCycle.tick(echoWorld);
                }
                EchoAnchorRegeneration.tick(echoWorld);
                if (tickCounter % 80 == 0) {
                    EchoProgressionManager.tick(echoWorld);
                }
            }
        });
    }

    private static void runStagedGeneration(class_3218 world, EchoDimensionPersistentState state) {
        // Wait a short moment after teleport so the client/server finish loading
        // the dimension before any block placement starts. One operation is done
        // per window; this avoids portal-entry freeze.
        // Do not run any heavy setup immediately after a player arrives. Portal
        // reliability is prioritized: safe bridge platform first, world setup later.
        if (loadedWithPlayersTicks < 120) {
            return;
        }
        if (++stageDelay < 80) {
            return;
        }
        stageDelay = 0;

        if (!state.isArenaGenerated() || !uz.echoes.world.EchoArenaAsyncBuilder.isArenaBuilt(world)) {
            // Arena generation is async/staged. The old logic only checked for
            // null phase, so COMPLETE was never persisted and expander/progression
            // content never ran. Persist completion when the build marker or phase
            // says the arena is complete.
            // Tall-citadel v2 also uses a new marker, so existing worlds that
            // already had the short incomplete arena will be upgraded in place.
            if (uz.echoes.world.EchoArenaAsyncBuilder.isArenaBuilt(world)) {
                state.setArenaGenerated(world, true);
                return;
            }
            if (!uz.echoes.world.EchoArenaAsyncBuilder.isGenerating(world)) {
                uz.echoes.world.EchoArenaAsyncBuilder.startAsyncGeneration(world);
            } else {
                uz.echoes.world.EchoArenaAsyncBuilder.BuildPhase phase = uz.echoes.world.EchoArenaAsyncBuilder.getCurrentPhase(world);
                if (phase != null && phase.isComplete()) {
                    state.setArenaGenerated(world, true);
                }
            }
            return;
        }
        if (!state.isExpanderGenerated()) {
            // Expander/progression are intentionally separated by long windows.
            EchoDimensionExpander.ensureGenerated(world);
            state.setExpanderGenerated(world, true);
            return;
        }
        if (!state.isProgressionGenerated()) {
            EchoProgressionManager.ensureGenerated(world);
            state.setProgressionGenerated(world, true);
            return;
        }
        if (!state.isSafetyDone()) {
            EchoDimensionSafetyManager.runOneTimeSafetyPass(world);
            state.setSafetyDone(world, true);
        }
    }
}
