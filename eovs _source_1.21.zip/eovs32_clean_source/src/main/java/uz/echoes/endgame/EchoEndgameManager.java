/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1937
 *  net.minecraft.class_3218
 */
package uz.echoes.endgame;

import net.minecraft.class_1937;
import net.minecraft.class_3218;
import uz.echoes.endgame.EchoRewardManager;
import uz.echoes.endgame.EchoWorldUnlocker;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class EchoEndgameManager {
    private EchoEndgameManager() {
    }

    public static void onBossDefeated(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        class_1937 class_19372 = echoWardenMonarchEntity.method_37908();
        if (!(class_19372 instanceof class_3218)) {
            return;
        }
        class_3218 class_32182 = (class_3218)class_19372;
        EchoWorldUnlocker.unlockReturn(class_32182);
        EchoRewardManager.grantRewards(class_32182);
    }
}

