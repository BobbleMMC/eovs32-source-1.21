/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 */
package uz.echoes.endgame;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class EchoCompletionTracker {
    private static final Set<UUID> completed = new HashSet<UUID>();

    private EchoCompletionTracker() {
    }

    public static void markComplete(UUID uUID) {
        completed.add(uUID);
    }

    public static boolean hasCompleted(UUID uUID) {
        return completed.contains(uUID);
    }
}

