/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 *  net.minecraft.class_3222
 */
package uz.echoes.endgame;

import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class EchoCreditsTrigger {
    private EchoCreditsTrigger() {
    }

    public static void showCredits(class_3222 class_32222) {
        class_32222.method_7353((class_2561)class_2561.method_43470((String)"You have conquered the Echo Dimension..."), false);
    }
}

