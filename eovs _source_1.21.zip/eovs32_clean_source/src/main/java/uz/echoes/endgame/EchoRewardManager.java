/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_3218
 */
package uz.echoes.endgame;

import net.minecraft.class_3218;

public final class EchoRewardManager {
    private EchoRewardManager() {
    }

    public static void grantRewards(class_3218 class_32182) {
        System.out.println("[EOVS32] Rewards granted after boss defeat");
    }
}

