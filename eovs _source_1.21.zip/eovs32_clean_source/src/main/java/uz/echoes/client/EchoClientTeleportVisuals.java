/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_310
 *  net.minecraft.class_437
 */
package uz.echoes.client;

import net.minecraft.class_310;
import net.minecraft.class_437;
import uz.echoes.client.EchoLoadingOverlay;

public final class EchoClientTeleportVisuals {
    private EchoClientTeleportVisuals() {
    }

    public static void showOverlay() {
        class_310 class_3102 = class_310.method_1551();
        class_3102.execute(() -> {
            if (class_3102.field_1724 == null || class_3102.field_1687 == null) {
                return;
            }
            if (!(class_3102.field_1755 instanceof EchoLoadingOverlay)) {
                class_3102.method_1507((class_437)new EchoLoadingOverlay());
            }
        });
    }
}

