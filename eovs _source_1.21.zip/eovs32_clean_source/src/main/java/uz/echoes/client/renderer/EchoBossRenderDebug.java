/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 */
package uz.echoes.client.renderer;

public final class EchoBossRenderDebug {
    private EchoBossRenderDebug() {
    }

    public static void logRendererLoaded() {
        System.out.println("[EOVS31] Echo Warden Monarch renderer loaded");
    }
}

