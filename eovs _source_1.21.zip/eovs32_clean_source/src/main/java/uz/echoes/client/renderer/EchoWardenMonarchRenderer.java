/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_5617$class_5618
 *  software.bernie.geckolib.model.GeoModel
 *  software.bernie.geckolib.renderer.GeoEntityRenderer
 */
package uz.echoes.client.renderer;

import net.minecraft.class_5617;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import uz.echoes.client.model.EchoWardenMonarchModel;
import uz.echoes.entity.EchoWardenMonarchEntity;

public class EchoWardenMonarchRenderer
extends GeoEntityRenderer<EchoWardenMonarchEntity> {
    public EchoWardenMonarchRenderer(class_5617.class_5618 class_56182) {
        super(class_56182, (GeoModel)new EchoWardenMonarchModel());
        this.field_4673 = 3.5f;
    }
}

