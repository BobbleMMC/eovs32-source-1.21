/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
 *  net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback
 *  net.minecraft.class_1657
 *  net.minecraft.class_1937
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  net.minecraft.class_3417
 *  net.minecraft.class_3419
 *  net.minecraft.class_3532
 *  net.minecraft.class_5321
 *  net.minecraft.class_5819
 *  net.minecraft.class_638
 *  net.minecraft.class_746
 *  net.minecraft.class_9779
 */
package uz.echoes.client.fx;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_9779;
import uz.echoes.portal.EchoDimensionKeys;

public final class EchoDimensionAmbienceClient {
    private static int tickCounter = 0;
    private static float overlayStrength = 0.0f;

    private EchoDimensionAmbienceClient() {
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(EchoDimensionAmbienceClient::clientTick);
        HudRenderCallback.EVENT.register(EchoDimensionAmbienceClient::renderEchoOverlay);
    }

    private static void clientTick(class_310 class_3102) {
        class_638 class_6382 = class_3102.field_1687;
        class_746 class_7462 = class_3102.field_1724;
        if (class_6382 == null || class_7462 == null || !EchoDimensionAmbienceClient.isEchoDimension((class_5321<class_1937>)class_6382.method_27983())) {
            overlayStrength = Math.max(0.0f, overlayStrength - 0.035f);
            return;
        }
        overlayStrength = Math.min(0.55f, overlayStrength + 0.014f);
        EchoDimensionAmbienceClient.spawnAmbientParticles(class_6382, (class_1657)class_7462);
        if (++tickCounter % 1200 == 0 && class_6382.field_9229.method_43048(4) == 0) {
            class_6382.method_8486(class_7462.method_23317(), class_7462.method_23318(), class_7462.method_23321(), class_3417.field_38060, class_3419.field_15256, 0.2f, 0.55f + class_6382.field_9229.method_43057() * 0.12f, false);
        }
    }

    private static boolean isEchoDimension(class_5321<class_1937> class_53212) {
        return EchoDimensionKeys.ECHO_DIMENSION.equals(class_53212);
    }

    private static void spawnAmbientParticles(class_638 class_6382, class_1657 class_16572) {
        class_5819 class_58192 = class_6382.field_9229;
        for (int i = 0; i < 1; ++i) {
            double d = class_16572.method_23317() + (class_58192.method_43058() - 0.5) * 18.0;
            double d2 = class_16572.method_23318() + 1.0 + class_58192.method_43058() * 7.5;
            double d3 = class_16572.method_23321() + (class_58192.method_43058() - 0.5) * 18.0;
            double d4 = (class_58192.method_43058() - 0.5) * 0.015;
            double d5 = 0.005 + class_58192.method_43058() * 0.018;
            double d6 = (class_58192.method_43058() - 0.5) * 0.015;
            if (class_58192.method_43056()) {
                class_6382.method_8406((class_2394)class_2398.field_38002, d, d2, d3, d4, d5, d6);
                continue;
            }
            class_6382.method_8406((class_2394)class_2398.field_22246, d, d2, d3, d4 * 0.3, d5 * 0.35, d6 * 0.3);
        }
        if (class_58192.method_43048(60) == 0) {
            double d = class_16572.method_23317() + (class_58192.method_43058() - 0.5) * 14.0;
            double d7 = class_16572.method_23318() + class_58192.method_43058() * 2.0;
            double d8 = class_16572.method_23321() + (class_58192.method_43058() - 0.5) * 14.0;
            class_6382.method_8406((class_2394)class_2398.field_22247, d, d7, d8, 0.0, 0.01, 0.0);
        }
    }

    private static void renderEchoOverlay(class_332 class_3322, class_9779 class_97792) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1724 == null || class_3102.field_1687 == null || overlayStrength <= 0.01f) {
            return;
        }
        if (!EchoDimensionAmbienceClient.isEchoDimension((class_5321<class_1937>)class_3102.field_1687.method_27983())) {
            return;
        }
        int n = class_3102.method_22683().method_4486();
        int n2 = class_3102.method_22683().method_4502();
        float f = 0.5f + 0.5f * class_3532.method_15374((float)(((float)class_3102.field_1724.field_6012 + class_97792.method_60637(false)) * 0.035f));
        int n3 = class_3532.method_15340((int)((int)((70.0f + f * 20.0f) * overlayStrength)), (int)0, (int)62);
        int n4 = n3 << 24 | 0x06120A;
        class_3322.method_25294(0, 0, n, n2, n4);
    }
}

