/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry
 */
package uz.echoes.client.registry;

import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import uz.echoes.client.renderer.EchoWardenMonarchRenderer;
import uz.echoes.registry.ModEntities;

public final class EchoClientEntityRenderers {
    private EchoClientEntityRenderers() {
    }

    public static void register() {
        EntityRendererRegistry.register(ModEntities.ECHO_WARDEN_MONARCH, EchoWardenMonarchRenderer::new);
    }
}

