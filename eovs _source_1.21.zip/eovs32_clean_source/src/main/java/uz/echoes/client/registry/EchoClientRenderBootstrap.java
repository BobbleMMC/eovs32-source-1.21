/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 */
package uz.echoes.client.registry;

import uz.echoes.client.registry.EchoClientEntityRenderers;
import uz.echoes.client.renderer.EchoBossRenderDebug;

public final class EchoClientRenderBootstrap {
    private EchoClientRenderBootstrap() {
    }

    public static void bootstrap() {
        EchoBossRenderDebug.logRendererLoaded();
        EchoClientEntityRenderers.register();
    }
}

