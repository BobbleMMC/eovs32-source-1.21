/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 *
 * Built-in fallback screen for the Echo Book. Keep this file client-only.
 */
package uz.echoes.client.gui;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

public class EchoBookScreen
extends class_437 {
    private static final int PANEL_W = 220;
    private static final int TEXT_W = 184;
    private static final String DEFAULT_BODY = String.join("\n",
        "=== ECHO DIMENSION GUIDE ===",
        "",
        "--- WARNING ---",
        "Echo Dimension is dangerous. Bring food, blocks, ranged options, Echo tools, and armor before touching arena chests. Chest interaction can awaken the Echo Warden Monarch exactly once.",
        "",
        "--- PORTAL ACCESS ---",
        "Echo Key: opens the reinforced 20x6 Ancient City-style portal frame only outside Echo Dimension. It is intentionally disabled inside Echo Dimension, so the exit portal cannot be opened by hand.",
        "",
        "Echo Gate Sigil: direct travel relic between Overworld and Echo Dimension safe points.",
        "",
        "--- ARENA AND EXIT ---",
        "The citadel arena centers on the Echo Altar. The exit portal opens after Echo Warden Monarch defeat.",
        "",
        "--- CORE BLOCKS ---",
        "Echo Altar: hard but breakable ritual block. Use Echoenergy Stone on it to charge a crystal focus.",
        "Echo Crystal Block: redstone-like echo battery. It powers normally and pulses redstone-related receivers in straight lines up to 30 blocks.",
        "Echo Protector Block: renamed protector block. Emits strong echo light and prevents hostile dark-spawn Overworld/Nether mobs inside 15 blocks.",
        "Void Glass: translucent tinted echo glass with high blast resistance.",
        "Echo Ore: drops Echo Crystal Shards; Silk Touch keeps the ore block.",
        "Dormant Anchor: late progression anchor for endgame crafting.",
        "",
        "--- RELIC ITEMS ---",
        "Sculk Binder Eye: Overworld keeps sculk-sense behavior. In Echo Dimension it converts nearby sculk into crystal anchor points.",
        "Echoenergy Stone: right-click Echo Altar to charge an Echo Crystal focus.",
        "",
        "--- ECHO TOOLS ---",
        "Echo Sword: every mob hit applies 5 seconds of Darkness.",
        "Echo Shovel: suspicious sand/gravel drops as a block; mined blocks can rarely bonus-drop diamond or diamond block.",
        "Echo Axe: sneak-left-click one log to chop the full tree up to 250 logs; leaves vanish.",
        "Echo Pickaxe: after every 1000 mined blocks, grants Haste II for 60 seconds.",
        "Echo Hoe: right-click growable crops or sugar cane for bonemeal-style growth with 0.4s cooldown.",
        "",
        "--- ECHO WARDEN MONARCH ---",
        "The boss is now less spammy with sonic boom, does not despawn during the fight, and takes 1.5x damage only from valid soul-core/chest weak-point hits.",
        "",
        "--- MINI STRUCTURE LOCATE COMMANDS ---",
        "/eovs32locate mini: nearest runtime mini structure.",
        "/eovs32locate mini_altar: nearest Echo Mini Altar.",
        "/eovs32locate echo_shrine: nearest Echo Shrine.",
        "/eovs32locate all: lists the nearest planned mini structures.",
        "",
        "--- SURVIVAL TIPS ---",
        "- Do not touch arena chests unless ready.",
        "- Use Echo Protector Block for safer staging rooms.",
        "- Use Void Glass for blast-resistant viewing windows.",
        "- Use Silk Touch if you want Echo Ore itself.",
        "- Boss defeat, full Echo tools, full Echo armor, Dormant Anchor, and Echo Core progression now have advancements."
    );

    private final String body;

    public EchoBookScreen(String string) {
        super((class_2561)class_2561.method_43470((String)"Echo Book"));
        this.body = string == null ? "" : string;
    }

    public void method_25394(class_332 class_3322, int n, int n2, float f) {
        this.method_25420(class_3322, n, n2, f);
        super.method_25394(class_3322, n, n2, f);
        int n3 = (this.field_22789 - PANEL_W) / 2;
        int n4 = 40;
        List<class_5481> list = this.field_22793.method_1728((class_5348)class_2561.method_43470((String)this.body), TEXT_W);
        for (class_5481 class_54812 : list) {
            class_3322.method_51430(this.field_22793, class_54812, n3 + 18, n4, 0xFFFFFF, false);
            n4 += 10;
            if (n4 > this.field_22790 - 12) {
                break;
            }
        }
    }

    public static void open() {
        class_310.method_1551().method_1507((class_437)new EchoBookScreen(DEFAULT_BODY));
    }
}
