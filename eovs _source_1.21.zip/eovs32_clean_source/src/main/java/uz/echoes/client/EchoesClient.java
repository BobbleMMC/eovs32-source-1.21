/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.ClientModInitializer
 *  net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking
 */
package uz.echoes.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1921;
import uz.echoes.block.ModBlocks;
import uz.echoes.client.registry.EchoClientEntityRenderers;
import uz.echoes.client.fx.EchoDimensionAmbienceClient;
import uz.echoes.client.vfx.EchoBossVfxClient;
import uz.echoes.network.BossVfxPayload;

public class EchoesClient
implements ClientModInitializer {
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(BossVfxPayload.ID, (bossVfxPayload, context) -> context.client().execute(() -> EchoBossVfxClient.play(bossVfxPayload.effect())));
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.ECHO_PORTAL, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.VOID_GLASS, class_1921.method_23581());
        EchoClientEntityRenderers.register();
        EchoDimensionAmbienceClient.register();
    }
}
