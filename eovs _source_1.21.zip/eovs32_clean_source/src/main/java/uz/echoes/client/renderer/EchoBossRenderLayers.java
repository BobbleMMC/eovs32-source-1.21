/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 */
package uz.echoes.client.renderer;

public final class EchoBossRenderLayers {
    public static final String ECHO_GLOW_LAYER = "echo_glow_layer";
    public static final String PHASE_AURA_LAYER = "phase_aura_layer";

    private EchoBossRenderLayers() {
    }
}

