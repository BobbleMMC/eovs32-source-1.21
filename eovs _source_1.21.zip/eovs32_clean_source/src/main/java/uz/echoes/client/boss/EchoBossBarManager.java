/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 */
package uz.echoes.client.boss;

public final class EchoBossBarManager {
    private EchoBossBarManager() {
    }

    public static void initClient() {
    }
}

