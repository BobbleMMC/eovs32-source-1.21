/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2960
 *  software.bernie.geckolib.model.GeoModel
 */
package uz.echoes.client.model;

import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;
import uz.echoes.entity.EchoWardenMonarchEntity;

public class EchoWardenMonarchModel
extends GeoModel<EchoWardenMonarchEntity> {
    private static final class_2960 MODEL = class_2960.method_60655((String)"eovs32", (String)"geo/geometry.echo_warden_monarch.geo.json");
    private static final class_2960 TEXTURE = class_2960.method_60655((String)"eovs32", (String)"textures/entity/echo_warden_monarch.png");
    private static final class_2960 ANIMATIONS = class_2960.method_60655((String)"eovs32", (String)"animations/echo_warden_monarch.animation.json");

    public class_2960 getModelResource(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        return MODEL;
    }

    public class_2960 getTextureResource(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        return TEXTURE;
    }

    public class_2960 getAnimationResource(EchoWardenMonarchEntity echoWardenMonarchEntity) {
        return ANIMATIONS;
    }
}
