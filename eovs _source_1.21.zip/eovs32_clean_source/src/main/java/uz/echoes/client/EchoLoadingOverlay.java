/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 *  net.minecraft.class_332
 *  net.minecraft.class_437
 */
package uz.echoes.client;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class EchoLoadingOverlay
extends class_437 {
    private static final class_2960 PORTAL_TEXTURE = class_2960.method_60655((String)"eovs32", (String)"textures/block/echo_portal.png");

    public EchoLoadingOverlay() {
        super((class_2561)class_2561.method_43470((String)"Echo Dimension"));
    }

    public void method_25394(class_332 class_3322, int n, int n2, float f) {
        class_3322.method_52706(PORTAL_TEXTURE, 0, 0, this.field_22789, this.field_22790);
        super.method_25394(class_3322, n, n2, f);
    }
}
