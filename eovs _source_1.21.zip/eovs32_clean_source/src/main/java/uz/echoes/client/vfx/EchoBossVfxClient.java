/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 *  net.minecraft.class_310
 */
package uz.echoes.client.vfx;

import net.minecraft.class_2561;
import net.minecraft.class_310;

public class EchoBossVfxClient {
    public static void init() {
    }

    public static void play(String string) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1724 == null) {
            return;
        }
        switch (string) {
            case "roar": {
                class_3102.field_1724.method_7353((class_2561)class_2561.method_43470((String)"ROAR VFX"), true);
                break;
            }
            case "shockwave": {
                class_3102.field_1724.method_7353((class_2561)class_2561.method_43470((String)"SHOCKWAVE VFX"), true);
                break;
            }
            case "sniff": {
                class_3102.field_1724.method_7353((class_2561)class_2561.method_43470((String)"SNIFF VFX"), true);
                break;
            }
            case "attack": {
                class_3102.field_1724.method_7353((class_2561)class_2561.method_43470((String)"ATTACK VFX"), true);
            }
        }
    }
}

