/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2960
 */
package uz.echoes.client.model;

import net.minecraft.class_2960;

public final class EchoModelPaths {
    private EchoModelPaths() {
    }

    public static class_2960 geo(String string) {
        return class_2960.method_60655((String)"eovs32", (String)("geo/" + string + ".geo.json"));
    }

    public static class_2960 texture(String string) {
        return class_2960.method_60655((String)"eovs32", (String)("textures/entity/" + string + ".png"));
    }

    public static class_2960 animation(String string) {
        return class_2960.method_60655((String)"eovs32", (String)("animations/" + string + ".animation.json"));
    }
}

