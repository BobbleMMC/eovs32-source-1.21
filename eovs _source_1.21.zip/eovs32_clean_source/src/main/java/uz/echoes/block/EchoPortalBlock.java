package uz.echoes.block;

import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import net.minecraft.class_5819;

/**
 * Stable Echo portal block.
 *
 * Portal travelling is handled only by EchoPortalTickHandler on the server.
 * Keeping teleport logic out of the block prevents double teleports/cooldown races
 * when the player is inside a 20x6 Ancient City portal sheet.
 */
public class EchoPortalBlock extends class_2248 {
    public static final class_2754<class_2350.class_2351> AXIS = class_2754.method_11849(
            "axis",
            class_2350.class_2351.class,
            new class_2350.class_2351[]{class_2350.class_2351.field_11048, class_2350.class_2351.field_11051}
    );

    private static final class_265 X_SHAPE = class_2248.method_9541(0.0D, 0.0D, 6.0D, 16.0D, 16.0D, 10.0D);
    private static final class_265 Z_SHAPE = class_2248.method_9541(6.0D, 0.0D, 0.0D, 10.0D, 16.0D, 16.0D);

    public EchoPortalBlock(class_4970.class_2251 settings) {
        super(settings);
        this.method_9590((class_2680)this.method_9564().method_11657(AXIS, class_2350.class_2351.field_11048));
    }

    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        // Intentionally empty: EchoPortalTickHandler is the single portal-travel authority.
        // Direct collision teleporting can fire every tick and can stack dimension
        // loading before the warmup/cooldown pipeline has stabilized.
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(AXIS);
    }

    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2350.class_2351 axis = (class_2350.class_2351)state.method_11654(AXIS);
        return axis == class_2350.class_2351.field_11048 ? X_SHAPE : Z_SHAPE;
    }

    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        if (random.method_43048(3) != 0) {
            return;
        }

        class_2350.class_2351 axis = (class_2350.class_2351)state.method_11654(AXIS);
        double x = (double)pos.method_10263() + 0.5D;
        double y = (double)pos.method_10264() + random.method_43058();
        double z = (double)pos.method_10260() + 0.5D;
        double velocityX = (random.method_43058() - 0.5D) * 0.08D;
        double velocityY = (random.method_43058() - 0.5D) * 0.04D;
        double velocityZ = (random.method_43058() - 0.5D) * 0.08D;

        if (axis == class_2350.class_2351.field_11048) {
            x = (double)pos.method_10263() + random.method_43058();
            z += (random.method_43058() - 0.5D) * 0.14D;
            velocityZ = (random.method_43056() ? 1.0D : -1.0D) * (0.04D + random.method_43058() * 0.05D);
        } else {
            x += (random.method_43058() - 0.5D) * 0.14D;
            z = (double)pos.method_10260() + random.method_43058();
            velocityX = (random.method_43056() ? 1.0D : -1.0D) * (0.04D + random.method_43058() * 0.05D);
        }

        world.method_8406((class_2394)class_2398.field_38002, x, y, z, velocityX, velocityY, velocityZ);
    }
}
