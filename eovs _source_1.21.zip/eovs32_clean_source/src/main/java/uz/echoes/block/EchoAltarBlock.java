package uz.echoes.block;

import net.minecraft.class_2248;
import net.minecraft.class_4970;

public class EchoAltarBlock extends class_2248 {
    public EchoAltarBlock(class_4970.class_2251 settings) {
        super(settings);
    }
}
