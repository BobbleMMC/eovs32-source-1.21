package uz.echoes.block;

import net.minecraft.class_2248;
import net.minecraft.class_4970;

public class EchoProtectorBlock extends class_2248 {
    public static final int PROTECTION_RADIUS = 15;

    /**
     * Vanilla block light is capped at 15.  The requested "30 level" behavior is
     * implemented by EchoFeatureEvents as a 30-block radius field of invisible
     * vanilla LIGHT blocks around every active protector.
     */
    public static final int ECHO_LIGHT_FIELD_RADIUS = 30;
    public static final int ECHO_LIGHT_FIELD_VERTICAL_RADIUS = 12;
    public static final int ECHO_LIGHT_SPACING = 10;

    public EchoProtectorBlock(class_4970.class_2251 settings) {
        super(settings);
    }
}
