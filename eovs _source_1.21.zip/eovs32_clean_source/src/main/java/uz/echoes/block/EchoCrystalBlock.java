package uz.echoes.block;

import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4970;

public class EchoCrystalBlock extends class_2248 {
    public static final int REDSTONE_RANGE = 30;

    public EchoCrystalBlock(class_4970.class_2251 settings) {
        super(settings);
    }

    public boolean method_9506(class_2680 state) {
        return true;
    }

    public int method_9524(class_2680 state, class_1922 world, class_2338 pos, class_2350 direction) {
        return 15;
    }

    public int method_9603(class_2680 state, class_1922 world, class_2338 pos, class_2350 direction) {
        return 15;
    }
}
