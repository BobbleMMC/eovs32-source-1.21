package uz.echoes.block;

import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4970;

public class VoidGlassBlock extends class_2248 {
    public VoidGlassBlock(class_4970.class_2251 settings) {
        super(settings);
    }

    /**
     * Makes the block behave like real transparent/tinted glass for lighting and culling.
     */
    public boolean method_9579(class_2680 state, class_1922 world, class_2338 pos) {
        return true;
    }

    /**
     * Full brightness on faces prevents the block from visually becoming an opaque dark cube.
     */
    public float method_9575(class_2680 state, class_1922 world, class_2338 pos) {
        return 1.0f;
    }

    /**
     * Hide only internal faces between adjacent Void Glass blocks; keep external faces visible.
     */
    public boolean method_9522(class_2680 state, class_2680 stateFrom, class_2350 direction) {
        return stateFrom.method_27852(this) || super.method_9522(state, stateFrom, direction);
    }
}
