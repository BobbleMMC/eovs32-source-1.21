/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2378
 *  net.minecraft.class_2498
 *  net.minecraft.class_2960
 *  net.minecraft.class_3619
 *  net.minecraft.class_3620
 *  net.minecraft.class_4970
 *  net.minecraft.class_4970$class_2251
 *  net.minecraft.class_7923
 */
package uz.echoes.block;

import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import uz.echoes.EchoesMod;
import uz.echoes.block.EchoPortalBlock;
import uz.echoes.block.VoidGlassBlock;
import uz.echoes.block.EchoProtectorBlock;
import uz.echoes.block.EchoCrystalBlock;
import uz.echoes.block.EchoAltarBlock;

public final class ModBlocks {
    public static final class_2248 ECHO_PORTAL = ModBlocks.register("echo_portal", (class_2248)new EchoPortalBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16026).method_9634().method_9629(-1.0f, 3600000.0f).method_9631(class_26802 -> 11).method_9626(class_2498.field_11537).method_50012(class_3619.field_15972).method_42327()));
    public static final class_2248 ECHO_ALTAR = ModBlocks.register("echo_altar", (class_2248)new EchoAltarBlock(class_4970.class_2251.method_9630((class_4970)class_2246.field_38420).method_31710(class_3620.field_16026).method_9631(class_26802 -> 8).method_9629(85.0f, 1200.0f).method_29292().method_50012(class_3619.field_15972)));
    public static final class_2248 ECHO_PROTECTOR_BLOCK = ModBlocks.register("echo_protector_block", (class_2248)new EchoProtectorBlock(class_4970.class_2251.method_9630((class_4970)class_2246.field_37570).method_31710(class_3620.field_16026).method_9631(class_26802 -> 15).method_9629(8.0f, 1800.0f).method_29292().method_50012(class_3619.field_15972)));
    /** Deprecated compatibility id: keeps old worlds from losing placed protector blocks. */
    @Deprecated
    public static final class_2248 SOUL_PROTECTOR_BLOCK = ModBlocks.register("soul_protector_block", (class_2248)new EchoProtectorBlock(class_4970.class_2251.method_9630((class_4970)class_2246.field_37570).method_31710(class_3620.field_16026).method_9631(class_26802 -> 15).method_9629(8.0f, 1800.0f).method_29292().method_50012(class_3619.field_15972)));
    public static final class_2248 ECHO_CRYSTAL_BLOCK = ModBlocks.register("echo_crystal_block", (class_2248)new EchoCrystalBlock(class_4970.class_2251.method_9630((class_4970)class_2246.field_38420).method_31710(class_3620.field_16026).method_9631(class_26802 -> 13).method_9629(3.5f, 18.0f).method_50012(class_3619.field_15972)));
    public static final class_2248 VOID_GLASS = ModBlocks.register("void_glass", (class_2248)new VoidGlassBlock(class_4970.class_2251.method_9630((class_4970)class_2246.field_27115).method_31710(class_3620.field_16026).method_22488().method_9631(class_26802 -> 2).method_9629(0.8f, 1200.0f).method_50012(class_3619.field_15972)));
    public static final class_2248 DORMANT_ANCHOR = ModBlocks.register("dormant_anchor", new class_2248(class_4970.class_2251.method_9630((class_4970)class_2246.field_37571).method_31710(class_3620.field_16026).method_9631(class_26802 -> 7).method_9629(6.0f, 1200.0f).method_29292()));
    public static final class_2248 SCULK_REINFORCED_STONE = ModBlocks.register("sculk_reinforced_stone", new class_2248(class_4970.class_2251.method_9630((class_4970)class_2246.field_38420).method_31710(class_3620.field_16026).method_9631(class_26802 -> 5).method_9629(75.0f, 1400.0f).method_29292().method_50012(class_3619.field_15972)));
    public static final class_2248 ECHO_ORE = ModBlocks.register("echo_ore", new class_2248(class_4970.class_2251.method_9630((class_4970)class_2246.field_38420).method_31710(class_3620.field_16026).method_9631(class_26802 -> 6).method_9629(4.5f, 9.0f).method_50012(class_3619.field_15972)));

    private ModBlocks() {
    }

    private static class_2248 register(String string, class_2248 class_22482) {
        return (class_2248)class_2378.method_10230((class_2378)class_7923.field_41175, (class_2960)class_2960.method_60655((String)"eovs32", (String)string), (Object)class_22482);
    }

    public static void register() {
        EchoesMod.LOGGER.info("Registering Echo blocks");
    }
}

