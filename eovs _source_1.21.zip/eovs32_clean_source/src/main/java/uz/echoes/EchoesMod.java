/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.ModInitializer
 *  net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package uz.echoes;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uz.echoes.block.ModBlocks;
import uz.echoes.command.EchoLocateCommands;
import uz.echoes.boss.EchoBossDelayedTasks;
import uz.echoes.item.EchoCombatEvents;
import uz.echoes.item.ModItemGroups;
import uz.echoes.item.ModItems;
import uz.echoes.portal.EchoPortalTickHandler;
import uz.echoes.item.EchoUseItemHandler;
import uz.echoes.loot.EchoLootEvents;
import uz.echoes.network.BossVfxPayload;
import uz.echoes.portal.EchoDimensionKeys;
import uz.echoes.registry.ModEntities;
import uz.echoes.sound.ModSounds;
import uz.echoes.world.EchoArenaWorldEvents;
import uz.echoes.world.EchoArenaChestBossTrigger;
import uz.echoes.world.EchoDimensionRules;
import uz.echoes.world.EchoDimensionEntryRescueEvents;
import uz.echoes.world.EchoMobSpawnCleaner;
import uz.echoes.world.EchoFeatureEvents;

public class EchoesMod
implements ModInitializer {
    public static final String MOD_ID = "eovs32";
    public static final Logger LOGGER = LoggerFactory.getLogger((String)"eovs32");

    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(BossVfxPayload.ID, BossVfxPayload.CODEC);
        ModSounds.registerSounds();
        ModBlocks.register();
        ModEntities.registerModEntities();
        ModItems.register();
        ModItemGroups.register();
        EchoCombatEvents.register();
        EchoUseItemHandler.register();
        EchoPortalTickHandler.register();
        EchoLootEvents.register();
        EchoBossDelayedTasks.init();
        EchoArenaWorldEvents.register(EchoDimensionKeys.ECHO_DIMENSION);
        EchoArenaChestBossTrigger.register();
        EchoDimensionEntryRescueEvents.register();
        EchoDimensionRules.register();
        EchoMobSpawnCleaner.register();
        EchoFeatureEvents.register();
        EchoLocateCommands.register();
        LOGGER.info("Echo Dimension Mod initialized. ENTRY_HARDFIX_SIGIL_2026_04_30 active. PORTAL_ENTRY_PIPELINE_REWRITE_2026_05_08 active. CHUNK_WAIT_FLOORFIX_2026_05_09 active. RIGHT_CLICK_PIPELINE_FIX_2026_05_09 active. SIGIL_RESPAWN_RETURN_AND_VANILLA_USE_FIX_2026_05_09 active. OLD_CITADEL_CHEST_TRIGGER_RESTORE_2026_05_09 active.");
    }
}
