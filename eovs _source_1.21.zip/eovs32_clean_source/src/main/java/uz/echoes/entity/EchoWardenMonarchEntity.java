/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1282
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1308
 *  net.minecraft.class_1309
 *  net.minecraft.class_1314
 *  net.minecraft.class_1352
 *  net.minecraft.class_1361
 *  net.minecraft.class_1366
 *  net.minecraft.class_1394
 *  net.minecraft.class_1399
 *  net.minecraft.class_1400
 *  net.minecraft.class_1588
 *  net.minecraft.class_1657
 *  net.minecraft.class_1937
 *  net.minecraft.class_238
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_3213
 *  net.minecraft.class_3218
 *  net.minecraft.class_3222
 *  net.minecraft.class_3417
 *  net.minecraft.class_3419
 *  net.minecraft.class_5132$class_5133
 *  net.minecraft.class_5134
 *  net.minecraft.class_7923
 *  software.bernie.geckolib.animatable.GeoAnimatable
 *  software.bernie.geckolib.animatable.GeoEntity
 *  software.bernie.geckolib.animatable.instance.AnimatableInstanceCache
 *  software.bernie.geckolib.animation.AnimatableManager$ControllerRegistrar
 *  software.bernie.geckolib.animation.AnimationController
 *  software.bernie.geckolib.animation.PlayState
 *  software.bernie.geckolib.animation.RawAnimation
 *  software.bernie.geckolib.util.GeckoLibUtil
 */
package uz.echoes.entity;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1352;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_3213;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_7923;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;
import uz.echoes.boss.EchoBossAttackController;
import uz.echoes.boss.EchoBossDefeatManager;
import uz.echoes.boss.EchoBossPhaseManager;
import uz.echoes.boss.EchoBossWeakPoint;

public class EchoWardenMonarchEntity
extends class_1588
implements GeoEntity {
    private static final RawAnimation BREATHING = RawAnimation.begin().thenLoop("animation.echo_warden_monarch.breathing");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("animation.echo_warden_monarch.walk");
    private static final RawAnimation ATTACK_HIT = RawAnimation.begin().thenPlay("animation.echo_warden_monarch.attack_hit");
    private static final RawAnimation JUMP_WAVE = RawAnimation.begin().thenPlay("animation.echo_warden_monarch.jump_wave");
    private static final RawAnimation SNIFF = RawAnimation.begin().thenPlay("animation.echo_warden_monarch.sniff");
    private static final RawAnimation ROAR = RawAnimation.begin().thenPlay("animation.echo_warden_monarch.roar");
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache((GeoAnimatable)this);
    private int echoPhase = 1;
    private int heartbeatCooldown = 0;
    private int sniffCooldown = 120;
    private int roarCooldown = 0;
    private int invulnerableIntroTicks = 0;
    private boolean defeatHandled = false;
    private class_3213 echoBossBar;

    public EchoWardenMonarchEntity(class_1299<? extends EchoWardenMonarchEntity> class_12992, class_1937 class_19372) {
        super(class_12992, class_19372);
        this.field_6194 = 500;
        this.method_5880(true);
    }

    public static class_5132.class_5133 createEchoWardenAttributes() {
        return class_1588.method_26918().method_26868(class_5134.field_23716, 800.0).method_26868(class_5134.field_23721, 24.0).method_26868(class_5134.field_23724, 9.0).method_26868(class_5134.field_23719, 0.20).method_26868(class_5134.field_23718, 1.0).method_26868(class_5134.field_23717, 96.0);
    }

    protected void method_5959() {
        this.field_6201.method_6277(1, (class_1352)new class_1366((class_1314)this, 1.0, true));
        this.field_6201.method_6277(2, (class_1352)new class_1394((class_1314)this, 0.65));
        this.field_6201.method_6277(3, (class_1352)new class_1361((class_1308)this, class_1657.class, 32.0f));
        this.field_6185.method_6277(1, (class_1352)new class_1399((class_1314)this, new Class[0]));
        this.field_6185.method_6277(2, (class_1352)new class_1400((class_1308)this, class_1657.class, true));
    }

    public void method_5773() {
        super.method_5773();
        if (!this.method_37908().method_8608()) {
            if (this.invulnerableIntroTicks > 0) {
                float f = this.method_6063();
                float f2 = Math.max(0.05f, (70.0f - (float)this.invulnerableIntroTicks) / 70.0f);
                this.method_6033(Math.min(f, f * f2));
                --this.invulnerableIntroTicks;
                this.tickEchoBossBar();
                return;
            }
            int n = this.echoPhase;
            EchoBossPhaseManager.updatePhase(this);
            EchoBossAttackController.tickBossAttacks(this);
            this.acquireNonWardenTarget();
            this.tickEchoBossBar();
            if (n != this.echoPhase) {
                this.triggerRoarAnimation();
            }
            this.tickHeartbeatPulse();
            this.tickSniffAnimation();
        }
        if (this.roarCooldown > 0) {
            --this.roarCooldown;
        }
    }

    public void setEchoBossBar(class_3213 class_32132) {
        this.echoBossBar = class_32132;
    }

    public void detachEchoBossBar() {
        if (this.echoBossBar == null) {
            return;
        }
        class_1937 class_19372 = this.method_37908();
        if (class_19372 instanceof class_3218) {
            for (class_3222 class_32222 : ((class_3218)class_19372).method_18456()) {
                this.echoBossBar.method_14089(class_32222);
            }
        }
        this.echoBossBar = null;
    }

    private void tickEchoBossBar() {
        if (this.echoBossBar == null) {
            return;
        }
        float f = this.method_6063();
        this.echoBossBar.method_5408(f <= 0.0f ? 0.0f : Math.max(0.0f, Math.min(1.0f, this.method_6032() / f)));
        class_1937 class_19372 = this.method_37908();
        if (!(class_19372 instanceof class_3218)) {
            return;
        }
        class_3218 class_32182 = (class_3218)class_19372;
        for (class_3222 class_32222 : class_32182.method_18456()) {
            if (class_32222.method_5858((class_1297)this) <= 16384.0) {
                this.echoBossBar.method_14088(class_32222);
                continue;
            }
            this.echoBossBar.method_14089(class_32222);
        }
    }

    private void acquireNonWardenTarget() {
        if (this.method_5968() != null && this.method_5968().method_5805()) {
            return;
        }
        class_1937 class_19372 = this.method_37908();
        if (!(class_19372 instanceof class_3218)) {
            return;
        }
        class_3218 class_32182 = (class_3218)class_19372;
        class_238 class_2382 = this.method_5829().method_1014(48.0);
        class_1309 class_13093 = null;
        double d = Double.MAX_VALUE;
        for (class_1309 class_13094 : class_32182.method_8390(class_1309.class, class_2382, class_13092 -> class_13092 != this && class_13092.method_5805() && !EchoWardenMonarchEntity.isWardenEntity(class_13092))) {
            double d2 = this.method_5858((class_1297)class_13094);
            if (!(d2 < d)) continue;
            class_13093 = class_13094;
            d = d2;
        }
        if (class_13093 != null) {
            this.method_5980(class_13093);
        }
    }

    private static boolean isWardenEntity(class_1309 class_13092) {
        return class_7923.field_41177.method_10221(class_13092.method_5864()).toString().equals("minecraft:warden");
    }

    public boolean method_5747(float f, float f2, class_1282 class_12822) {
        return false;
    }

    public boolean method_5643(class_1282 class_12822, float f) {
        if (this.invulnerableIntroTicks > 0) {
            return false;
        }
        if (class_12822 != null && EchoWardenMonarchEntity.isEnvironmentalImmunity(class_12822)) {
            return false;
        }
        float adjustedDamage = EchoBossWeakPoint.isSoulCoreHit(this, class_12822) ? f * 1.5f : f;
        return super.method_5643(class_12822, adjustedDamage);
    }

    public void method_6078(class_1282 class_12822) {
        if (!this.defeatHandled) {
            this.defeatHandled = true;
            EchoBossDefeatManager.handleDefeat(this);
        }
        super.method_6078(class_12822);
    }

    public void setInvulnerableIntroTicks(int n) {
        this.invulnerableIntroTicks = Math.max(0, n);
    }

    private static boolean isEnvironmentalImmunity(class_1282 class_12822) {
        String string = class_12822.method_5525();
        return string.contains("fire") || string.contains("lava") || string.contains("hotFloor") || string.contains("fall") || string.contains("inWall") || string.contains("cramming") || string.contains("drown") || string.contains("freeze");
    }

    private void tickHeartbeatPulse() {
        class_1937 class_19372 = this.method_37908();
        if (!(class_19372 instanceof class_3218)) {
            return;
        }
        class_3218 class_32182 = (class_3218)class_19372;
        if (this.heartbeatCooldown > 0) {
            --this.heartbeatCooldown;
            return;
        }
        int n = switch (this.echoPhase) {
            case 3 -> 22;
            case 2 -> 34;
            default -> 48;
        };
        int n2 = n;
        this.heartbeatCooldown = n;
        float f = switch (this.echoPhase) {
            case 3 -> 3.5f;
            case 2 -> 2.6f;
            default -> 1.8f;
        };
        float f2 = switch (this.echoPhase) {
            case 3 -> 0.55f;
            case 2 -> 0.7f;
            default -> 0.85f;
        };
        class_32182.method_8396(null, this.method_24515(), class_3417.field_38068, class_3419.field_15251, f, f2);
        int heartbeatParticles = this.echoPhase == 3 ? 4 : 2 + this.echoPhase * 2;
        double heartbeatSpread = this.echoPhase == 3 ? 0.55 : 0.3 + (double)this.echoPhase * 0.25;
        class_32182.method_14199((class_2394)class_2398.field_38002, this.method_23317(), this.method_23318() + 3.8, this.method_23321(), heartbeatParticles, heartbeatSpread, 0.22, heartbeatSpread, 0.004);
    }

    private void tickSniffAnimation() {
        if (this.sniffCooldown > 0) {
            --this.sniffCooldown;
            return;
        }
        class_1309 class_13092 = this.method_5968();
        if (class_13092 != null && class_13092.method_5805() && this.method_5858((class_1297)class_13092) <= 1024.0 && this.method_59922().method_43048(5) == 0) {
            this.triggerSniffAnimation();
            this.sniffCooldown = 160 + this.method_59922().method_43048(120);
            return;
        }
        this.sniffCooldown = 80;
    }

    private boolean isWalkingForAnimation() {
        double d3 = this.method_23317() - this.field_6014;
        double d = this.method_23321() - this.field_5969;
        return d3 * d3 + d * d > 0.0025;
    }

    public boolean method_6121(class_1297 class_12972) {
        this.triggerAttackHitAnimation();
        return super.method_6121(class_12972);
    }

    public void triggerAttackHitAnimation() {
        if (!this.method_37908().method_8608()) {
            this.triggerAnim("main_controller", "attack_hit");
        }
    }

    public void triggerJumpWaveAnimation() {
        if (!this.method_37908().method_8608()) {
            this.triggerAnim("main_controller", "jump_wave");
        }
    }

    public void triggerSniffAnimation() {
        if (!this.method_37908().method_8608()) {
            this.triggerAnim("main_controller", "sniff");
        }
    }

    public void triggerRoarAnimation() {
        if (!this.method_37908().method_8608() && this.roarCooldown <= 0) {
            this.triggerAnim("main_controller", "roar");
            this.roarCooldown = 40;
        }
    }

    public int getEchoPhase() {
        return this.echoPhase;
    }

    public void setEchoPhase(int n) {
        this.echoPhase = Math.max(1, Math.min(3, n));
    }

    public boolean isTargetValid() {
        class_1309 class_13092 = this.method_5968();
        return class_13092 != null && class_13092.method_5805();
    }

    public void registerControllers(AnimatableManager.ControllerRegistrar controllerRegistrar) {
        controllerRegistrar.add(new AnimationController((GeoAnimatable)this, "breathing_controller", 0, animationState -> animationState.setAndContinue(BREATHING)));
        controllerRegistrar.add(new AnimationController((GeoAnimatable)this, "main_controller", 5, animationState -> {
            if (this.isWalkingForAnimation()) {
                return animationState.setAndContinue(WALK);
            }
            return PlayState.STOP;
        }).triggerableAnim("attack_hit", ATTACK_HIT).triggerableAnim("jump_wave", JUMP_WAVE).triggerableAnim("sniff", SNIFF).triggerableAnim("roar", ROAR));
    }

    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }
}
