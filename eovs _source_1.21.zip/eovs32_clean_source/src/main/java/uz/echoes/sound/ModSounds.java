/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2378
 *  net.minecraft.class_2960
 *  net.minecraft.class_3414
 *  net.minecraft.class_7923
 */
package uz.echoes.sound;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public final class ModSounds {
    public static final String MOD_ID = "eovs32";
    public static final class_3414 ECHO_MONARCH_IDLE_BREATH = ModSounds.register("echo_monarch_idle_breath");
    public static final class_3414 ECHO_MONARCH_WALK = ModSounds.register("echo_monarch_walk");
    public static final class_3414 ECHO_MONARCH_ATTACK_HIT = ModSounds.register("echo_monarch_attack_hit");
    public static final class_3414 ECHO_MONARCH_JUMP_WAVE = ModSounds.register("echo_monarch_jump_wave");
    public static final class_3414 ECHO_MONARCH_SNIFF = ModSounds.register("echo_monarch_sniff");
    public static final class_3414 ECHO_MONARCH_ROAR = ModSounds.register("echo_monarch_roar");
    public static final class_3414 ECHO_MONARCH_DEATH = ModSounds.register("echo_monarch_death");
    public static final class_3414 ECHO_BOSS_DEATH_ULTRA_BASS = ModSounds.register("echo_boss_death_ultra_bass");

    private ModSounds() {
    }

    private static class_3414 register(String string) {
        class_2960 class_29602 = class_2960.method_60655((String)MOD_ID, (String)string);
        return (class_3414)class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)class_29602, (Object)class_3414.method_47908((class_2960)class_29602));
    }

    public static void registerSounds() {
    }
}

