/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_3218
 */
package uz.echoes.structure;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class EchoArenaBoundary {
    public static void createBoundary(class_3218 class_32182, class_2338 class_23382) {
        int n = 25;
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                if (Math.abs(i) != n && Math.abs(j) != n) continue;
                for (int k = 0; k < 10; ++k) {
                    class_32182.method_8501(class_23382.method_10069(i, k, j), class_2246.field_38420.method_9564());
                }
            }
        }
    }
}
