package uz.echoes.structure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;

/**
 * Restored Echo boss arena loot chest placer.
 *
 * The old arena layout used 4 ground/pedestal chests and 8 mid/high balcony
 * chests. This version keeps those exact positions, but fills every chest slot
 * with a deterministic shuffled loot pool so all 27 slots are occupied and the
 * item positions are random per-world/per-chest.
 */
public final class EchoArenaChestFiller {
    private static final int CHEST_SIZE = 27;

    private EchoArenaChestFiller() {
    }

    public static void placeArenaChests(class_3218 world, class_2338 center) {
        placeChest(world, center.method_10069(-22, 0, 0), false);
        placeChest(world, center.method_10069(22, 0, 0), false);
        placeChest(world, center.method_10069(0, 0, -22), false);
        placeChest(world, center.method_10069(0, 0, 22), false);
    }

    public static void placeTallCitadelChests(class_3218 world, class_2338 center) {
        placeChest(world, center.method_10069(0, 19, -31), true);
        placeChest(world, center.method_10069(31, 19, 0), true);
        placeChest(world, center.method_10069(0, 19, 31), true);
        placeChest(world, center.method_10069(-31, 19, 0), true);

        placeChest(world, center.method_10069(0, 33, -31), true);
        placeChest(world, center.method_10069(31, 33, 0), true);
        placeChest(world, center.method_10069(0, 33, 31), true);
        placeChest(world, center.method_10069(-31, 33, 0), true);
    }

    public static void placeArenaChest(class_3218 world, class_2338 pos, boolean rare) {
        placeChest(world, pos, rare);
    }

    public static boolean isArenaChestPosition(class_2338 pos) {
        if (pos == null) {
            return false;
        }
        for (class_2338 chestPos : getArenaChestPositions(new class_2338(0, 81, 0))) {
            if (samePos(pos, chestPos)) {
                return true;
            }
        }
        return false;
    }

    public static List<class_2338> getArenaChestPositions(class_2338 center) {
        ArrayList<class_2338> result = new ArrayList<class_2338>();
        result.add(center.method_10069(-22, 0, 0));
        result.add(center.method_10069(22, 0, 0));
        result.add(center.method_10069(0, 0, -22));
        result.add(center.method_10069(0, 0, 22));

        result.add(center.method_10069(0, 18, -31));
        result.add(center.method_10069(31, 18, 0));
        result.add(center.method_10069(0, 18, 31));
        result.add(center.method_10069(-31, 18, 0));

        result.add(center.method_10069(0, 32, -31));
        result.add(center.method_10069(31, 32, 0));
        result.add(center.method_10069(0, 32, 31));
        result.add(center.method_10069(-31, 32, 0));
        return result;
    }

    private static void placeChest(class_3218 world, class_2338 pos, boolean rare) {
        if (world == null || pos == null) {
            return;
        }
        if (!world.method_8320(pos).method_27852(class_2246.field_10034)) {
            world.method_8501(pos, class_2246.field_10034.method_9564());
        }

        class_2586 blockEntity = world.method_8321(pos);
        if (!(blockEntity instanceof class_2595)) {
            return;
        }

        class_2595 chest = (class_2595)blockEntity;
        if (isFull(chest)) {
            return;
        }
        fillAllSlots(world, pos, chest, rare);
    }

    private static boolean isFull(class_2595 chest) {
        for (int slot = 0; slot < CHEST_SIZE; ++slot) {
            if (chest.method_5438(slot).method_7960()) {
                return false;
            }
        }
        return true;
    }

    private static void fillAllSlots(class_3218 world, class_2338 pos, class_2595 chest, boolean rare) {
        List<LootEntry> loot = rare ? rarePool() : commonPool();
        long seed = world.method_8409().method_43055()
                ^ ((long)pos.method_10263() * 341873128712L)
                ^ ((long)pos.method_10264() * 132897987541L)
                ^ ((long)pos.method_10260() * 42317861L)
                ^ (rare ? 0x5DEECE66DL : 0x9E3779B97F4A7C15L);
        Collections.shuffle(loot, new Random(seed));
        for (int slot = 0; slot < CHEST_SIZE; ++slot) {
            LootEntry entry = loot.get(slot % loot.size());
            if (isDormantLoot(entry.id)) {
                chest.method_5447(slot, new class_1799(item("minecraft:echo_shard"), 1));
                continue;
            }
            chest.method_5447(slot, new class_1799(item(entry.id), entry.count));
        }
    }

    private static List<LootEntry> commonPool() {
        ArrayList<LootEntry> loot = new ArrayList<LootEntry>();
        loot.add(new LootEntry("minecraft:echo_shard", 8));
        loot.add(new LootEntry("minecraft:diamond", 10));
        loot.add(new LootEntry("minecraft:experience_bottle", 24));
        loot.add(new LootEntry("minecraft:golden_apple", 3));
        loot.add(new LootEntry("minecraft:ender_pearl", 8));
        loot.add(new LootEntry("minecraft:sculk_catalyst", 2));
        loot.add(new LootEntry("minecraft:ancient_debris", 3));
        loot.add(new LootEntry("minecraft:netherite_scrap", 3));
        loot.add(new LootEntry("minecraft:amethyst_shard", 16));
        loot.add(new LootEntry("minecraft:lapis_lazuli", 32));
        loot.add(new LootEntry("minecraft:deepslate", 32));
        loot.add(new LootEntry("eovs32:sculk_reinforced_stone", 8));
        loot.add(new LootEntry("minecraft:sculk", 24));
        loot.add(new LootEntry("minecraft:sculk_sensor", 4));
        loot.add(new LootEntry("minecraft:sculk_shrieker", 2));
        loot.add(new LootEntry("eovs32:echo_crystal_shard", 16));
        loot.add(new LootEntry("eovs32:echo_fragment", 3));
        loot.add(new LootEntry("eovs32:echoenergy_stone", 1));
        loot.add(new LootEntry("eovs32:silent_pearl", 2));
        loot.add(new LootEntry("eovs32:ancient_rib_bone", 6));
        loot.add(new LootEntry("eovs32:sculk_reinforced_stone", 24));
        loot.add(new LootEntry("eovs32:echo_crystal_block", 2));
        loot.add(new LootEntry("minecraft:gold_block", 2));
        loot.add(new LootEntry("minecraft:iron_block", 4));
        loot.add(new LootEntry("minecraft:obsidian", 16));
        loot.add(new LootEntry("minecraft:crying_obsidian", 8));
        loot.add(new LootEntry("minecraft:torchflower_seeds", 4));
        return loot;
    }

    private static List<LootEntry> rarePool() {
        ArrayList<LootEntry> loot = new ArrayList<LootEntry>();
        loot.add(new LootEntry("minecraft:enchanted_golden_apple", 1));
        loot.add(new LootEntry("minecraft:diamond_block", 3));
        loot.add(new LootEntry("minecraft:diamond", 20));
        loot.add(new LootEntry("minecraft:netherite_ingot", 2));
        loot.add(new LootEntry("minecraft:netherite_scrap", 6));
        loot.add(new LootEntry("minecraft:ancient_debris", 6));
        loot.add(new LootEntry("minecraft:recovery_compass", 1));
        loot.add(new LootEntry("minecraft:shulker_box", 1));
        loot.add(new LootEntry("minecraft:experience_bottle", 48));
        loot.add(new LootEntry("minecraft:totem_of_undying", 1));
        loot.add(new LootEntry("minecraft:nether_star", 1));
        loot.add(new LootEntry("minecraft:heart_of_the_sea", 1));
        loot.add(new LootEntry("minecraft:golden_apple", 8));
        loot.add(new LootEntry("minecraft:echo_shard", 12));
        loot.add(new LootEntry("eovs32:sculk_reinforced_stone", 16));
        loot.add(new LootEntry("minecraft:sculk_catalyst", 4));
        loot.add(new LootEntry("minecraft:sculk_shrieker", 4));
        loot.add(new LootEntry("eovs32:echo_core", 1));
        loot.add(new LootEntry("eovs32:echo_warden_heart", 1));
        loot.add(new LootEntry("eovs32:echoenergy_stone", 3));
        loot.add(new LootEntry("eovs32:echo_crystal_shard", 32));
        loot.add(new LootEntry("eovs32:echo_fragment", 6));
        loot.add(new LootEntry("eovs32:void_stalker_pearl", 2));
        loot.add(new LootEntry("eovs32:sculk_binder_eye", 1));
        loot.add(new LootEntry("eovs32:echo_gate_sigil", 1));
        loot.add(new LootEntry("eovs32:silent_pearl", 3));
        loot.add(new LootEntry("eovs32:ancient_rib_bone", 8));
        return loot;
    }

    private static boolean isDormantLoot(String id) {
        return "eovs32:dormant_anchor".equals(id) || "eovs32:echo_dormant".equals(id);
    }

    private static boolean samePos(class_2338 a, class_2338 b) {
        return a.method_10263() == b.method_10263()
                && a.method_10264() == b.method_10264()
                && a.method_10260() == b.method_10260();
    }

    private static class_1935 item(String id) {
        int split = id.indexOf(':');
        String namespace = split >= 0 ? id.substring(0, split) : "minecraft";
        String path = split >= 0 ? id.substring(split + 1) : id;
        return (class_1935)class_7923.field_41178.method_10223(class_2960.method_60655(namespace, path));
    }

    private static final class LootEntry {
        private final String id;
        private final int count;

        private LootEntry(String id, int count) {
            this.id = id;
            this.count = count;
        }
    }
}
