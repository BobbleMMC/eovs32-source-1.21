/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_3218
 */
package uz.echoes.structure;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public final class EchoAltarPlacement {
    private EchoAltarPlacement() {
    }

    public static void placeCenterAltar(class_3218 class_32182, class_2338 class_23382) {
        class_2338 class_23383 = class_23382.method_10069(0, 0, 0);
        class_32182.method_8501(class_23383.method_10074(), class_2246.field_38420.method_9564());
        class_32182.method_8501(class_23383, class_2246.field_37570.method_9564());
        class_32182.method_8501(class_23383.method_10084(), class_2246.field_10124.method_9564());
        class_32182.method_8501(class_23383.method_10086(2), class_2246.field_10124.method_9564());
    }
}
