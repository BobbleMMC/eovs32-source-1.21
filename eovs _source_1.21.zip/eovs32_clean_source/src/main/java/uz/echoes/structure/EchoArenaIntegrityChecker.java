/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 *  net.minecraft.class_3218
 */
package uz.echoes.structure;

import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class EchoArenaIntegrityChecker {
    public static boolean check(class_3218 class_32182, class_2338 class_23382) {
        return class_32182.method_22347(class_23382.method_10086(2));
    }
}

