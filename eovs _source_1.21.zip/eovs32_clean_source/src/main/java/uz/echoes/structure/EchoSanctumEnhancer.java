/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_3218
 */
package uz.echoes.structure;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class EchoSanctumEnhancer {
    public static void enhance(class_3218 class_32182, class_2338 class_23382) {
        class_32182.method_8501(class_23382.method_10086(3), class_2246.field_37571.method_9564());
    }
}
