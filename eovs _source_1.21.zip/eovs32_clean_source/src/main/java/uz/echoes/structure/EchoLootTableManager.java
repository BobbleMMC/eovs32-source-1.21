/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1935
 */
package uz.echoes.structure;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;

public class EchoLootTableManager {
    public static class_1799[] getArenaLoot() {
        return new class_1799[]{new class_1799((class_1935)class_1802.field_38746, 6), new class_1799((class_1935)class_1802.field_8477, 3), new class_1799((class_1935)class_1802.field_8463, 2)};
    }
}

