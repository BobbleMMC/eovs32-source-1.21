/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_3218
 */
package uz.echoes.structure;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public final class EchoSanctumLayout {
    private EchoSanctumLayout() {
    }

    public static void placeSimpleSanctum(class_3218 class_32182, class_2338 class_23382) {
        int n = 10;
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                boolean bl = Math.abs(i) == n || Math.abs(j) == n;
                boolean bl2 = bl;
                if (bl) {
                    for (int k = 0; k <= 5; ++k) {
                        class_32182.method_8501(class_23382.method_10069(i, k, j), class_2246.field_28892.method_9564());
                    }
                    continue;
                }
                class_32182.method_8501(class_23382.method_10069(i, -1, j), class_2246.field_37568.method_9564());
                class_32182.method_8501(class_23382.method_10069(i, 0, j), class_2246.field_10124.method_9564());
                class_32182.method_8501(class_23382.method_10069(i, 1, j), class_2246.field_10124.method_9564());
                class_32182.method_8501(class_23382.method_10069(i, 2, j), class_2246.field_10124.method_9564());
            }
        }
        class_32182.method_8501(class_23382.method_10069(0, 0, -n), class_2246.field_10124.method_9564());
        class_32182.method_8501(class_23382.method_10069(0, 1, -n), class_2246.field_10124.method_9564());
        class_32182.method_8501(class_23382.method_10069(0, 2, -n), class_2246.field_10124.method_9564());
    }
}
