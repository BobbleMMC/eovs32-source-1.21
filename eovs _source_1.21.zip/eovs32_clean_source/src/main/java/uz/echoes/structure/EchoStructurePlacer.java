/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_3218
 */
package uz.echoes.structure;

import net.minecraft.class_3218;
import uz.echoes.world.EchoArenaFixer;

public final class EchoStructurePlacer {
    private EchoStructurePlacer() {
    }

    public static void placeBossArena(class_3218 class_32182) {
        EchoArenaFixer.generateArena(class_32182);
    }
}

