/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 *  net.minecraft.class_3218
 */
package uz.echoes.structure;

import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class EchoStructureValidator {
    public static boolean isAreaSafe(class_3218 class_32182, class_2338 class_23382) {
        int n = 25;
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                if (class_32182.method_22347(class_23382.method_10069(i, 1, j))) continue;
                return false;
            }
        }
        return true;
    }
}

