/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry
 *  net.minecraft.class_1299
 *  net.minecraft.class_1299$class_1300
 *  net.minecraft.class_1311
 *  net.minecraft.class_2378
 *  net.minecraft.class_2960
 *  net.minecraft.class_5132$class_5133
 *  net.minecraft.class_7923
 */
package uz.echoes.registry;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5132;
import net.minecraft.class_7923;
import uz.echoes.EchoesMod;
import uz.echoes.entity.EchoWardenMonarchEntity;

public final class ModEntities {
    public static final class_1299<EchoWardenMonarchEntity> ECHO_WARDEN_MONARCH = (class_1299)class_2378.method_10230((class_2378)class_7923.field_41177, (class_2960)class_2960.method_60655((String)"eovs32", (String)"echo_warden_monarch"), (Object)class_1299.class_1300.method_5903(EchoWardenMonarchEntity::new, (class_1311)class_1311.field_6302).method_17687(2.6f, 6.2f).method_27299(80).method_27300(3).method_5905(class_2960.method_60655((String)"eovs32", (String)"echo_warden_monarch").toString()));

    private ModEntities() {
    }

    public static void registerModEntities() {
        FabricDefaultAttributeRegistry.register(ECHO_WARDEN_MONARCH, (class_5132.class_5133)EchoWardenMonarchEntity.createEchoWardenAttributes());
        EchoesMod.LOGGER.info("Registering EOVS32 entities");
    }
}
