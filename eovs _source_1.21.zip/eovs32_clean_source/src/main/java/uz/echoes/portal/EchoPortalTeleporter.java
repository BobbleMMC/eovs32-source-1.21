package uz.echoes.portal;

import uz.echoes.EchoesMod;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import uz.echoes.world.EchoArenaFixer;
import uz.echoes.world.EchoDimensionSafetyManager;
import uz.echoes.world.EchoExitHandler;

/**
 * Central server-side travel logic for the Echo portal.
 *
 * Important freeze fix:
 * Portal blocks and the Echo Gate Sigil are only allowed to enqueue one travel
 * request. The actual dimension lookup and teleport happen on the server tick
 * after a tiny delay, so repeated collision/item callbacks cannot stack world
 * generation or teleport calls on the same frame.
 */
public final class EchoPortalTeleporter {
    private static final class_2338 ECHO_BRIDGE_SPAWN = EchoArenaFixer.PLAYER_BRIDGE_SPAWN;
    private static final int PORTAL_COOLDOWN_TICKS = 120;
    private static final int ENTRY_PREPARE_DELAY_TICKS = 4;
    private static final int PREPARE_TIMEOUT_TICKS = 20 * 20;
    private static final Map<UUID, Long> NEXT_ALLOWED_TRAVEL_TICK = new HashMap<>();
    private static final Map<UUID, PendingTravel> PENDING_TRAVEL = new HashMap<>();
    private static long serverTickCounter = 0L;

    private EchoPortalTeleporter() {
    }

    public static boolean canUsePortal(class_3222 player) {
        if (player == null) {
            return false;
        }
        if (PENDING_TRAVEL.containsKey(player.method_5667())) {
            return false;
        }
        long now = serverTickCounter;
        Long nextAllowed = NEXT_ALLOWED_TRAVEL_TICK.get(player.method_5667());
        return nextAllowed == null || now >= nextAllowed.longValue();
    }

    public static boolean isTravelPending(class_3222 player) {
        return player != null && PENDING_TRAVEL.containsKey(player.method_5667());
    }

    public static void tickCooldowns(class_3218 world) {
        cleanupCooldowns();
    }

    private static void cleanupCooldowns() {
        long now = serverTickCounter;
        Iterator<Map.Entry<UUID, Long>> iterator = NEXT_ALLOWED_TRAVEL_TICK.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Long> entry = iterator.next();
            if (now >= entry.getValue().longValue() + 20L) {
                iterator.remove();
            }
        }
    }

    public static void tickPendingTravels() {
        ++serverTickCounter;
        cleanupCooldowns();
        Iterator<Map.Entry<UUID, PendingTravel>> iterator = PENDING_TRAVEL.entrySet().iterator();
        while (iterator.hasNext()) {
            PendingTravel pending = iterator.next().getValue();
            class_3222 player = pending.player;
            if (player == null) {
                iterator.remove();
                continue;
            }
            long now = serverTickCounter;
            if (now < pending.nextStepTick) {
                continue;
            }
            if (now - pending.createdTick > PREPARE_TIMEOUT_TICKS) {
                iterator.remove();
                continue;
            }

            MinecraftServer server = player.method_5682();
            if (server == null) {
                iterator.remove();
                continue;
            }

            class_3218 echoWorld = server.method_3847(EchoDimensionKeys.ECHO_DIMENSION);
            if (echoWorld == null) {
                iterator.remove();
                continue;
            }

            EchoDimensionSafetyManager.forceEssentialChunks(echoWorld);
        class_2338 safeArrival = EchoDimensionSafetyManager.forceBridgeArrivalPlatform(echoWorld);
            if (safeArrival == null) {
                iterator.remove();
                continue;
            }

            player.method_51850(PORTAL_COOLDOWN_TICKS);
            if (player.method_51469().method_27983().equals(EchoDimensionKeys.ECHO_DIMENSION)) {
                teleportTo(player.method_51469(), player, safeArrival);
            } else {
                teleportTo(echoWorld, player, safeArrival);
            }
            player.method_51850(PORTAL_COOLDOWN_TICKS);
            iterator.remove();
        }
    }

    public static void teleport(class_3222 player) {
        requestPortalTravel(player);
    }

    public static boolean requestPortalTravel(class_3222 player) {
        if (player == null) {
            return false;
        }
        if (PENDING_TRAVEL.containsKey(player.method_5667())) {
            return false;
        }
        if (!canUsePortal(player)) {
            return false;
        }

        MinecraftServer server = player.method_5682();
        if (server == null) {
            return false;
        }

        class_3218 currentWorld = player.method_51469();
        if (currentWorld.method_27983().equals(EchoDimensionKeys.ECHO_DIMENSION)) {
            player.method_51850(PORTAL_COOLDOWN_TICKS);
            EchoExitHandler.exitToOverworld(player);
            player.method_51850(PORTAL_COOLDOWN_TICKS);
            return true;
        }

        return queueStagedTravel(player, "Portal", "Echo Portal");
    }


    /**
     * Direct Echo Gate Sigil travel path.
     *
     * This intentionally does not require a portal block or Ancient City frame.
     * It always sends the player to the protected obsidian bridge platform in
     * the Echo Dimension and only performs the tiny platform safety pass before
     * teleporting. Heavy arena/world setup is still handled later by the normal
     * one-time dimension systems.
     */
    public static boolean teleportToEchoPlatformFromSigil(class_3222 player) {
        return requestSigilTravel(player);
    }

    public static boolean requestSigilTravel(class_3222 player) {
        if (player == null) {
            return false;
        }
        if (PENDING_TRAVEL.containsKey(player.method_5667())) {
            return false;
        }
        if (!canUsePortal(player)) {
            return false;
        }

        if (player.method_51469().method_27983().equals(EchoDimensionKeys.ECHO_DIMENSION)) {
            startCooldown(player);
            returnToOverworldRespawn(player);
            return true;
        }

        return queueStagedTravel(player, "Sigil", "Echo Gate Sigil");
    }

    private static void startCooldown(class_3222 player) {
        NEXT_ALLOWED_TRAVEL_TICK.put(player.method_5667(), Long.valueOf(serverTickCounter + (long)PORTAL_COOLDOWN_TICKS));
        player.method_51850(PORTAL_COOLDOWN_TICKS);
    }

    private static void returnToOverworldRespawn(class_3222 player) {
        MinecraftServer server = player.method_5682();
        if (server == null) {
            return;
        }

        class_3218 overworld = server.method_30002();
        class_2338 targetPos = overworld.method_43126();
        float yaw = player.method_36454();

        try {
            class_2338 respawnPos = player.method_26280();
            class_3218 respawnWorld = server.method_3847(player.method_26281());
            if (respawnPos != null && respawnWorld == overworld) {
                targetPos = respawnPos;
                yaw = player.method_30631();
            }
        } catch (Exception exception) {
            EchoesMod.LOGGER.warn("Could not read Echo return respawn target; falling back to overworld spawn.", exception);
        }

        player.method_14251(
                overworld,
                (double)targetPos.method_10263() + 0.5D,
                (double)targetPos.method_10264() + 0.2D,
                (double)targetPos.method_10260() + 0.5D,
                yaw,
                player.method_36455()
        );
    }

    private static boolean queueStagedTravel(class_3222 player, String logPrefix, String label) {
        UUID uuid = player.method_5667();
        if (PENDING_TRAVEL.containsKey(uuid)) {
            return false;
        }
        MinecraftServer server = player.method_5682();
        if (server == null) {
            return false;
        }
        class_3218 echoWorld = server.method_3847(EchoDimensionKeys.ECHO_DIMENSION);
        if (echoWorld == null) {
            return false;
        }
        EchoDimensionSafetyManager.forceEssentialChunks(echoWorld);
        EchoDimensionSafetyManager.forceBridgeArrivalPlatform(echoWorld);
        startCooldown(player);
        PENDING_TRAVEL.put(uuid, new PendingTravel(player, serverTickCounter, logPrefix, label));
        return true;
    }

    private static void teleportTo(class_3218 targetWorld, class_3222 player, class_2338 targetPos) {
        if (targetWorld == null || player == null || targetPos == null) {
            return;
        }
        EchoDimensionSafetyManager.forceEssentialChunks(targetWorld);
        EchoDimensionSafetyManager.forceBridgeArrivalPlatform(targetWorld);
        player.method_14251(
                targetWorld,
                (double)targetPos.method_10263() + 0.5D,
                (double)targetPos.method_10264(),
                (double)targetPos.method_10260() + 0.5D,
                player.method_36454(),
                player.method_36455()
        );
    }

    private static final class PendingTravel {
        private final class_3222 player;
        private final long createdTick;
        private final String logPrefix;
        private final String label;
        private long nextStepTick;

        private PendingTravel(class_3222 player, long createdTick, String logPrefix, String label) {
            this.player = player;
            this.createdTick = createdTick;
            this.logPrefix = logPrefix;
            this.label = label;
            this.nextStepTick = createdTick + (long)ENTRY_PREPARE_DELAY_TICKS;
        }
    }
}
