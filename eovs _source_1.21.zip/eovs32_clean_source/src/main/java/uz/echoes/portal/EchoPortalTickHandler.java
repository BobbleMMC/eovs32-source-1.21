package uz.echoes.portal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import uz.echoes.block.ModBlocks;

/**
 * Single authoritative portal detector.
 *
 * Portal travelling is handled here for every game mode. The detector scans a
 * small area around the player instead of only checking the exact feet block;
 * this keeps opened Ancient City portals usable for creative players who fly
 * through the portal sheet quickly or hover slightly outside the block center.
 */
public final class EchoPortalTickHandler {
    /** Short staged warmup: enough to show particles, not enough to stack teleport calls. */
    private static final int PORTAL_WARMUP_TICKS = 40;
    private static final int PORTAL_WARMUP_STALE_TICKS = 20 * 15;
    private static final Map<UUID, Integer> PORTAL_WARMUP = new HashMap<>();
    private static final Map<UUID, Long> PORTAL_WARMUP_LAST_SEEN = new HashMap<>();
    private static long serverTickCounter = 0L;

    private EchoPortalTickHandler() {
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            ++serverTickCounter;
            EchoPortalTeleporter.tickPendingTravels();
            cleanupWarmups();
        });
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (!(world instanceof class_3218)) {
                return;
            }
            class_3218 serverWorld = (class_3218)world;
            List<class_3222> readyToTravel = new ArrayList<>();
            for (class_1657 player : new ArrayList<>(serverWorld.method_18456())) {
                if (!(player instanceof class_3222)) {
                    continue;
                }
                class_3222 serverPlayer = (class_3222)player;
                if (serverPlayer.method_30230() || EchoPortalTeleporter.isTravelPending(serverPlayer) || !EchoPortalTeleporter.canUsePortal(serverPlayer)) {
                    resetWarmup(serverPlayer);
                    continue;
                }
                if (!isPlayerTouchingEchoPortal(serverWorld, serverPlayer)) {
                    resetWarmup(serverPlayer);
                    continue;
                }
                if (advanceWarmup(serverWorld, serverPlayer) >= PORTAL_WARMUP_TICKS) {
                    resetWarmup(serverPlayer);
                    readyToTravel.add(serverPlayer);
                }
            }
            for (class_3222 serverPlayer : readyToTravel) {
                if (!serverPlayer.method_30230() && !EchoPortalTeleporter.isTravelPending(serverPlayer) && EchoPortalTeleporter.canUsePortal(serverPlayer)) {
                    EchoPortalTeleporter.requestPortalTravel(serverPlayer);
                }
            }
        });
    }


    private static int advanceWarmup(class_3218 world, class_3222 player) {
        UUID uuid = player.method_5667();
        int ticks = PORTAL_WARMUP.getOrDefault(uuid, Integer.valueOf(0)).intValue() + 1;
        PORTAL_WARMUP.put(uuid, Integer.valueOf(ticks));
        PORTAL_WARMUP_LAST_SEEN.put(uuid, Long.valueOf(serverTickCounter));
        playNetherStylePortalCharge(world, player, ticks);
        return ticks;
    }

    /**
     * Keeps portal entry visual-only. No status text or nausea effect is applied;
     * the real teleport still happens only after the warmup finishes.
     */
    private static void playNetherStylePortalCharge(class_3218 world, class_3222 player, int ticks) {
        if (ticks % 5 == 0) {
            double x = player.method_23317();
            double y = player.method_23318() + 1.0D;
            double z = player.method_23321();
            world.method_14199((class_2394)class_2398.field_38002, x, y, z, 12, 0.45D, 0.75D, 0.45D, 0.02D);
        }
    }

    private static void resetWarmup(class_3222 player) {
        UUID uuid = player.method_5667();
        PORTAL_WARMUP.remove(uuid);
        PORTAL_WARMUP_LAST_SEEN.remove(uuid);
    }

    private static void cleanupWarmups() {
        long now = serverTickCounter;
        Iterator<Map.Entry<UUID, Long>> iterator = PORTAL_WARMUP_LAST_SEEN.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Long> entry = iterator.next();
            if (now - entry.getValue().longValue() > (long)PORTAL_WARMUP_STALE_TICKS) {
                PORTAL_WARMUP.remove(entry.getKey());
                iterator.remove();
            }
        }
    }

    /**
     * Creative mode movement can skip the exact feet/head block check. A compact
     * scan around the player makes the opened portal reliable without allowing
     * teleporting from empty space.
     */
    private static boolean isPlayerTouchingEchoPortal(class_3218 world, class_3222 player) {
        class_2338 base = player.method_24515();
        int baseX = base.method_10263();
        int baseY = base.method_10264();
        int baseZ = base.method_10260();

        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 2; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (isEchoPortal(world, new class_2338(baseX + dx, baseY + dy, baseZ + dz))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static boolean isEchoPortal(class_3218 world, class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return state.method_27852(ModBlocks.ECHO_PORTAL);
    }
}
