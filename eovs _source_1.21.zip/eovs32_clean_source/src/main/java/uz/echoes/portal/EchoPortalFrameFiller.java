/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350$class_2351
 *  net.minecraft.class_2680
 *  net.minecraft.class_3218
 */
package uz.echoes.portal;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import uz.echoes.block.EchoPortalBlock;
import uz.echoes.block.ModBlocks;

public final class EchoPortalFrameFiller {
    public static final int PORTAL_HEIGHT = 6;
    public static final int PORTAL_LENGTH = 20;

    private EchoPortalFrameFiller() {
    }

    public static boolean tryOpenPortal(class_3218 class_32182, class_2338 class_23382) {
        if (!class_32182.method_8320(class_23382).method_27852(class_2246.field_38420)) {
            return false;
        }
        return EchoPortalFrameFiller.tryOpenInAxis(class_32182, class_23382, class_2350.class_2351.field_11048) || EchoPortalFrameFiller.tryOpenInAxis(class_32182, class_23382, class_2350.class_2351.field_11051);
    }

    private static boolean tryOpenInAxis(class_3218 class_32182, class_2338 class_23382, class_2350.class_2351 class_23512) {
        class_2350.class_2351 class_23513 = class_23512 == class_2350.class_2351.field_11048 ? class_2350.class_2351.field_11051 : class_2350.class_2351.field_11048;
        for (int i = -1; i <= 20; ++i) {
            for (int j = -1; j <= 6; ++j) {
                class_2338 class_23383 = EchoPortalFrameFiller.offset(class_23382, class_23513, -i).method_10087(j);
                if (!EchoPortalFrameFiller.isValidFrame(class_32182, class_23383, class_23513)) continue;
                EchoPortalFrameFiller.fillInterior(class_32182, class_23383, class_23513, class_23512);
                return true;
            }
        }
        return false;
    }

    private static boolean isValidFrame(class_3218 class_32182, class_2338 class_23382, class_2350.class_2351 class_23512) {
        for (int i = -1; i <= 20; ++i) {
            for (int j = -1; j <= 6; ++j) {
                boolean bl = i == -1 || i == 20 || j == -1 || j == 6;
                class_2338 class_23383 = EchoPortalFrameFiller.offset(class_23382, class_23512, i).method_10086(j);
                class_2680 class_26802 = class_32182.method_8320(class_23383);
                if (bl) {
                    if (class_26802.method_27852(class_2246.field_38420)) continue;
                } else if (EchoPortalFrameFiller.canReplaceInterior(class_26802)) continue;
                return false;
            }
        }
        return true;
    }

    private static boolean canReplaceInterior(class_2680 class_26802) {
        return class_26802.method_26215() || class_26802.method_27852(class_2246.field_37568) || class_26802.method_27852(class_2246.field_37569) || class_26802.method_27852(ModBlocks.ECHO_PORTAL);
    }

    private static void fillInterior(class_3218 class_32182, class_2338 class_23382, class_2350.class_2351 class_23512, class_2350.class_2351 class_23513) {
        class_2680 class_26802 = (class_2680)ModBlocks.ECHO_PORTAL.method_9564().method_11657(EchoPortalBlock.AXIS, class_23512);
        for (int i = 0; i < 20; ++i) {
            for (int j = 0; j < 6; ++j) {
                class_2338 class_23383 = EchoPortalFrameFiller.offset(class_23382, class_23512, i).method_10086(j);
                class_32182.method_8652(class_23383, class_26802, 3);
            }
        }
    }

    private static class_2338 offset(class_2338 class_23382, class_2350.class_2351 class_23512, int n) {
        return class_23512 == class_2350.class_2351.field_11048 ? class_23382.method_10069(n, 0, 0) : class_23382.method_10069(0, 0, n);
    }
}
