/*
 * Decompiled with CFR 0.2.0 (FabricMC d28b102d).
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 *  net.minecraft.class_3218
 *  net.minecraft.class_3222
 *  net.minecraft.server.MinecraftServer
 */
package uz.echoes.portal;

import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import uz.echoes.EchoesMod;

public final class EchoRespawnReturnTarget {
    private EchoRespawnReturnTarget() {
    }

    public static Target resolve(class_3222 class_32222) {
        class_2338 class_23382;
        MinecraftServer minecraftServer = class_32222.method_5682();
        class_3218 class_32182 = minecraftServer.method_30002();
        try {
            class_2338 class_23383 = class_32222.method_26280();
            class_3218 respawnWorld = minecraftServer.method_3847(class_32222.method_26281());
            if (class_23383 != null && respawnWorld != null) {
                return new Target(respawnWorld, class_23383, class_32222.method_30631());
            }
        } catch (Exception exception) {
            EchoesMod.LOGGER.warn("Could not resolve player respawn target for Echo return; falling back to overworld spawn.", exception);
        }
        class_23382 = class_32182.method_43126();
        return new Target(class_32182, class_23382, class_32222.method_36454());
    }

    public record Target(class_3218 world, class_2338 pos, float yaw) {
    }
}

